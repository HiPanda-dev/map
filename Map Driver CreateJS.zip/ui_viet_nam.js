(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"ui_viet_nam_atlas_", frames: [[132,823,46,19],[647,771,62,24],[633,537,86,34],[396,449,122,28],[0,761,59,26],[959,821,50,20],[577,726,72,24],[172,695,73,26],[706,814,58,19],[0,619,86,28],[904,821,53,19],[700,580,94,28],[749,692,80,24],[796,635,82,27],[943,799,63,20],[0,589,93,28],[369,89,123,25],[520,456,100,34],[315,483,77,24],[771,664,82,26],[845,820,57,19],[369,221,133,36],[666,668,81,26],[536,381,80,28],[722,770,75,20],[438,747,68,24],[441,720,70,25],[564,803,46,26],[799,779,73,19],[498,801,64,19],[458,661,79,27],[348,769,39,39],[247,695,43,43],[831,698,65,28],[544,564,76,36],[225,804,60,19],[892,612,86,28],[398,411,101,35],[885,372,36,106],[0,789,68,20],[0,811,59,19],[504,0,140,73],[0,703,67,27],[387,816,58,19],[95,592,95,27],[705,191,139,36],[339,545,102,28],[172,668,48,24],[204,723,19,91],[598,611,90,27],[470,690,67,28],[0,369,140,28],[863,485,115,28],[689,79,56,28],[252,539,85,34],[73,735,65,25],[386,690,82,24],[539,670,85,24],[600,418,97,36],[368,716,71,25],[501,411,97,36],[0,437,102,34],[225,740,42,38],[292,709,74,24],[508,753,65,24],[287,818,49,19],[0,677,85,24],[0,0,367,367],[683,718,71,25],[367,743,69,24],[292,735,73,23],[211,430,97,36],[622,573,76,36],[690,638,79,28],[612,819,55,20],[635,342,109,36],[389,769,35,43],[497,632,86,27],[1000,274,24,24],[504,79,183,36],[314,575,97,28],[857,38,94,75],[513,723,62,28],[232,575,80,34],[585,640,79,28],[980,485,44,26],[1008,32,14,14],[845,545,102,28],[983,198,39,32],[296,782,40,34],[130,562,100,28],[379,652,77,28],[618,380,104,36],[689,115,172,36],[747,0,206,36],[369,117,171,36],[700,610,94,26],[898,724,62,28],[369,155,154,34],[561,191,142,36],[780,800,63,20],[506,602,90,28],[923,448,96,35],[855,668,75,28],[336,369,29,35],[651,745,69,24],[336,421,58,60],[863,122,158,36],[542,153,166,36],[50,514,85,35],[369,0,133,87],[514,537,117,25],[227,611,68,35],[443,564,99,28],[405,624,90,26],[0,735,71,24],[859,515,105,28],[743,491,114,28],[577,752,68,24],[142,369,125,31],[860,160,143,36],[542,117,137,34],[893,236,125,36],[227,665,76,28],[880,642,92,24],[796,439,65,50],[846,198,135,36],[752,310,118,34],[338,810,47,24],[920,575,77,35],[50,551,78,36],[874,799,67,19],[426,773,74,20],[974,642,43,51],[87,681,83,24],[757,274,123,34],[105,476,93,36],[522,305,111,36],[721,551,105,27],[192,592,33,74],[683,696,63,20],[504,229,129,36],[514,507,111,28],[923,410,99,36],[140,753,62,25],[140,723,62,28],[93,651,77,28],[635,304,115,36],[200,504,113,28],[398,381,136,28],[398,267,117,36],[305,682,79,25],[923,372,101,36],[622,477,119,28],[0,476,103,33],[70,802,60,20],[269,760,77,20],[398,305,122,34],[756,718,63,28],[746,372,137,28],[104,440,100,34],[69,707,69,26],[959,774,63,23],[269,369,65,59],[766,236,125,36],[106,402,103,36],[0,651,91,24],[398,341,109,36],[413,594,91,28],[396,479,116,28],[575,778,61,23],[622,456,73,19],[830,402,52,35],[872,342,140,28],[211,402,55,25],[747,38,108,66],[0,511,48,62],[369,259,27,160],[955,0,51,120],[1008,0,7,30],[669,819,30,29],[517,267,116,36],[872,312,141,28],[539,696,74,25],[766,822,47,19],[724,402,104,35],[447,822,52,19],[932,695,70,27],[635,229,129,35],[615,696,66,28],[501,822,51,19],[796,607,94,26],[638,797,66,20],[699,439,95,36],[828,575,90,30],[88,621,84,28],[966,515,56,44],[225,782,69,20],[962,724,34,48],[297,635,80,28],[882,274,116,36],[722,748,82,20],[711,792,67,20],[61,762,61,25],[132,802,63,19],[124,780,69,20],[0,399,104,36],[61,824,46,19],[314,605,89,28],[879,755,78,20],[646,0,99,77],[980,612,40,19],[627,507,109,28],[424,509,88,34],[746,346,100,24],[635,266,120,36],[315,509,107,28],[509,343,107,36],[369,191,190,28],[879,777,74,20],[932,668,34,20],[206,468,100,34],[738,521,105,28],[137,534,113,26],[806,755,71,22],[426,795,70,19],[502,779,70,20],[821,728,69,25],[710,153,148,36]]}
];


// symbols:



(lib.ALuoi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ARoang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Attapeu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMeThuot = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.BaBe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bakhe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.BacGiang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.BacHa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.BacKan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.BacLieu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.BacMe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.BacNinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.BacQuang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.BacSon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.BachMa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.BanGioc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.BanKhietNgong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.BanLung = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.BangLang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.BaoLac = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.BaoLoc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Battambang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.BenTre = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.BinhBa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.BinhChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.BinhLu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1copy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.BoY = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.BuonDon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.BuonHo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CaMau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_3 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_4 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CaiBe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CaiLay = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CanCau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CanTho = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CaoBang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.caobangpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CaoLanh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CaoSon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.caosonpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CatBa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CatTien = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CauTreo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.Champassak = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.ChauDoc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CocLy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.coclypngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.ConDao = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CuChi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CuLaoCham = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.DBienPhu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.DaLat = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.Danang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.DinhLap = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.DonDeang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.DongGiang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.DongHoi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.DongKhe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.DongNai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.DongVan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.dongvanpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.DongXoai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.DraySap = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.DuGia = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.DuongLam = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.ghichucacphuongtien = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.GiaNghia = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.GotFerry = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.HSuPhi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.HaGiang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.HaLong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.HaTien = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.HaTinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.HaiPhong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.HaNoiDongHoi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.HANOI = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.hnpoint = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.HoChiMinhCity = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.HoaBinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.HoangSa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.HoiAn = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.Hongsa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.Houixai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.Hue = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.imgdot = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.Kenethao = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.kepcambodge = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.Kep = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.KheXanh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.Kohker = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.KohTrong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.KompongCham = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.KompongChhnang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.KompongThom = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.KonTum = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.Kratie = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.KrongKampot = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.KrongPoiPet = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.LacLake = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.LaiChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.LangSon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.LaoCai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.laocaipngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.Laongam = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.LongXuyen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.LuangNamtha = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.LuangPrabang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.LungCu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.lungkhaunhin = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.LungKhauNhinpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.LySon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.MaiChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.map3nuoc1pngcopy = function() {
	this.initialize(img.map3nuoc1pngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2048,2854);


(lib.MeoVac = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.MocBai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.MocChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.Mondulkiri = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.MongCai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.MuCangChai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.MuangKham = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.MuangNgoy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.MuangSing = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.MuiNe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.MuongHum = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.muonghumpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.MuongKhua = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(126);
}).prototype = p = new cjs.Sprite();



(lib.MuongLay = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(127);
}).prototype = p = new cjs.Sprite();



(lib.MyLai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(128);
}).prototype = p = new cjs.Sprite();



(lib.MySon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(129);
}).prototype = p = new cjs.Sprite();



(lib.MyTho = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(130);
}).prototype = p = new cjs.Sprite();



(lib.NamCan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(131);
}).prototype = p = new cjs.Sprite();



(lib.NamDinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(132);
}).prototype = p = new cjs.Sprite();



(lib.namdinhpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(133);
}).prototype = p = new cjs.Sprite();



(lib.NamGiang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(134);
}).prototype = p = new cjs.Sprite();



(lib.NamNgum = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(135);
}).prototype = p = new cjs.Sprite();



(lib.NghiaLo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(136);
}).prototype = p = new cjs.Sprite();



(lib.NhaTrang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(137);
}).prototype = p = new cjs.Sprite();



(lib.NinhBinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(138);
}).prototype = p = new cjs.Sprite();



(lib.NinhBinhpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(139);
}).prototype = p = new cjs.Sprite();



(lib.NinhGia = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(140);
}).prototype = p = new cjs.Sprite();



(lib.NongKhiaw = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(141);
}).prototype = p = new cjs.Sprite();



(lib.Oudomxai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(142);
}).prototype = p = new cjs.Sprite();



(lib.PakBeng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(143);
}).prototype = p = new cjs.Sprite();



(lib.Paksong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(144);
}).prototype = p = new cjs.Sprite();



(lib.Paksé = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(145);
}).prototype = p = new cjs.Sprite();



(lib.Pakxan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(146);
}).prototype = p = new cjs.Sprite();



(lib.PhanRang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(147);
}).prototype = p = new cjs.Sprite();



(lib.PhanThiet = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(148);
}).prototype = p = new cjs.Sprite();



(lib.PhnomPenh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(149);
}).prototype = p = new cjs.Sprite();



(lib.PhongNha = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(150);
}).prototype = p = new cjs.Sprite();



(lib.PhongTho = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(151);
}).prototype = p = new cjs.Sprite();



(lib.Phongsali = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(152);
}).prototype = p = new cjs.Sprite();



(lib.Phonxavan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(153);
}).prototype = p = new cjs.Sprite();



(lib.PhuQuoc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(154);
}).prototype = p = new cjs.Sprite();



(lib.PhuYen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(155);
}).prototype = p = new cjs.Sprite();



(lib.PhuocSon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(156);
}).prototype = p = new cjs.Sprite();



(lib.PlainofJars = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(157);
}).prototype = p = new cjs.Sprite();



(lib.Pleiku = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(158);
}).prototype = p = new cjs.Sprite();



(lib.PreahVihear = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(159);
}).prototype = p = new cjs.Sprite();



(lib.PuLuong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(160);
}).prototype = p = new cjs.Sprite();



(lib.Pursat = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(161);
}).prototype = p = new cjs.Sprite();



(lib.QuanBa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(162);
}).prototype = p = new cjs.Sprite();



(lib.quanbapngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(163);
}).prototype = p = new cjs.Sprite();



(lib.QuangNgai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(164);
}).prototype = p = new cjs.Sprite();



(lib.QuangTri = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(165);
}).prototype = p = new cjs.Sprite();



(lib.QuangUyen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(166);
}).prototype = p = new cjs.Sprite();



(lib.QuyNhon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(167);
}).prototype = p = new cjs.Sprite();



(lib.RachGia = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(168);
}).prototype = p = new cjs.Sprite();



(lib.Rattanakiri = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(169);
}).prototype = p = new cjs.Sprite();



(lib.SaDec = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(170);
}).prototype = p = new cjs.Sprite();



(lib.Sanamxai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(171);
}).prototype = p = new cjs.Sprite();



(lib.Sapa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(172);
}).prototype = p = new cjs.Sprite();



(lib.Savannakhet = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(173);
}).prototype = p = new cjs.Sprite();



(lib.Sekong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(174);
}).prototype = p = new cjs.Sprite();



(lib.SereiSaophoan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(175);
}).prototype = p = new cjs.Sprite();



(lib.Shape1319copy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(176);
}).prototype = p = new cjs.Sprite();



(lib.Shape1327 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(177);
}).prototype = p = new cjs.Sprite();



(lib.Shape1328 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(178);
}).prototype = p = new cjs.Sprite();



(lib.Shape1477 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(179);
}).prototype = p = new cjs.Sprite();



(lib.Shape1486 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(180);
}).prototype = p = new cjs.Sprite();



(lib.SiemReap = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(181);
}).prototype = p = new cjs.Sprite();



(lib.Sihanoukville = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(182);
}).prototype = p = new cjs.Sprite();



(lib.SinCheng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(183);
}).prototype = p = new cjs.Sprite();



(lib.SinHo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(184);
}).prototype = p = new cjs.Sprite();



(lib.SocTrang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(185);
}).prototype = p = new cjs.Sprite();



(lib.SonHa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(186);
}).prototype = p = new cjs.Sprite();



(lib.SonLa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(187);
}).prototype = p = new cjs.Sprite();



(lib.StungTreng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(188);
}).prototype = p = new cjs.Sprite();



(lib.Takeo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(189);
}).prototype = p = new cjs.Sprite();



(lib.TanAn = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(190);
}).prototype = p = new cjs.Sprite();



(lib.TanTrao = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(191);
}).prototype = p = new cjs.Sprite();



(lib.TanChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(192);
}).prototype = p = new cjs.Sprite();



(lib.TayNinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(193);
}).prototype = p = new cjs.Sprite();



(lib.TayTrang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(194);
}).prototype = p = new cjs.Sprite();



(lib.ThacBa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(195);
}).prototype = p = new cjs.Sprite();



(lib.ThaiNguyen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(196);
}).prototype = p = new cjs.Sprite();



(lib.ThaiBinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(197);
}).prototype = p = new cjs.Sprite();



(lib.thaibinhpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(198);
}).prototype = p = new cjs.Sprite();



(lib.Thakek = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(199);
}).prototype = p = new cjs.Sprite();



(lib.ThanUyen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(200);
}).prototype = p = new cjs.Sprite();



(lib.ThanhHoa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(201);
}).prototype = p = new cjs.Sprite();



(lib.ThatKhe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(202);
}).prototype = p = new cjs.Sprite();



(lib.Thateng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(203);
}).prototype = p = new cjs.Sprite();



(lib.TienYen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(204);
}).prototype = p = new cjs.Sprite();



(lib.TinhBien = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(205);
}).prototype = p = new cjs.Sprite();



(lib.TonléSap = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(206);
}).prototype = p = new cjs.Sprite();



(lib.TraSu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(207);
}).prototype = p = new cjs.Sprite();



(lib.TraVinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(208);
}).prototype = p = new cjs.Sprite();



(lib.TramChim = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(209);
}).prototype = p = new cjs.Sprite();



(lib.TruongSa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(210);
}).prototype = p = new cjs.Sprite();



(lib.TuLe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(211);
}).prototype = p = new cjs.Sprite();



(lib.TuanGiao = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(212);
}).prototype = p = new cjs.Sprite();



(lib.TuyHoa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(213);
}).prototype = p = new cjs.Sprite();



(lib.TuyenQuang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(214);
}).prototype = p = new cjs.Sprite();



(lib.VangVieng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(215);
}).prototype = p = new cjs.Sprite();



(lib.Vientiane = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(216);
}).prototype = p = new cjs.Sprite();



(lib.VinhLong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(217);
}).prototype = p = new cjs.Sprite();



(lib.VinhMocTunnels = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(218);
}).prototype = p = new cjs.Sprite();



(lib.VinhPhuc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(219);
}).prototype = p = new cjs.Sprite();



(lib.Vinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(220);
}).prototype = p = new cjs.Sprite();



(lib.VungTau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(221);
}).prototype = p = new cjs.Sprite();



(lib.WatPhou = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(222);
}).prototype = p = new cjs.Sprite();



(lib.XamNeua = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(223);
}).prototype = p = new cjs.Sprite();



(lib.XinMan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(224);
}).prototype = p = new cjs.Sprite();



(lib.XuanMai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(225);
}).prototype = p = new cjs.Sprite();



(lib.YenMinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(226);
}).prototype = p = new cjs.Sprite();



(lib.YenThuy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(227);
}).prototype = p = new cjs.Sprite();



(lib.îledeKhnong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(228);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MyLai();
	this.instance.parent = this;
	this.instance.setTransform(-23.5,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(-23.5,-12,47,24), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BachMa();
	this.instance.parent = this;
	this.instance.setTransform(-31.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-31.5,-10,63,20), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ALuoi();
	this.instance.parent = this;
	this.instance.setTransform(-23,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-23,-9.5,46,19), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TinhBien();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-34.5,-10,69,20), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TanAn();
	this.instance.parent = this;
	this.instance.setTransform(-25.5,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-25.5,-9.5,51,19), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CatTien();
	this.instance.parent = this;
	this.instance.setTransform(-29,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-29,-9.5,58,19), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BinhChau();
	this.instance.parent = this;
	this.instance.setTransform(-37.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-37.5,-10,75,20), null);


(lib.VN_MuCangChai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuCangChai();
	this.instance.parent = this;
	this.instance.setTransform(-63,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_MuCangChai, new cjs.Rectangle(-63,-13,125,31), null);


(lib.VN_DongKhe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongKhe();
	this.instance.parent = this;
	this.instance.setTransform(-51,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_DongKhe, new cjs.Rectangle(-51,-17,71,25), null);


(lib.VN_DienBienPhu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DBienPhu();
	this.instance.parent = this;
	this.instance.setTransform(-57.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_DienBienPhu, new cjs.Rectangle(-57.5,-13.5,115,28), null);


(lib.VN_CocLy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.coclypngcopy();
	this.instance.parent = this;
	this.instance.setTransform(30,1);

	this.instance_1 = new lib.CocLy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-19,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CocLy, new cjs.Rectangle(-19,-12,68,104), null);


(lib.VN_CatBa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CatBa();
	this.instance.parent = this;
	this.instance.setTransform(-33.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CatBa, new cjs.Rectangle(-33.5,-12.5,67,27), null);


(lib.VN_CaoSon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.caosonpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(36,5);

	this.instance_1 = new lib.CaoSon();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-28,-7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CaoSon, new cjs.Rectangle(-28,-7,204,85), null);


(lib.VN_CaoBang = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.caobangpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-93,2);

	this.instance_1 = new lib.CaoBang();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-54,-9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CaoBang, new cjs.Rectangle(-93,-9,140,117), null);


(lib.VN_CanCau = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Shape1327();
	this.instance.parent = this;
	this.instance.setTransform(64,-36);

	this.instance_1 = new lib.CanCau();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28,-63);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CanCau, new cjs.Rectangle(28,-63,63,187), null);


(lib.VN_BinhLu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BinhLu();
	this.instance.parent = this;
	this.instance.setTransform(-39,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BinhLu, new cjs.Rectangle(-39,-13.5,68,24), null);


(lib.VN_BaoLac = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BaoLac();
	this.instance.parent = this;
	this.instance.setTransform(-40.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BaoLac, new cjs.Rectangle(-40.5,-12.5,82,26), null);


(lib.VN_BanGioc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BanGioc();
	this.instance.parent = this;
	this.instance.setTransform(-49,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BanGioc, new cjs.Rectangle(-49,-15,93,28), null);


(lib.VN_BaKhe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bakhe();
	this.instance.parent = this;
	this.instance.setTransform(-35.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BaKhe, new cjs.Rectangle(-35.5,-13.5,50,20), null);


(lib.VN_BacSon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacSon();
	this.instance.parent = this;
	this.instance.setTransform(-41,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacSon, new cjs.Rectangle(-41,-12.5,82,27), null);


(lib.VN_BacNinh = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacNinh();
	this.instance.parent = this;
	this.instance.setTransform(-47,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacNinh, new cjs.Rectangle(-47,-13.5,94,28), null);


(lib.VN_BacMe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacMe();
	this.instance.parent = this;
	this.instance.setTransform(-38,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacMe, new cjs.Rectangle(-38,-12.5,53,19), null);


(lib.VN_BacHa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacHa();
	this.instance.parent = this;
	this.instance.setTransform(-28,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacHa, new cjs.Rectangle(-28,-7,73,26), null);


(lib.VN_BacGiang = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacGiang();
	this.instance.parent = this;
	this.instance.setTransform(-52.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacGiang, new cjs.Rectangle(-52.5,-16.5,72,24), null);


(lib.Symbol123 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Oudomxai();
	this.instance.parent = this;
	this.instance.setTransform(-55.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol123, new cjs.Rectangle(-55.5,-13.5,111,28), null);


(lib.Symbol122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DuGia();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol122, new cjs.Rectangle(-34.5,-13,49,19), null);


(lib.Symbol120 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Sihanoukville();
	this.instance.parent = this;
	this.instance.setTransform(-70.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol120, new cjs.Rectangle(-70.5,-13.5,141,28), null);


(lib.Symbol119 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.kepcambodge();
	this.instance.parent = this;
	this.instance.setTransform(4,-49);

	this.instance_1 = new lib.Kep();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-19.5,-16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol119, new cjs.Rectangle(-19.5,-49,62.5,67), null);


(lib.Symbol118 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Shape1319copy();
	this.instance.parent = this;
	this.instance.setTransform(83,-63);

	this.instance_1 = new lib.KrongKampot();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-77,-17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol118, new cjs.Rectangle(-77,-63,208,80), null);


(lib.Symbol117 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TonléSap();
	this.instance.parent = this;
	this.instance.setTransform(-52,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol117, new cjs.Rectangle(-52,-17,104,36), null);


(lib.Symbol116 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhnomPenh();
	this.instance.parent = this;
	this.instance.setTransform(-68,-14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol116, new cjs.Rectangle(-68,-14,136,28), null);


(lib.Symbol115 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KompongChhnang();
	this.instance.parent = this;
	this.instance.setTransform(-146,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol115, new cjs.Rectangle(-146,-24,206,36), null);


(lib.Symbol114 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Pursat();
	this.instance.parent = this;
	this.instance.setTransform(-34,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol114, new cjs.Rectangle(-34,-12.5,69,26), null);


(lib.Symbol113 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Battambang();
	this.instance.parent = this;
	this.instance.setTransform(-65.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol113, new cjs.Rectangle(-65.5,-17,133,36), null);


(lib.Symbol112 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KohTrong();
	this.instance.parent = this;
	this.instance.setTransform(-52,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol112, new cjs.Rectangle(-52,-17,104,36), null);


(lib.Symbol111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KompongCham();
	this.instance.parent = this;
	this.instance.setTransform(-47,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol111, new cjs.Rectangle(-47,-21,172,36), null);


(lib.Symbol110 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Kratie();
	this.instance.parent = this;
	this.instance.setTransform(-31,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol110, new cjs.Rectangle(-31,-13,62,28), null);


(lib.Symbol109 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Mondulkiri();
	this.instance.parent = this;
	this.instance.setTransform(-57,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol109, new cjs.Rectangle(-57,-13.5,114,28), null);


(lib.Symbol108 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rattanakiri();
	this.instance.parent = this;
	this.instance.setTransform(-58,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol108, new cjs.Rectangle(-58,-13.5,116,28), null);


(lib.Symbol107 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BanLung();
	this.instance.parent = this;
	this.instance.setTransform(-49.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol107, new cjs.Rectangle(-49.5,-16,100,34), null);


(lib.Symbol106 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.StungTreng();
	this.instance.parent = this;
	this.instance.setTransform(-64,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol106, new cjs.Rectangle(-64,-16,129,35), null);


(lib.Symbol105 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KompongThom();
	this.instance.parent = this;
	this.instance.setTransform(-18,-6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol105, new cjs.Rectangle(-18,-6,171,36), null);


(lib.Symbol104 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SiemReap();
	this.instance.parent = this;
	this.instance.setTransform(-55.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol104, new cjs.Rectangle(-55.5,-16.5,116,36), null);


(lib.Symbol103 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SereiSaophoan();
	this.instance.parent = this;
	this.instance.setTransform(-53,-31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol103, new cjs.Rectangle(-53,-31,108,66), null);


(lib.Symbol102 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KrongPoiPet();
	this.instance.parent = this;
	this.instance.setTransform(-102,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol102, new cjs.Rectangle(-102,-15,142,36), null);


(lib.Symbol101 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Kohker();
	this.instance.parent = this;
	this.instance.setTransform(-38,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol101, new cjs.Rectangle(-38,-13.5,77,28), null);


(lib.Symbol100 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PreahVihear();
	this.instance.parent = this;
	this.instance.setTransform(-68.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol100, new cjs.Rectangle(-68.5,-13.5,137,28), null);


(lib.Symbol99 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.îledeKhnong();
	this.instance.parent = this;
	this.instance.setTransform(-22,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol99, new cjs.Rectangle(-22,-23,148,36), null);


(lib.Symbol98 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Champassak();
	this.instance.parent = this;
	this.instance.setTransform(-68.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol98, new cjs.Rectangle(-68.5,-17,139,36), null);


(lib.Symbol97 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BanKhietNgong();
	this.instance.parent = this;
	this.instance.setTransform(-89,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol97, new cjs.Rectangle(-89,-17,123,25), null);


(lib.Symbol96 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DonDeang();
	this.instance.parent = this;
	this.instance.setTransform(-41,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol96, new cjs.Rectangle(-41,-12,82,24), null);


(lib.Symbol95 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.WatPhou();
	this.instance.parent = this;
	this.instance.setTransform(-51.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol95, new cjs.Rectangle(-51.5,-13.5,105,28), null);


(lib.Symbol94 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Attapeu();
	this.instance.parent = this;
	this.instance.setTransform(-43,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol94, new cjs.Rectangle(-43,-16,86,34), null);


(lib.Symbol93 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Paksé();
	this.instance.parent = this;
	this.instance.setTransform(-30.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol93, new cjs.Rectangle(-30.5,-13.5,62,28), null);


(lib.Symbol92 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Thateng();
	this.instance.parent = this;
	this.instance.setTransform(-44.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol92, new cjs.Rectangle(-44.5,-17,61,25), null);


(lib.Symbol91 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Laongam();
	this.instance.parent = this;
	this.instance.setTransform(-48.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol91, new cjs.Rectangle(-48.5,-16,69,24), null);


(lib.Symbol90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Savannakhet();
	this.instance.parent = this;
	this.instance.setTransform(-69.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol90, new cjs.Rectangle(-69.5,-13.5,140,28), null);


(lib.Symbol89 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Thakek();
	this.instance.parent = this;
	this.instance.setTransform(-39.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol89, new cjs.Rectangle(-39.5,-13.5,80,28), null);


(lib.Symbol88 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Kenethao();
	this.instance.parent = this;
	this.instance.setTransform(-51,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol88, new cjs.Rectangle(-51,-13.5,102,28), null);


(lib.Symbol87 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.XamNeua();
	this.instance.parent = this;
	this.instance.setTransform(-55.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol87, new cjs.Rectangle(-55.5,-12.5,113,26), null);


(lib.Symbol86 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Hongsa();
	this.instance.parent = this;
	this.instance.setTransform(-39,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol86, new cjs.Rectangle(-39,-16,80,34), null);


(lib.Symbol85 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Vientiane();
	this.instance.parent = this;
	this.instance.setTransform(-50.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol85, new cjs.Rectangle(-50.5,-13,107,28), null);


(lib.Symbol84 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PlainofJars();
	this.instance.parent = this;
	this.instance.setTransform(-61.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol84, new cjs.Rectangle(-61.5,-16.5,122,34), null);


(lib.Symbol83 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NamCan();
	this.instance.parent = this;
	this.instance.setTransform(-48,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol83, new cjs.Rectangle(-48,-12.5,67,19), null);


(lib.Symbol82 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuangKham();
	this.instance.parent = this;
	this.instance.setTransform(-70.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol82, new cjs.Rectangle(-70.5,-17,143,36), null);


(lib.Symbol81 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Phonxavan();
	this.instance.parent = this;
	this.instance.setTransform(-58.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol81, new cjs.Rectangle(-58.5,-13.5,119,28), null);


(lib.Symbol80 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VangVieng();
	this.instance.parent = this;
	this.instance.setTransform(-59.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol80, new cjs.Rectangle(-59.5,-16.5,120,36), null);


(lib.Symbol79 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Pakxan();
	this.instance.parent = this;
	this.instance.setTransform(-38,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol79, new cjs.Rectangle(-38,-13.5,77,28), null);


(lib.Symbol78 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NamNgum();
	this.instance.parent = this;
	this.instance.setTransform(-60.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol78, new cjs.Rectangle(-60.5,-16,123,34), null);


(lib.Symbol77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Houixai();
	this.instance.parent = this;
	this.instance.setTransform(-59,4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol77, new cjs.Rectangle(-59,4,79,28), null);


(lib.Symbol76 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LuangPrabang();
	this.instance.parent = this;
	this.instance.setTransform(-80,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol76, new cjs.Rectangle(-80,-17,166,36), null);


(lib.Symbol75 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NongKhiaw();
	this.instance.parent = this;
	this.instance.setTransform(-64,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol75, new cjs.Rectangle(-64,-17,129,36), null);


(lib.Symbol74 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuangNgoy();
	this.instance.parent = this;
	this.instance.setTransform(-67.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol74, new cjs.Rectangle(-67.5,-16,137,34), null);


(lib.Symbol73 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuongKhua();
	this.instance.parent = this;
	this.instance.setTransform(-66.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol73, new cjs.Rectangle(-66.5,-17,135,36), null);


(lib.Symbol72 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LuangNamtha();
	this.instance.parent = this;
	this.instance.setTransform(-78.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol72, new cjs.Rectangle(-78.5,-17,158,36), null);


(lib.Symbol71 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuangSing();
	this.instance.parent = this;
	this.instance.setTransform(-61.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol71, new cjs.Rectangle(-61.5,-16.5,125,36), null);


(lib.Symbol70 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Phongsali();
	this.instance.parent = this;
	this.instance.setTransform(-50.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol70, new cjs.Rectangle(-50.5,-17,101,36), null);


(lib.Symbol68 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhuQuoc();
	this.instance.parent = this;
	this.instance.setTransform(-51.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol68, new cjs.Rectangle(-51.5,-16,103,33), null);


(lib.Symbol67 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Takeo();
	this.instance.parent = this;
	this.instance.setTransform(-32,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol67, new cjs.Rectangle(-32,-13.5,66,28), null);


(lib.Symbol66 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ChauDoc();
	this.instance.parent = this;
	this.instance.setTransform(-50.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol66, new cjs.Rectangle(-50.5,-13.5,102,28), null);


(lib.Symbol65 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TruongSa();
	this.instance.parent = this;
	this.instance.setTransform(-50.5,-38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol65, new cjs.Rectangle(-50.5,-38.5,99,77), null);


(lib.Symbol64 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ConDao();
	this.instance.parent = this;
	this.instance.setTransform(-44.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol64, new cjs.Rectangle(-44.5,-12.5,90,27), null);


(lib.Symbol63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CaMau();
	this.instance.parent = this;
	this.instance.setTransform(-39.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol63, new cjs.Rectangle(-39.5,-12.5,79,27), null);


(lib.Symbol62 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.RachGia();
	this.instance.parent = this;
	this.instance.setTransform(-61,-14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol62, new cjs.Rectangle(-61,-14,91,28), null);


(lib.Symbol61 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TraSu();
	this.instance.parent = this;
	this.instance.setTransform(-33,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol61, new cjs.Rectangle(-33,-12.5,46,19), null);


(lib.Symbol60 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaTien();
	this.instance.parent = this;
	this.instance.setTransform(-39,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol60, new cjs.Rectangle(-39,-13,79,28), null);


(lib.Symbol59 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BangLang();
	this.instance.parent = this;
	this.instance.setTransform(-55,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol59, new cjs.Rectangle(-55,-16,77,24), null);


(lib.Symbol58 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CanTho();
	this.instance.parent = this;
	this.instance.setTransform(-43,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol58, new cjs.Rectangle(-43,-13.5,86,28), null);


(lib.Symbol57 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacLieu();
	this.instance.parent = this;
	this.instance.setTransform(-43,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol57, new cjs.Rectangle(-43,-13,86,28), null);


(lib.Symbol56 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SocTrang();
	this.instance.parent = this;
	this.instance.setTransform(-51.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol56, new cjs.Rectangle(-51.5,-16,104,35), null);


(lib.Symbol55 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TraVinh();
	this.instance.parent = this;
	this.instance.setTransform(-44,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol55, new cjs.Rectangle(-44,-13.5,89,28), null);


(lib.Symbol54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VinhLong();
	this.instance.parent = this;
	this.instance.setTransform(-53.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol54, new cjs.Rectangle(-53.5,-17,107,36), null);


(lib.Symbol53 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CaiBe();
	this.instance.parent = this;
	this.instance.setTransform(-32.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol53, new cjs.Rectangle(-32.5,-13,65,28), null);


(lib.Symbol52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BenTre();
	this.instance.parent = this;
	this.instance.setTransform(-40,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol52, new cjs.Rectangle(-40,-12.5,81,26), null);


(lib.Symbol51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VungTau();
	this.instance.parent = this;
	this.instance.setTransform(-49.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol51, new cjs.Rectangle(-49.5,-16,100,34), null);


(lib.Symbol50 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MyTho();
	this.instance.parent = this;
	this.instance.setTransform(-38.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol50, new cjs.Rectangle(-38.5,-17,78,36), null);


(lib.Symbol49copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CaiLay();
	this.instance.parent = this;
	this.instance.setTransform(-37.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol49copy, new cjs.Rectangle(-37.5,-16.5,76,36), null);


(lib.Symbol49 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThacBa();
	this.instance.parent = this;
	this.instance.setTransform(-41.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol49, new cjs.Rectangle(-41.5,-13.5,84,28), null);


(lib.Symbol48copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SaDec();
	this.instance.parent = this;
	this.instance.setTransform(-35,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol48copy, new cjs.Rectangle(-35,-12.5,61,23), null);


(lib.Symbol48 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TayTrang();
	this.instance.parent = this;
	this.instance.setTransform(-53,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol48, new cjs.Rectangle(-53,-16,90,30), null);


(lib.Symbol47copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LongXuyen();
	this.instance.parent = this;
	this.instance.setTransform(-43,-42);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol47copy, new cjs.Rectangle(-43,-42,58,60), null);


(lib.Symbol47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThaiNguyen();
	this.instance.parent = this;
	this.instance.setTransform(-40.5,-26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol47, new cjs.Rectangle(-40.5,-26.5,56,44), null);


(lib.Symbol46copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MocBai();
	this.instance.parent = this;
	this.instance.setTransform(-41,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol46copy, new cjs.Rectangle(-41,-13,71,24), null);


(lib.Symbol45copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CuChi();
	this.instance.parent = this;
	this.instance.setTransform(-33.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol45copy, new cjs.Rectangle(-33.5,-13.5,67,28), null);


(lib.Symbol45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Shape1486();
	this.instance.parent = this;
	this.instance.setTransform(-15,5);

	this.instance_1 = new lib.YenMinh();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-53,-17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol45, new cjs.Rectangle(-53,-17,70,51), null);


(lib.Symbol44copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HoChiMinhCity();
	this.instance.parent = this;
	this.instance.setTransform(-23,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol44copy, new cjs.Rectangle(-23,-16,183,36), null);


(lib.Symbol44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.XinMan();
	this.instance.parent = this;
	this.instance.setTransform(-44,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol44, new cjs.Rectangle(-44,-13,71,22), null);


(lib.Symbol43copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TayNinh();
	this.instance.parent = this;
	this.instance.setTransform(-47.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol43copy, new cjs.Rectangle(-47.5,-17,95,36), null);


(lib.Symbol43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VinhPhuc();
	this.instance.parent = this;
	this.instance.setTransform(-53.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol43, new cjs.Rectangle(-53.5,-13.5,74,20), null);


(lib.Symbol42copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongXoai();
	this.instance.parent = this;
	this.instance.setTransform(-53,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42copy, new cjs.Rectangle(-53,-16.5,74,24), null);


(lib.Symbol42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TuyenQuang();
	this.instance.parent = this;
	this.instance.setTransform(-77,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42, new cjs.Rectangle(-77,-16,100,24), null);


(lib.Symbol41copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongNai();
	this.instance.parent = this;
	this.instance.setTransform(-48.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol41copy, new cjs.Rectangle(-48.5,-16.5,97,36), null);


(lib.Symbol41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TuanGiao();
	this.instance.parent = this;
	this.instance.setTransform(-54.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol41, new cjs.Rectangle(-54.5,-13,109,28), null);


(lib.Symbol40copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BaoLoc();
	this.instance.parent = this;
	this.instance.setTransform(-41,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol40copy, new cjs.Rectangle(-41,-12.5,57,19), null);


(lib.Symbol40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TienYen();
	this.instance.parent = this;
	this.instance.setTransform(-45.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol40, new cjs.Rectangle(-45.5,-13,63,19), null);


(lib.Symbol39copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.GiaNghia();
	this.instance.parent = this;
	this.instance.setTransform(-51,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol39copy, new cjs.Rectangle(-51,-17,71,25), null);


(lib.Symbol39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThatKhe();
	this.instance.parent = this;
	this.instance.setTransform(-47.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol39, new cjs.Rectangle(-47.5,-13.5,67,20), null);


(lib.Symbol38copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhanThiet();
	this.instance.parent = this;
	this.instance.setTransform(-56.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol38copy, new cjs.Rectangle(-56.5,-13.5,113,28), null);


(lib.Symbol38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThanhHoa();
	this.instance.parent = this;
	this.instance.setTransform(-58.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol38, new cjs.Rectangle(-58.5,-13.5,82,20), null);


(lib.Symbol37copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuiNe();
	this.instance.parent = this;
	this.instance.setTransform(-37.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol37copy, new cjs.Rectangle(-37.5,-13,76,28), null);


(lib.Symbol37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThanUyen();
	this.instance.parent = this;
	this.instance.setTransform(-57,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol37, new cjs.Rectangle(-57,-17,116,36), null);


(lib.Symbol36copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NinhGia();
	this.instance.parent = this;
	this.instance.setTransform(-45.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol36copy, new cjs.Rectangle(-45.5,-13.5,63,20), null);


(lib.Symbol36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.thaibinhpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-89,-39);

	this.instance_1 = new lib.ThaiBinh();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-57,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol36, new cjs.Rectangle(-89,-39,101,48), null);


(lib.Symbol35copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DaLat();
	this.instance.parent = this;
	this.instance.setTransform(-33.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol35copy, new cjs.Rectangle(-33.5,-12.5,56,28), null);


(lib.Symbol35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TanTrao();
	this.instance.parent = this;
	this.instance.setTransform(-47,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol35, new cjs.Rectangle(-47,-12.5,94,26), null);


(lib.Symbol34copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LacLake();
	this.instance.parent = this;
	this.instance.setTransform(-40,-14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol34copy, new cjs.Rectangle(-40,-14,63,20), null);


(lib.Symbol33copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BMeThuot();
	this.instance.parent = this;
	this.instance.setTransform(-61,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol33copy, new cjs.Rectangle(-61,-13.5,122,28), null);


(lib.Symbol33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SonLa();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol33, new cjs.Rectangle(-34.5,-12.5,70,27), null);


(lib.Symbol32copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Pleiku();
	this.instance.parent = this;
	this.instance.setTransform(-31.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol32copy, new cjs.Rectangle(-31.5,-13.5,63,28), null);


(lib.Symbol31copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BoY();
	this.instance.parent = this;
	this.instance.setTransform(-23,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol31copy, new cjs.Rectangle(-23,-12.5,46,26), null);


(lib.Symbol31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SinHo();
	this.instance.parent = this;
	this.instance.setTransform(-11,-8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol31, new cjs.Rectangle(-11,-8,47,19), null);


(lib.Symbol30copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BuonHo();
	this.instance.parent = this;
	this.instance.setTransform(-45.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol30copy, new cjs.Rectangle(-45.5,-12.5,64,19), null);


(lib.Symbol30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Shape1328();
	this.instance.parent = this;
	this.instance.setTransform(-6,29);

	this.instance_1 = new lib.SinCheng();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-83,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol30, new cjs.Rectangle(-83,17,128,132), null);


(lib.Symbol29copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KonTum();
	this.instance.parent = this;
	this.instance.setTransform(-47,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol29copy, new cjs.Rectangle(-47,-12.5,94,26), null);


(lib.Symbol29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Sapa();
	this.instance.parent = this;
	this.instance.setTransform(-25,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol29, new cjs.Rectangle(-25,-16,52,35), null);


(lib.Symbol28copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhanRang();
	this.instance.parent = this;
	this.instance.setTransform(-56.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol28copy, new cjs.Rectangle(-56.5,-17,115,36), null);


(lib.Symbol28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.QuangUyen();
	this.instance.parent = this;
	this.instance.setTransform(-65.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol28, new cjs.Rectangle(-65.5,-16,91,24), null);


(lib.Symbol27copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BinhBa();
	this.instance.parent = this;
	this.instance.setTransform(-40,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol27copy, new cjs.Rectangle(-40,-13.5,80,28), null);


(lib.Symbol27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.quanbapngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-19,8);

	this.instance_1 = new lib.QuanBa();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-51,-13);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol27, new cjs.Rectangle(-51,-13,97,80), null);


(lib.Symbol26copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NhaTrang();
	this.instance.parent = this;
	this.instance.setTransform(-55.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26copy, new cjs.Rectangle(-55.5,-17,111,36), null);


(lib.Symbol26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NghiaLo();
	this.instance.parent = this;
	this.instance.setTransform(-46,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26, new cjs.Rectangle(-46,-17,93,36), null);


(lib.Symbol25copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TuyHoa();
	this.instance.parent = this;
	this.instance.setTransform(-43.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol25copy, new cjs.Rectangle(-43.5,-16,88,34), null);


(lib.Symbol25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PuLuong();
	this.instance.parent = this;
	this.instance.setTransform(-49.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol25, new cjs.Rectangle(-49.5,-16,100,34), null);


(lib.Symbol24copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.QuyNhon();
	this.instance.parent = this;
	this.instance.setTransform(-53.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol24copy, new cjs.Rectangle(-53.5,-17,109,36), null);


(lib.Symbol24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NinhBinhpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-93,-64);

	this.instance_1 = new lib.NinhBinh();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-53,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol24, new cjs.Rectangle(-93,-64,145,79), null);


(lib.Symbol23copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HoangSa();
	this.instance.parent = this;
	this.instance.setTransform(-46.5,-38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol23copy, new cjs.Rectangle(-46.5,-38.5,94,75), null);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhuYen();
	this.instance.parent = this;
	this.instance.setTransform(-42.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol23, new cjs.Rectangle(-42.5,-13.5,60,20), null);


(lib.Symbol22copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhuocSon();
	this.instance.parent = this;
	this.instance.setTransform(-55,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol22copy, new cjs.Rectangle(-55,-13.5,77,20), null);


(lib.Symbol22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhongTho();
	this.instance.parent = this;
	this.instance.setTransform(-32,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol22, new cjs.Rectangle(-32,-7,79,25), null);


(lib.Symbol21copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SonHa();
	this.instance.parent = this;
	this.instance.setTransform(-37,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol21copy, new cjs.Rectangle(-37,-12.5,52,19), null);


(lib.Symbol21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.namdinhpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-102,-49);

	this.instance_1 = new lib.NamDinh();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-56,-11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol21, new cjs.Rectangle(-102,-49,120,58), null);


(lib.Symbol20copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.QuangNgai();
	this.instance.parent = this;
	this.instance.setTransform(-62,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol20copy, new cjs.Rectangle(-62,-16.5,125,36), null);


(lib.Symbol20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuongLay();
	this.instance.parent = this;
	this.instance.setTransform(-58.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol20, new cjs.Rectangle(-58.5,-16,118,34), null);


(lib.Symbol19copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LySon();
	this.instance.parent = this;
	this.instance.setTransform(-33.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19copy2, new cjs.Rectangle(-33.5,-16,68,35), null);


(lib.Symbol19copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.muonghumpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(30,8);

	this.instance_1 = new lib.MuongHum();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-28,-19);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19copy, new cjs.Rectangle(-28,-19,123,77), null);


(lib.Symbol18copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CuLaoCham();
	this.instance.parent = this;
	this.instance.setTransform(-54,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18copy2, new cjs.Rectangle(-54,-10,140,28), null);


(lib.Symbol18copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MongCai();
	this.instance.parent = this;
	this.instance.setTransform(-48.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18copy, new cjs.Rectangle(-48.5,-16.5,68,24), null);


(lib.Symbol17copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MocChau();
	this.instance.parent = this;
	this.instance.setTransform(-52,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17copy, new cjs.Rectangle(-52,-13.5,105,28), null);


(lib.Symbol16copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NamGiang();
	this.instance.parent = this;
	this.instance.setTransform(-59,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol16copy2, new cjs.Rectangle(-59,-16.5,83,24), null);


(lib.Symbol16copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MeoVac();
	this.instance.parent = this;
	this.instance.setTransform(-47,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol16copy, new cjs.Rectangle(-47,-13,90,26), null);


(lib.Symbol15copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongGiang();
	this.instance.parent = this;
	this.instance.setTransform(-61.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol15copy2, new cjs.Rectangle(-61.5,-16.5,85,24), null);


(lib.Symbol15copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MaiChau();
	this.instance.parent = this;
	this.instance.setTransform(-23,-11);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol15copy, new cjs.Rectangle(-23,-11,99,28), null);


(lib.Symbol14copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ARoang();
	this.instance.parent = this;
	this.instance.setTransform(-44,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14copy2, new cjs.Rectangle(-44,-16,62,24), null);


(lib.Symbol14copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LungCu();
	this.instance.parent = this;
	this.instance.setTransform(-42,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14copy, new cjs.Rectangle(-42,-16,85,35), null);


(lib.Symbol13copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HoiAn();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol13copy2, new cjs.Rectangle(-34.5,-13,62,28), null);


(lib.Symbol13copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.laocaipngcopy();
	this.instance.parent = this;
	this.instance.setTransform(62,13);

	this.instance_1 = new lib.LaoCai();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-16,-9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol13copy, new cjs.Rectangle(-16,-9,107,57), null);


(lib.Symbol12copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Danang();
	this.instance.parent = this;
	this.instance.setTransform(-49,-11);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12copy2, new cjs.Rectangle(-49,-11,85,34), null);


(lib.Symbol12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LangSon();
	this.instance.parent = this;
	this.instance.setTransform(-47,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12copy, new cjs.Rectangle(-47,-16,96,35), null);


(lib.Symbol11copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MySon();
	this.instance.parent = this;
	this.instance.setTransform(-38,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11copy2, new cjs.Rectangle(-38,-16,77,35), null);


(lib.Symbol11copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LaiChau();
	this.instance.parent = this;
	this.instance.setTransform(-22,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11copy, new cjs.Rectangle(-22,-10,90,28), null);


(lib.Symbol10copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KheXanh();
	this.instance.parent = this;
	this.instance.setTransform(-50,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10copy2, new cjs.Rectangle(-50,-13.5,100,28), null);


(lib.Symbol10copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LungKhauNhinpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-95,-8);

	this.instance_1 = new lib.lungkhaunhin();
	this.instance_1.parent = this;
	this.instance_1.setTransform(31,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10copy, new cjs.Rectangle(-95,-8,259,100), null);


(lib.Symbol9copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhongNha();
	this.instance.parent = this;
	this.instance.setTransform(-58,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9copy2, new cjs.Rectangle(-58,-17,117,36), null);


(lib.Symbol9copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HoaBinh();
	this.instance.parent = this;
	this.instance.setTransform(-46,-14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9copy, new cjs.Rectangle(-46,-14,97,28), null);


(lib.Symbol8copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CauTreo();
	this.instance.parent = this;
	this.instance.setTransform(-47,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8copy3, new cjs.Rectangle(-47,-12.5,95,27), null);


(lib.Symbol8copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HANOI();
	this.instance.parent = this;
	this.instance.setTransform(-37,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8copy2, new cjs.Rectangle(-37,-12.5,86,27), null);


(lib.Symbol7copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Hue();
	this.instance.parent = this;
	this.instance.setTransform(-21,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7copy4, new cjs.Rectangle(-21,-12.5,44,26), null);


(lib.Symbol7copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaiPhong();
	this.instance.parent = this;
	this.instance.setTransform(-54,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7copy3, new cjs.Rectangle(-54,-17,109,36), null);


(lib.Symbol6copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.QuangTri();
	this.instance.parent = this;
	this.instance.setTransform(-51.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6copy3, new cjs.Rectangle(-51.5,-16.5,103,36), null);


(lib.Symbol6copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaLong();
	this.instance.parent = this;
	this.instance.setTransform(-43,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6copy2, new cjs.Rectangle(-43,-16,76,36), null);


(lib.Symbol5copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VinhMocTunnels();
	this.instance.parent = this;
	this.instance.setTransform(-95,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5copy3, new cjs.Rectangle(-95,-13.5,190,28), null);


(lib.Symbol5copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaGiang();
	this.instance.parent = this;
	this.instance.setTransform(-48,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5copy2, new cjs.Rectangle(-48,-16.5,97,36), null);


(lib.Symbol4copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongHoi();
	this.instance.parent = this;
	this.instance.setTransform(-68,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4copy4, new cjs.Rectangle(-68,-17,97,36), null);


(lib.Symbol4copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HSuPhi();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4copy3, new cjs.Rectangle(0,0,73,23), null);


(lib.Symbol4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.imgdot();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-7,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4_1, new cjs.Rectangle(-7,-7,14,14), null);


(lib.Symbol3copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaTinh();
	this.instance.parent = this;
	this.instance.setTransform(-40,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3copy3, new cjs.Rectangle(-40,-13.5,55,20), null);


(lib.Symbol3copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DuongLam();
	this.instance.parent = this;
	this.instance.setTransform(-60.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3copy2, new cjs.Rectangle(-60.5,-16,85,24), null);


(lib.Symbol3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.CachedTexturedBitmap_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.6574,0.6574);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3_1, new cjs.Rectangle(0,0,28.3,28.3), null);


(lib.Symbol2copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PakBeng();
	this.instance.parent = this;
	this.instance.setTransform(-35.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy4, new cjs.Rectangle(-35.5,-12.5,99,36), null);


(lib.Symbol2copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Vinh();
	this.instance.parent = this;
	this.instance.setTransform(-24,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy3, new cjs.Rectangle(-24,-13,34,20), null);


(lib.Symbol2copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.dongvanpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-100,0);

	this.instance_1 = new lib.DongVan();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-52,-9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy2, new cjs.Rectangle(-100,-9,150,47), null);


(lib.Symbol2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaNoiDongHoi();
	this.instance.parent = this;
	this.instance.setTransform(310,305,0.9418,0.9418);

	this.instance_1 = new lib.ghichucacphuongtien();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy, new cjs.Rectangle(0,0,367,367), null);


(lib.Symbol2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.CachedTexturedBitmap_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.8,-2.8,0.8725,0.8725);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2_1, new cjs.Rectangle(-2.8,-2.8,34.1,34.1), null);


(lib.Symbol1copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.XuanMai();
	this.instance.parent = this;
	this.instance.setTransform(-29,-8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy6, new cjs.Rectangle(-29,-8,70,19), null);


(lib.Symbol1copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BaBe();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy3, new cjs.Rectangle(0,0,59,26), null);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TramChim();
	this.instance.parent = this;
	this.instance.setTransform(-39,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(-39,-10,78,20), null);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TanChau();
	this.instance.parent = this;
	this.instance.setTransform(-33,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(-33,-10,66,20), null);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CaoLanh();
	this.instance.parent = this;
	this.instance.setTransform(-34,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(-34,-10,68,20), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DraySap();
	this.instance.parent = this;
	this.instance.setTransform(-32.5,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(-32.5,-12,65,24), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BuonDon();
	this.instance.parent = this;
	this.instance.setTransform(-36.5,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-36.5,-9.5,73,19), null);


(lib.Symbol7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Sanamxai();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-36.5,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7_1, new cjs.Rectangle(-36.5,-9.5,73,19), null);


(lib.Symbol6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Paksong();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-31,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6_1, new cjs.Rectangle(-31,-12.5,62,25), null);


(lib.Symbol5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Sekong();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-27.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5_1, new cjs.Rectangle(-27.5,-12.5,55,25), null);


(lib.Symbol4_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.YenThuy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-34.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4_2, new cjs.Rectangle(-34.5,-12.5,69,25), null);


(lib.Symbol3copy2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.BacKan();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-29,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3copy2_1, new cjs.Rectangle(-29,-9.5,58,19), null);


(lib.Symbol3copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DinhLap();
	this.instance.parent = this;
	this.instance.setTransform(-32.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3copy, new cjs.Rectangle(-32.5,-12.5,65,25), null);


(lib.Symbol2copy_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.Bitmap1copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-35,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy_1, new cjs.Rectangle(-35,-12.5,70,25), null);


(lib.Symbol2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.TuLe();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-20,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2_2, new cjs.Rectangle(-20,-9.5,40,19), null);


(lib.Symbol1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacQuang();
	this.instance.parent = this;
	this.instance.setTransform(-40,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy, new cjs.Rectangle(-40,-12,80,24), null);


(lib.Symbol1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Shape1477();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2,-45);

	this.instance_2 = new lib.GotFerry();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-34.5,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1_1, new cjs.Rectangle(-34.5,-45,69,57), null);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol2copy();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.36,0.36);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19, new cjs.Rectangle(0,0,132.1,132.1), null);


(lib.Symbol8copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.VN_MyLai = new lib.Symbol7();
	this.VN_MyLai.name = "VN_MyLai";
	this.VN_MyLai.parent = this;
	this.VN_MyLai.setTransform(1658.5,1596);

	this.VN_BachMa = new lib.Symbol6();
	this.VN_BachMa.name = "VN_BachMa";
	this.VN_BachMa.parent = this;
	this.VN_BachMa.setTransform(1454.5,1364);

	this.VN_ALuoi = new lib.Symbol5();
	this.VN_ALuoi.name = "VN_ALuoi";
	this.VN_ALuoi.parent = this;
	this.VN_ALuoi.setTransform(1307,1336.5);

	this.VN_TinhBien = new lib.Symbol4();
	this.VN_TinhBien.name = "VN_TinhBien";
	this.VN_TinhBien.parent = this;
	this.VN_TinhBien.setTransform(837.5,2402);

	this.VN_TanAn = new lib.Symbol3();
	this.VN_TanAn.name = "VN_TanAn";
	this.VN_TanAn.parent = this;
	this.VN_TanAn.setTransform(1189.5,2384.5);

	this.VN_CatTien = new lib.Symbol2();
	this.VN_CatTien.name = "VN_CatTien";
	this.VN_CatTien.parent = this;
	this.VN_CatTien.setTransform(1344,2192.5);

	this.VN_BinhChau = new lib.Symbol1();
	this.VN_BinhChau.name = "VN_BinhChau";
	this.VN_BinhChau.parent = this;
	this.VN_BinhChau.setTransform(1389.5,2376.3);

	this.VN_BacKan = new lib.Symbol3copy2_1();
	this.VN_BacKan.name = "VN_BacKan";
	this.VN_BacKan.parent = this;
	this.VN_BacKan.setTransform(1100,270.5);

	this.VN_PhoRang = new lib.Symbol2copy_1();
	this.VN_PhoRang.name = "VN_PhoRang";
	this.VN_PhoRang.parent = this;
	this.VN_PhoRang.setTransform(867,274.5);

	this.VN_BacQuang = new lib.Symbol1copy();
	this.VN_BacQuang.name = "VN_BacQuang";
	this.VN_BacQuang.parent = this;
	this.VN_BacQuang.setTransform(926.4,236);

	this.VN_TramChim = new lib.Symbol12();
	this.VN_TramChim.name = "VN_TramChim";
	this.VN_TramChim.parent = this;
	this.VN_TramChim.setTransform(1037,2361);

	this.VN_TanChau = new lib.Symbol11();
	this.VN_TanChau.name = "VN_TanChau";
	this.VN_TanChau.parent = this;
	this.VN_TanChau.setTransform(956,2343);

	this.VN_CaoLanh = new lib.Symbol10();
	this.VN_CaoLanh.name = "VN_CaoLanh";
	this.VN_CaoLanh.parent = this;
	this.VN_CaoLanh.setTransform(1042,2391);

	this.VN_DraySap = new lib.Symbol9();
	this.VN_DraySap.name = "VN_DraySap";
	this.VN_DraySap.parent = this;
	this.VN_DraySap.setTransform(1413.5,1991);

	this.VN_BuonDon = new lib.Symbol8();
	this.VN_BuonDon.name = "VN_BuonDon";
	this.VN_BuonDon.parent = this;
	this.VN_BuonDon.setTransform(1405.5,1945.5);

	this.LA_Sanamxai = new lib.Symbol7_1();
	this.LA_Sanamxai.name = "LA_Sanamxai";
	this.LA_Sanamxai.parent = this;
	this.LA_Sanamxai.setTransform(1186.5,1637.5);

	this.LA_Paksong = new lib.Symbol6_1();
	this.LA_Paksong.name = "LA_Paksong";
	this.LA_Paksong.parent = this;
	this.LA_Paksong.setTransform(1150,1441.5);

	this.LA_Sekong = new lib.Symbol5_1();
	this.LA_Sekong.name = "LA_Sekong";
	this.LA_Sekong.parent = this;
	this.LA_Sekong.setTransform(1273.5,1426.5);

	this.VN_YenThuy = new lib.Symbol4_2();
	this.VN_YenThuy.name = "VN_YenThuy";
	this.VN_YenThuy.parent = this;
	this.VN_YenThuy.setTransform(1027.5,619.5);

	this.VN_DinhLap = new lib.Symbol3copy();
	this.VN_DinhLap.name = "VN_DinhLap";
	this.VN_DinhLap.parent = this;
	this.VN_DinhLap.setTransform(1316.5,372.5);

	this.VN_TuLe = new lib.Symbol2_2();
	this.VN_TuLe.name = "VN_TuLe";
	this.VN_TuLe.parent = this;
	this.VN_TuLe.setTransform(828,385.5);

	this.VN_GotFerry = new lib.Symbol1_1();
	this.VN_GotFerry.name = "VN_GotFerry";
	this.VN_GotFerry.parent = this;
	this.VN_GotFerry.setTransform(1256.5,592);

	this.LA_PakBeng = new lib.Symbol2copy4();
	this.LA_PakBeng.name = "LA_PakBeng";
	this.LA_PakBeng.parent = this;
	this.LA_PakBeng.setTransform(145.5,647.5);

	this.VN_XuanMai = new lib.Symbol1copy6();
	this.VN_XuanMai.name = "VN_XuanMai";
	this.VN_XuanMai.parent = this;
	this.VN_XuanMai.setTransform(1066.4,524);

	this.LA_Oudomxai = new lib.Symbol123();
	this.LA_Oudomxai.name = "LA_Oudomxai";
	this.LA_Oudomxai.parent = this;
	this.LA_Oudomxai.setTransform(329.5,585.5);

	this.VN_DuGia = new lib.Symbol122();
	this.VN_DuGia.name = "VN_DuGia";
	this.VN_DuGia.parent = this;
	this.VN_DuGia.setTransform(976,140);

	this.VN_PhuQuoc = new lib.Symbol68();
	this.VN_PhuQuoc.name = "VN_PhuQuoc";
	this.VN_PhuQuoc.parent = this;
	this.VN_PhuQuoc.setTransform(660.9,2551);

	this.KH_Takeo = new lib.Symbol67();
	this.KH_Takeo.name = "KH_Takeo";
	this.KH_Takeo.parent = this;
	this.KH_Takeo.setTransform(844,2293.5);

	this.VN_ChauDoc = new lib.Symbol66();
	this.VN_ChauDoc.name = "VN_ChauDoc";
	this.VN_ChauDoc.parent = this;
	this.VN_ChauDoc.setTransform(844.5,2370.8);

	this.VN_TruongSa = new lib.Symbol65();
	this.VN_TruongSa.name = "VN_TruongSa";
	this.VN_TruongSa.parent = this;
	this.VN_TruongSa.setTransform(1836.5,2629.5);

	this.VN_ConDao = new lib.Symbol64();
	this.VN_ConDao.name = "VN_ConDao";
	this.VN_ConDao.parent = this;
	this.VN_ConDao.setTransform(1340.5,2703.5);

	this.VN_CaMau = new lib.Symbol63();
	this.VN_CaMau.name = "VN_CaMau";
	this.VN_CaMau.parent = this;
	this.VN_CaMau.setTransform(902.5,2699.5);

	this.VN_RachGia = new lib.Symbol62();
	this.VN_RachGia.name = "VN_RachGia";
	this.VN_RachGia.parent = this;
	this.VN_RachGia.setTransform(862,2500.5);

	this.VN_TraSu = new lib.Symbol61();
	this.VN_TraSu.name = "VN_TraSu";
	this.VN_TraSu.parent = this;
	this.VN_TraSu.setTransform(924.5,2430.5);

	this.VN_HaTien = new lib.Symbol60();
	this.VN_HaTien.name = "VN_HaTien";
	this.VN_HaTien.parent = this;
	this.VN_HaTien.setTransform(806.5,2457);

	this.VN_BangLang = new lib.Symbol59();
	this.VN_BangLang.name = "VN_BangLang";
	this.VN_BangLang.parent = this;
	this.VN_BangLang.setTransform(1001,2493);

	this.VN_CanTho = new lib.Symbol58();
	this.VN_CanTho.name = "VN_CanTho";
	this.VN_CanTho.parent = this;
	this.VN_CanTho.setTransform(1025,2539.5);

	this.VN_BacLieu = new lib.Symbol57();
	this.VN_BacLieu.name = "VN_BacLieu";
	this.VN_BacLieu.parent = this;
	this.VN_BacLieu.setTransform(1005.4,2676);

	this.VN_SocTrang = new lib.Symbol56();
	this.VN_SocTrang.name = "VN_SocTrang";
	this.VN_SocTrang.parent = this;
	this.VN_SocTrang.setTransform(1119.5,2607);

	this.VN_TraVinh = new lib.Symbol55();
	this.VN_TraVinh.name = "VN_TraVinh";
	this.VN_TraVinh.parent = this;
	this.VN_TraVinh.setTransform(1145,2546.5);

	this.VN_VinhLong = new lib.Symbol54();
	this.VN_VinhLong.name = "VN_VinhLong";
	this.VN_VinhLong.parent = this;
	this.VN_VinhLong.setTransform(1101.5,2500);

	this.VN_CaiBe = new lib.Symbol53();
	this.VN_CaiBe.name = "VN_CaiBe";
	this.VN_CaiBe.parent = this;
	this.VN_CaiBe.setTransform(1130.5,2440);

	this.VN_BenTre = new lib.Symbol52();
	this.VN_BenTre.name = "VN_BenTre";
	this.VN_BenTre.parent = this;
	this.VN_BenTre.setTransform(1208,2488.5);

	this.VN_VungTau = new lib.Symbol51();
	this.VN_VungTau.name = "VN_VungTau";
	this.VN_VungTau.parent = this;
	this.VN_VungTau.setTransform(1379.5,2427);

	this.VN_MyTho = new lib.Symbol50();
	this.VN_MyTho.name = "VN_MyTho";
	this.VN_MyTho.parent = this;
	this.VN_MyTho.setTransform(1228.5,2435);

	this.VN_CaiLay = new lib.Symbol49copy();
	this.VN_CaiLay.name = "VN_CaiLay";
	this.VN_CaiLay.parent = this;
	this.VN_CaiLay.setTransform(1121.5,2395.5);

	this.VN_SaDec = new lib.Symbol48copy();
	this.VN_SaDec.name = "VN_SaDec";
	this.VN_SaDec.parent = this;
	this.VN_SaDec.setTransform(1058,2472.5);

	this.VN_LongXuyen = new lib.Symbol47copy();
	this.VN_LongXuyen.name = "VN_LongXuyen";
	this.VN_LongXuyen.parent = this;
	this.VN_LongXuyen.setTransform(984,2404);

	this.VN_MocBai = new lib.Symbol46copy();
	this.VN_MocBai.name = "VN_MocBai";
	this.VN_MocBai.parent = this;
	this.VN_MocBai.setTransform(1082,2289);

	this.VN_CuChi = new lib.Symbol45copy();
	this.VN_CuChi.name = "VN_CuChi";
	this.VN_CuChi.parent = this;
	this.VN_CuChi.setTransform(1210.5,2294.5);

	this.VN_HoChiMinhCity = new lib.Symbol44copy();
	this.VN_HoChiMinhCity.name = "VN_HoChiMinhCity";
	this.VN_HoChiMinhCity.parent = this;
	this.VN_HoChiMinhCity.setTransform(1248,2346.3);

	this.VN_TayNinh = new lib.Symbol43copy();
	this.VN_TayNinh.name = "VN_TayNinh";
	this.VN_TayNinh.parent = this;
	this.VN_TayNinh.setTransform(1133.5,2222.5);

	this.VN_DongXoai = new lib.Symbol42copy();
	this.VN_DongXoai.name = "VN_DongXoai";
	this.VN_DongXoai.parent = this;
	this.VN_DongXoai.setTransform(1271,2216.5);

	this.VN_DongNai = new lib.Symbol41copy();
	this.VN_DongNai.name = "VN_DongNai";
	this.VN_DongNai.parent = this;
	this.VN_DongNai.setTransform(1378.5,2300.5);

	this.VN_BaoLoc = new lib.Symbol40copy();
	this.VN_BaoLoc.name = "VN_BaoLoc";
	this.VN_BaoLoc.parent = this;
	this.VN_BaoLoc.setTransform(1460,2201.5);

	this.VN_GiaNghia = new lib.Symbol39copy();
	this.VN_GiaNghia.name = "VN_GiaNghia";
	this.VN_GiaNghia.parent = this;
	this.VN_GiaNghia.setTransform(1400,2131);

	this.VN_PhanThiet = new lib.Symbol38copy();
	this.VN_PhanThiet.name = "VN_PhanThiet";
	this.VN_PhanThiet.parent = this;
	this.VN_PhanThiet.setTransform(1566.5,2331.5);

	this.VN_MuiNe = new lib.Symbol37copy();
	this.VN_MuiNe.name = "VN_MuiNe";
	this.VN_MuiNe.parent = this;
	this.VN_MuiNe.setTransform(1649.45,2299);

	this.VN_NinhGia = new lib.Symbol36copy();
	this.VN_NinhGia.name = "VN_NinhGia";
	this.VN_NinhGia.parent = this;
	this.VN_NinhGia.setTransform(1567.5,2185.5);

	this.VN_DaLat = new lib.Symbol35copy();
	this.VN_DaLat.name = "VN_DaLat";
	this.VN_DaLat.parent = this;
	this.VN_DaLat.setTransform(1533.5,2088.5);

	this.VN_LacLake = new lib.Symbol34copy();
	this.VN_LacLake.name = "VN_LacLake";
	this.VN_LacLake.parent = this;
	this.VN_LacLake.setTransform(1519,1982.5);

	this.VN_BuonMeThuot = new lib.Symbol33copy();
	this.VN_BuonMeThuot.name = "VN_BuonMeThuot";
	this.VN_BuonMeThuot.parent = this;
	this.VN_BuonMeThuot.setTransform(1542,1941.5);

	this.VN_Pleiku = new lib.Symbol32copy();
	this.VN_Pleiku.name = "VN_Pleiku";
	this.VN_Pleiku.parent = this;
	this.VN_Pleiku.setTransform(1415.5,1804.5);

	this.VN_BoY = new lib.Symbol31copy();
	this.VN_BoY.name = "VN_BoY";
	this.VN_BoY.parent = this;
	this.VN_BoY.setTransform(1388,1712.5);

	this.VN_BuonHo = new lib.Symbol30copy();
	this.VN_BuonHo.name = "VN_BuonHo";
	this.VN_BuonHo.parent = this;
	this.VN_BuonHo.setTransform(1525.5,1890.5);

	this.VN_KonTum = new lib.Symbol29copy();
	this.VN_KonTum.name = "VN_KonTum";
	this.VN_KonTum.parent = this;
	this.VN_KonTum.setTransform(1502,1763.5);

	this.VN_PhanRang = new lib.Symbol28copy();
	this.VN_PhanRang.name = "VN_PhanRang";
	this.VN_PhanRang.parent = this;
	this.VN_PhanRang.setTransform(1725.5,2206);

	this.VN_BinhBa = new lib.Symbol27copy();
	this.VN_BinhBa.name = "VN_BinhBa";
	this.VN_BinhBa.parent = this;
	this.VN_BinhBa.setTransform(1787,2047.5);

	this.VN_NhaTrang = new lib.Symbol26copy();
	this.VN_NhaTrang.name = "VN_NhaTrang";
	this.VN_NhaTrang.parent = this;
	this.VN_NhaTrang.setTransform(1785.5,1991);

	this.VN_TuyHoa = new lib.Symbol25copy();
	this.VN_TuyHoa.name = "VN_TuyHoa";
	this.VN_TuyHoa.parent = this;
	this.VN_TuyHoa.setTransform(1761.5,1861);

	this.VN_QuyNhon = new lib.Symbol24copy();
	this.VN_QuyNhon.name = "VN_QuyNhon";
	this.VN_QuyNhon.parent = this;
	this.VN_QuyNhon.setTransform(1758.5,1819);

	this.VN_HoangSa = new lib.Symbol23copy();
	this.VN_HoangSa.name = "VN_HoangSa";
	this.VN_HoangSa.parent = this;
	this.VN_HoangSa.setTransform(1887.5,1285.5);

	this.VN_PhuocSon = new lib.Symbol22copy();
	this.VN_PhuocSon.name = "VN_PhuocSon";
	this.VN_PhuocSon.parent = this;
	this.VN_PhuocSon.setTransform(1436,1554.5);

	this.VN_SonHa = new lib.Symbol21copy();
	this.VN_SonHa.name = "VN_SonHa";
	this.VN_SonHa.parent = this;
	this.VN_SonHa.setTransform(1528,1679.5);

	this.VN_QuangNgai = new lib.Symbol20copy();
	this.VN_QuangNgai.name = "VN_QuangNgai";
	this.VN_QuangNgai.parent = this;
	this.VN_QuangNgai.setTransform(1720,1636.5);

	this.VN_LySon = new lib.Symbol19copy2();
	this.VN_LySon.name = "VN_LySon";
	this.VN_LySon.parent = this;
	this.VN_LySon.setTransform(1747.5,1566);

	this.VN_CuLaoCham = new lib.Symbol18copy2();
	this.VN_CuLaoCham.name = "VN_CuLaoCham";
	this.VN_CuLaoCham.parent = this;
	this.VN_CuLaoCham.setTransform(1718,1426);

	this.VN_NamGiang = new lib.Symbol16copy2();
	this.VN_NamGiang.name = "VN_NamGiang";
	this.VN_NamGiang.parent = this;
	this.VN_NamGiang.setTransform(1375,1488.5);

	this.VN_DongGiang = new lib.Symbol15copy2();
	this.VN_DongGiang.name = "VN_DongGiang";
	this.VN_DongGiang.parent = this;
	this.VN_DongGiang.setTransform(1415.5,1430.5);

	this.VN_ARoang = new lib.Symbol14copy2();
	this.VN_ARoang.name = "VN_ARoang";
	this.VN_ARoang.parent = this;
	this.VN_ARoang.setTransform(1383,1380);

	this.VN_HoiAn = new lib.Symbol13copy2();
	this.VN_HoiAn.name = "VN_HoiAn";
	this.VN_HoiAn.parent = this;
	this.VN_HoiAn.setTransform(1581.45,1433);

	this.VN_DaNang = new lib.Symbol12copy2();
	this.VN_DaNang.name = "VN_DaNang";
	this.VN_DaNang.parent = this;
	this.VN_DaNang.setTransform(1561,1393);

	this.VN_MySon = new lib.Symbol11copy2();
	this.VN_MySon.name = "VN_MySon";
	this.VN_MySon.parent = this;
	this.VN_MySon.setTransform(1461.5,1481);

	this.VN_KheXanh = new lib.Symbol10copy2();
	this.VN_KheXanh.name = "VN_KheXanh";
	this.VN_KheXanh.parent = this;
	this.VN_KheXanh.setTransform(1251,1270.5);

	this.VN_PhongNha = new lib.Symbol9copy2();
	this.VN_PhongNha.name = "VN_PhongNha";
	this.VN_PhongNha.parent = this;
	this.VN_PhongNha.setTransform(1092,1115);

	this.VN_CauTreo = new lib.Symbol8copy3();
	this.VN_CauTreo.name = "VN_CauTreo";
	this.VN_CauTreo.parent = this;
	this.VN_CauTreo.setTransform(933,951.5);

	this.VN_Hue = new lib.Symbol7copy4();
	this.VN_Hue.name = "VN_Hue";
	this.VN_Hue.parent = this;
	this.VN_Hue.setTransform(1418,1321.5);

	this.VN_QuangTri = new lib.Symbol6copy3();
	this.VN_QuangTri.name = "VN_QuangTri";
	this.VN_QuangTri.parent = this;
	this.VN_QuangTri.setTransform(1391.5,1268.5);

	this.VN_VinhMocTunnels = new lib.Symbol5copy3();
	this.VN_VinhMocTunnels.name = "VN_VinhMocTunnels";
	this.VN_VinhMocTunnels.parent = this;
	this.VN_VinhMocTunnels.setTransform(1411,1209.5);

	this.VN_DongHoi = new lib.Symbol4copy4();
	this.VN_DongHoi.name = "VN_DongHoi";
	this.VN_DongHoi.parent = this;
	this.VN_DongHoi.setTransform(1277.5,1144);

	this.VN_HaTinh = new lib.Symbol3copy3();
	this.VN_HaTinh.name = "VN_HaTinh";
	this.VN_HaTinh.parent = this;
	this.VN_HaTinh.setTransform(1053,996.5);

	this.VN_Vinh = new lib.Symbol2copy3();
	this.VN_Vinh.name = "VN_Vinh";
	this.VN_Vinh.parent = this;
	this.VN_Vinh.setTransform(1006.5,919);

	this.VN_ThacBa = new lib.Symbol49();
	this.VN_ThacBa.name = "VN_ThacBa";
	this.VN_ThacBa.parent = this;
	this.VN_ThacBa.setTransform(952.9,389);

	this.VN_TayTrang = new lib.Symbol48();
	this.VN_TayTrang.name = "VN_TayTrang";
	this.VN_TayTrang.parent = this;
	this.VN_TayTrang.setTransform(567,463);

	this.VN_ThaiNguyen = new lib.Symbol47();
	this.VN_ThaiNguyen.name = "VN_ThaiNguyen";
	this.VN_ThaiNguyen.parent = this;
	this.VN_ThaiNguyen.setTransform(1095.5,392.5);

	this.VN_YenMinh = new lib.Symbol45();
	this.VN_YenMinh.name = "VN_YenMinh";
	this.VN_YenMinh.parent = this;
	this.VN_YenMinh.setTransform(893.4,65);

	this.VN_XinMan = new lib.Symbol44();
	this.VN_XinMan.name = "VN_XinMan";
	this.VN_XinMan.parent = this;
	this.VN_XinMan.setTransform(818.4,141.5);

	this.VN_VinhPhuc = new lib.Symbol43();
	this.VN_VinhPhuc.name = "VN_VinhPhuc";
	this.VN_VinhPhuc.parent = this;
	this.VN_VinhPhuc.setTransform(1017.9,421);

	this.VN_TuyenQuang = new lib.Symbol42();
	this.VN_TuyenQuang.name = "VN_TuyenQuang";
	this.VN_TuyenQuang.parent = this;
	this.VN_TuyenQuang.setTransform(1038,349);

	this.VN_TuanGiao = new lib.Symbol41();
	this.VN_TuanGiao.name = "VN_TuanGiao";
	this.VN_TuanGiao.parent = this;
	this.VN_TuanGiao.setTransform(593,327);

	this.VN_TienYen = new lib.Symbol40();
	this.VN_TienYen.name = "VN_TienYen";
	this.VN_TienYen.parent = this;
	this.VN_TienYen.setTransform(1325.5,426);

	this.VN_ThatKhe = new lib.Symbol39();
	this.VN_ThatKhe.name = "VN_ThatKhe";
	this.VN_ThatKhe.parent = this;
	this.VN_ThatKhe.setTransform(1248,273.5);

	this.VN_ThanhHoa = new lib.Symbol38();
	this.VN_ThanhHoa.name = "VN_ThanhHoa";
	this.VN_ThanhHoa.parent = this;
	this.VN_ThanhHoa.setTransform(1086.9,765.5);

	this.VN_ThanUyen = new lib.Symbol37();
	this.VN_ThanUyen.name = "VN_ThanUyen";
	this.VN_ThanUyen.parent = this;
	this.VN_ThanUyen.setTransform(759.4,319);

	this.VN_DongKhe = new lib.VN_DongKhe();
	this.VN_DongKhe.name = "VN_DongKhe";
	this.VN_DongKhe.parent = this;
	this.VN_DongKhe.setTransform(1238,229.5);

	this.VN_DienBienPhu = new lib.VN_DienBienPhu();
	this.VN_DienBienPhu.name = "VN_DienBienPhu";
	this.VN_DienBienPhu.parent = this;
	this.VN_DienBienPhu.setTransform(596,406.5);

	this.VN_CocLy = new lib.VN_CocLy();
	this.VN_CocLy.name = "VN_CocLy";
	this.VN_CocLy.parent = this;
	this.VN_CocLy.setTransform(694.4,109);

	this.VN_CatBa = new lib.VN_CatBa();
	this.VN_CatBa.name = "VN_CatBa";
	this.VN_CatBa.parent = this;
	this.VN_CatBa.setTransform(1332.4,551.5);

	this.VN_CaoSon = new lib.VN_CaoSon();
	this.VN_CaoSon.name = "VN_CaoSon";
	this.VN_CaoSon.parent = this;
	this.VN_CaoSon.setTransform(544.5,110);

	this.VN_CaoBang = new lib.VN_CaoBang();
	this.VN_CaoBang.name = "VN_CaoBang";
	this.VN_CaoBang.parent = this;
	this.VN_CaoBang.setTransform(1229.4,84.5);

	this.VN_CanCau = new lib.VN_CanCau();
	this.VN_CanCau.name = "VN_CanCau";
	this.VN_CanCau.parent = this;
	this.VN_CanCau.setTransform(690,72);

	this.VN_BinhLu = new lib.VN_BinhLu();
	this.VN_BinhLu.name = "VN_BinhLu";
	this.VN_BinhLu.parent = this;
	this.VN_BinhLu.setTransform(655.9,284.5);

	this.VN_BaoLac = new lib.VN_BaoLac();
	this.VN_BaoLac.name = "VN_BaoLac";
	this.VN_BaoLac.parent = this;
	this.VN_BaoLac.setTransform(1070.5,134.5);

	this.VN_BanGioc = new lib.VN_BanGioc();
	this.VN_BanGioc.name = "VN_BanGioc";
	this.VN_BanGioc.parent = this;
	this.VN_BanGioc.setTransform(1285.9,151);

	this.VN_BacSon = new lib.VN_BacSon();
	this.VN_BacSon.name = "VN_BacSon";
	this.VN_BacSon.parent = this;
	this.VN_BacSon.setTransform(1132,327.5);

	this.VN_BacNinh = new lib.VN_BacNinh();
	this.VN_BacNinh.name = "VN_BacNinh";
	this.VN_BacNinh.parent = this;
	this.VN_BacNinh.setTransform(1138,475.5);

	this.VN_BacMe = new lib.VN_BacMe();
	this.VN_BacMe.name = "VN_BacMe";
	this.VN_BacMe.parent = this;
	this.VN_BacMe.setTransform(968.4,210.5);

	this.VN_BacHa = new lib.VN_BacHa();
	this.VN_BacHa.name = "VN_BacHa";
	this.VN_BacHa.parent = this;
	this.VN_BacHa.setTransform(799,243);

	this.VN_BacGiang = new lib.VN_BacGiang();
	this.VN_BacGiang.name = "VN_BacGiang";
	this.VN_BacGiang.parent = this;
	this.VN_BacGiang.setTransform(1159.5,452.5);

	this.VN_BaKhe = new lib.VN_BaKhe();
	this.VN_BaKhe.name = "VN_BaKhe";
	this.VN_BaKhe.parent = this;
	this.VN_BaKhe.setTransform(921.5,443.5);

	this.VN_ThaiBinh = new lib.Symbol36();
	this.VN_ThaiBinh.name = "VN_ThaiBinh";
	this.VN_ThaiBinh.parent = this;
	this.VN_ThaiBinh.setTransform(1244,635.5);

	this.VN_TanTrao = new lib.Symbol35();
	this.VN_TanTrao.name = "VN_TanTrao";
	this.VN_TanTrao.parent = this;
	this.VN_TanTrao.setTransform(1035.5,288.5);

	this.VN_SonLa = new lib.Symbol33();
	this.VN_SonLa.name = "VN_SonLa";
	this.VN_SonLa.parent = this;
	this.VN_SonLa.setTransform(721,487);

	this.VN_SinHo = new lib.Symbol31();
	this.VN_SinHo.name = "VN_SinHo";
	this.VN_SinHo.parent = this;
	this.VN_SinHo.setTransform(520,256);

	this.VN_SinCheng = new lib.Symbol30();
	this.VN_SinCheng.name = "VN_SinCheng";
	this.VN_SinCheng.parent = this;
	this.VN_SinCheng.setTransform(717.5,34);

	this.VN_Sapa = new lib.Symbol29();
	this.VN_Sapa.name = "VN_Sapa";
	this.VN_Sapa.parent = this;
	this.VN_Sapa.setTransform(714.4,255.5);

	this.VN_QuangUyen = new lib.Symbol28();
	this.VN_QuangUyen.name = "VN_QuangUyen";
	this.VN_QuangUyen.parent = this;
	this.VN_QuangUyen.setTransform(1258,196);

	this.VN_QuanBa = new lib.Symbol27();
	this.VN_QuanBa.name = "VN_QuanBa";
	this.VN_QuanBa.parent = this;
	this.VN_QuanBa.setTransform(829.5,49);

	this.VN_NghiaLo = new lib.Symbol26();
	this.VN_NghiaLo.name = "VN_NghiaLo";
	this.VN_NghiaLo.parent = this;
	this.VN_NghiaLo.setTransform(797,424);

	this.VN_PuLuong = new lib.Symbol25();
	this.VN_PuLuong.name = "VN_PuLuong";
	this.VN_PuLuong.parent = this;
	this.VN_PuLuong.setTransform(926,638.5);

	this.VN_NinhBinh = new lib.Symbol24();
	this.VN_NinhBinh.name = "VN_NinhBinh";
	this.VN_NinhBinh.parent = this;
	this.VN_NinhBinh.setTransform(1173,692);

	this.VN_PhuYen = new lib.Symbol23();
	this.VN_PhuYen.name = "VN_PhuYen";
	this.VN_PhuYen.parent = this;
	this.VN_PhuYen.setTransform(855.5,470.5);

	this.VN_PhongTho = new lib.Symbol22();
	this.VN_PhongTho.name = "VN_PhongTho";
	this.VN_PhongTho.parent = this;
	this.VN_PhongTho.setTransform(533.5,183);

	this.VN_NamDinh = new lib.Symbol21();
	this.VN_NamDinh.name = "VN_NamDinh";
	this.VN_NamDinh.parent = this;
	this.VN_NamDinh.setTransform(1223,659.5);

	this.VN_MuongLay = new lib.Symbol20();
	this.VN_MuongLay.name = "VN_MuongLay";
	this.VN_MuongLay.parent = this;
	this.VN_MuongLay.setTransform(470.5,306);

	this.VN_MuongHum = new lib.Symbol19copy();
	this.VN_MuongHum.name = "VN_MuongHum";
	this.VN_MuongHum.parent = this;
	this.VN_MuongHum.setTransform(556.5,150.5);

	this.VN_MongCai = new lib.Symbol18copy();
	this.VN_MongCai.name = "VN_MongCai";
	this.VN_MongCai.parent = this;
	this.VN_MongCai.setTransform(1485,423.5);

	this.VN_MocChau = new lib.Symbol17copy();
	this.VN_MocChau.name = "VN_MocChau";
	this.VN_MocChau.parent = this;
	this.VN_MocChau.setTransform(855,506.5);

	this.VN_MeoVac = new lib.Symbol16copy();
	this.VN_MeoVac.name = "VN_MeoVac";
	this.VN_MeoVac.parent = this;
	this.VN_MeoVac.setTransform(1039.5,101);

	this.VN_MaiChau = new lib.Symbol15copy();
	this.VN_MaiChau.name = "VN_MaiChau";
	this.VN_MaiChau.parent = this;
	this.VN_MaiChau.setTransform(874,566.5);

	this.VN_MuCangChai = new lib.VN_MuCangChai();
	this.VN_MuCangChai.name = "VN_MuCangChai";
	this.VN_MuCangChai.parent = this;
	this.VN_MuCangChai.setTransform(842,361);

	this.VN_LungCu = new lib.Symbol14copy();
	this.VN_LungCu.name = "VN_LungCu";
	this.VN_LungCu.parent = this;
	this.VN_LungCu.setTransform(952.4,19);

	this.VN_LaoCai = new lib.Symbol13copy();
	this.VN_LaoCai.name = "VN_LaoCai";
	this.VN_LaoCai.parent = this;
	this.VN_LaoCai.setTransform(607,167);

	this.VN_LangSon = new lib.Symbol12copy();
	this.VN_LangSon.name = "VN_LangSon";
	this.VN_LangSon.parent = this;
	this.VN_LangSon.setTransform(1279,323);

	this.VN_LaiChau = new lib.Symbol11copy();
	this.VN_LaiChau.name = "VN_LaiChau";
	this.VN_LaiChau.parent = this;
	this.VN_LaiChau.setTransform(536,218);

	this.VN_LungKhauNhin = new lib.Symbol10copy();
	this.VN_LungKhauNhin.name = "VN_LungKhauNhin";
	this.VN_LungKhauNhin.parent = this;
	this.VN_LungKhauNhin.setTransform(557.5,73.5);

	this.VN_HoaBinh = new lib.Symbol9copy();
	this.VN_HoaBinh.name = "VN_HoaBinh";
	this.VN_HoaBinh.parent = this;
	this.VN_HoaBinh.setTransform(1017,566);

	this.VN_HaNoi = new lib.Symbol8copy2();
	this.VN_HaNoi.name = "VN_HaNoi";
	this.VN_HaNoi.parent = this;
	this.VN_HaNoi.setTransform(1030,453.5);

	this.VN_HaiPhong = new lib.Symbol7copy3();
	this.VN_HaiPhong.name = "VN_HaiPhong";
	this.VN_HaiPhong.parent = this;
	this.VN_HaiPhong.setTransform(1188,535);

	this.VN_HaLong = new lib.Symbol6copy2();
	this.VN_HaLong.name = "VN_HaLong";
	this.VN_HaLong.parent = this;
	this.VN_HaLong.setTransform(1314,503.5);

	this.VN_HaGiang = new lib.Symbol5copy2();
	this.VN_HaGiang.name = "VN_HaGiang";
	this.VN_HaGiang.parent = this;
	this.VN_HaGiang.setTransform(938.5,166.5);

	this.VN_HoangSuPhi = new lib.Symbol4copy3();
	this.VN_HoangSuPhi.name = "VN_HoangSuPhi";
	this.VN_HoangSuPhi.parent = this;
	this.VN_HoangSuPhi.setTransform(814,197);

	this.VN_DuongLam = new lib.Symbol3copy2();
	this.VN_DuongLam.name = "VN_DuongLam";
	this.VN_DuongLam.parent = this;
	this.VN_DuongLam.setTransform(978.5,491);

	this.VN_DongVan = new lib.Symbol2copy2();
	this.VN_DongVan.name = "VN_DongVan";
	this.VN_DongVan.parent = this;
	this.VN_DongVan.setTransform(1062,45);

	this.VN_BaBe = new lib.Symbol1copy3();
	this.VN_BaBe.name = "VN_BaBe";
	this.VN_BaBe.parent = this;
	this.VN_BaBe.setTransform(1076.5,234.5,1,1,0,0,0,29.5,12.5);

	this.KH_Sihanoukville = new lib.Symbol120();
	this.KH_Sihanoukville.name = "KH_Sihanoukville";
	this.KH_Sihanoukville.parent = this;
	this.KH_Sihanoukville.setTransform(546.4,2384.8);

	this.KH_Kep = new lib.Symbol119();
	this.KH_Kep.name = "KH_Kep";
	this.KH_Kep.parent = this;
	this.KH_Kep.setTransform(726.5,2460);

	this.KH_Kampot = new lib.Symbol118();
	this.KH_Kampot.name = "KH_Kampot";
	this.KH_Kampot.parent = this;
	this.KH_Kampot.setTransform(591.5,2455);

	this.KH_TonleSap = new lib.Symbol117();
	this.KH_TonleSap.name = "KH_TonleSap";
	this.KH_TonleSap.parent = this;
	this.KH_TonleSap.setTransform(745,1900);

	this.KH_PhnomPenh = new lib.Symbol116();
	this.KH_PhnomPenh.name = "KH_PhnomPenh";
	this.KH_PhnomPenh.parent = this;
	this.KH_PhnomPenh.setTransform(805,2226.5);

	this.KH_KompongChhnang = new lib.Symbol115();
	this.KH_KompongChhnang.name = "KH_KompongChhnang";
	this.KH_KompongChhnang.parent = this;
	this.KH_KompongChhnang.setTransform(675,2060);

	this.KH_Pursat = new lib.Symbol114();
	this.KH_Pursat.name = "KH_Pursat";
	this.KH_Pursat.parent = this;
	this.KH_Pursat.setTransform(618,1994.5);

	this.KH_Battambang = new lib.Symbol113();
	this.KH_Battambang.name = "KH_Battambang";
	this.KH_Battambang.parent = this;
	this.KH_Battambang.setTransform(525.5,1924);

	this.KH_KohTrong = new lib.Symbol112();
	this.KH_KohTrong.name = "KH_KohTrong";
	this.KH_KohTrong.parent = this;
	this.KH_KohTrong.setTransform(1178,2055);

	this.KH_KompongCham = new lib.Symbol111();
	this.KH_KompongCham.name = "KH_KompongCham";
	this.KH_KompongCham.parent = this;
	this.KH_KompongCham.setTransform(1052,2138);

	this.KH_Kratie = new lib.Symbol110();
	this.KH_Kratie.name = "KH_Kratie";
	this.KH_Kratie.parent = this;
	this.KH_Kratie.setTransform(1036,2022);

	this.KH_Mondulkiri = new lib.Symbol109();
	this.KH_Mondulkiri.name = "KH_Mondulkiri";
	this.KH_Mondulkiri.parent = this;
	this.KH_Mondulkiri.setTransform(1265,2000.5);

	this.KH_Rattanakiri = new lib.Symbol108();
	this.KH_Rattanakiri.name = "KH_Rattanakiri";
	this.KH_Rattanakiri.parent = this;
	this.KH_Rattanakiri.setTransform(1256,1767.5);

	this.KH_BanLung = new lib.Symbol107();
	this.KH_BanLung.name = "KH_BanLung";
	this.KH_BanLung.parent = this;
	this.KH_BanLung.setTransform(1285.4,1826);

	this.KH_StungTreng = new lib.Symbol106();
	this.KH_StungTreng.name = "KH_StungTreng";
	this.KH_StungTreng.parent = this;
	this.KH_StungTreng.setTransform(1037,1813);

	this.KH_KompongThom = new lib.Symbol105();
	this.KH_KompongThom.name = "KH_KompongThom";
	this.KH_KompongThom.parent = this;
	this.KH_KompongThom.setTransform(919.4,1975);

	this.KH_SiemReap = new lib.Symbol104();
	this.KH_SiemReap.name = "KH_SiemReap";
	this.KH_SiemReap.parent = this;
	this.KH_SiemReap.setTransform(748.5,1823.5);

	this.KH_SereiSaoPhoan = new lib.Symbol103();
	this.KH_SereiSaoPhoan.name = "KH_SereiSaoPhoan";
	this.KH_SereiSaoPhoan.parent = this;
	this.KH_SereiSaoPhoan.setTransform(577.5,1772);

	this.KH_KrongPoiPet = new lib.Symbol102();
	this.KH_KrongPoiPet.name = "KH_KrongPoiPet";
	this.KH_KrongPoiPet.parent = this;
	this.KH_KrongPoiPet.setTransform(668,1715);

	this.KH_Kohker = new lib.Symbol101();
	this.KH_Kohker.name = "KH_Kohker";
	this.KH_Kohker.parent = this;
	this.KH_Kohker.setTransform(757,1766.5);

	this.KH_PreahVihear = new lib.Symbol100();
	this.KH_PreahVihear.name = "KH_PreahVihear";
	this.KH_PreahVihear.parent = this;
	this.KH_PreahVihear.setTransform(921,1762.5);

	this.LA_IledeKhnong = new lib.Symbol99();
	this.LA_IledeKhnong.name = "LA_IledeKhnong";
	this.LA_IledeKhnong.parent = this;
	this.LA_IledeKhnong.setTransform(997,1706.5);

	this.LA_Champassak = new lib.Symbol98();
	this.LA_Champassak.name = "LA_Champassak";
	this.LA_Champassak.parent = this;
	this.LA_Champassak.setTransform(1120.5,1517);

	this.LA_BanKhietNgong = new lib.Symbol97();
	this.LA_BanKhietNgong.name = "LA_BanKhietNgong";
	this.LA_BanKhietNgong.parent = this;
	this.LA_BanKhietNgong.setTransform(1097,1646);

	this.LA_DonDeang = new lib.Symbol96();
	this.LA_DonDeang.name = "LA_DonDeang";
	this.LA_DonDeang.parent = this;
	this.LA_DonDeang.setTransform(1007.4,1560);

	this.LA_WatPhou = new lib.Symbol95();
	this.LA_WatPhou.name = "LA_WatPhou";
	this.LA_WatPhou.parent = this;
	this.LA_WatPhou.setTransform(1094.5,1585.5);

	this.LA_Attapeu = new lib.Symbol94();
	this.LA_Attapeu.name = "LA_Attapeu";
	this.LA_Attapeu.parent = this;
	this.LA_Attapeu.setTransform(1310,1600);

	this.LA_Pakse = new lib.Symbol93();
	this.LA_Pakse.name = "LA_Pakse";
	this.LA_Pakse.parent = this;
	this.LA_Pakse.setTransform(1049.5,1429.5);

	this.LA_Thateng = new lib.Symbol92();
	this.LA_Thateng.name = "LA_Thateng";
	this.LA_Thateng.parent = this;
	this.LA_Thateng.setTransform(1134.5,1366);

	this.LA_Laongam = new lib.Symbol91();
	this.LA_Laongam.name = "LA_Laongam";
	this.LA_Laongam.parent = this;
	this.LA_Laongam.setTransform(1072.9,1314);

	this.LA_Savannakhet = new lib.Symbol90();
	this.LA_Savannakhet.name = "LA_Savannakhet";
	this.LA_Savannakhet.parent = this;
	this.LA_Savannakhet.setTransform(945.5,1325.5);

	this.LA_Thakek = new lib.Symbol89();
	this.LA_Thakek.name = "LA_Thakek";
	this.LA_Thakek.parent = this;
	this.LA_Thakek.setTransform(888.5,1133.5);

	this.LA_Kenethao = new lib.Symbol88();
	this.LA_Kenethao.name = "LA_Kenethao";
	this.LA_Kenethao.parent = this;
	this.LA_Kenethao.setTransform(268,1042);

	this.LA_XamNeua = new lib.Symbol87();
	this.LA_XamNeua.name = "LA_XamNeua";
	this.LA_XamNeua.parent = this;
	this.LA_XamNeua.setTransform(716.5,626);

	this.LA_Hongsa = new lib.Symbol86();
	this.LA_Hongsa.name = "LA_Hongsa";
	this.LA_Hongsa.parent = this;
	this.LA_Hongsa.setTransform(267.5,727);

	this.LA_Vientiane = new lib.Symbol85();
	this.LA_Vientiane.name = "LA_Vientiane";
	this.LA_Vientiane.parent = this;
	this.LA_Vientiane.setTransform(442,1013);

	this.LA_PlainOfJars = new lib.Symbol84();
	this.LA_PlainOfJars.name = "LA_PlainOfJars";
	this.LA_PlainOfJars.parent = this;
	this.LA_PlainOfJars.setTransform(539.5,829.5);

	this.VN_NamCan = new lib.Symbol83();
	this.VN_NamCan.name = "VN_NamCan";
	this.VN_NamCan.parent = this;
	this.VN_NamCan.setTransform(777,774);

	this.LA_MuangKham = new lib.Symbol82();
	this.LA_MuangKham.name = "LA_MuangKham";
	this.LA_MuangKham.parent = this;
	this.LA_MuangKham.setTransform(675,710.5);

	this.LA_Phonxavan = new lib.Symbol81();
	this.LA_Phonxavan.name = "LA_Phonxavan";
	this.LA_Phonxavan.parent = this;
	this.LA_Phonxavan.setTransform(521,736.5);

	this.LA_VangVieng = new lib.Symbol80();
	this.LA_VangVieng.name = "LA_VangVieng";
	this.LA_VangVieng.parent = this;
	this.LA_VangVieng.setTransform(410,881.5);

	this.LA_Pakxan = new lib.Symbol79();
	this.LA_Pakxan.name = "LA_Pakxan";
	this.LA_Pakxan.parent = this;
	this.LA_Pakxan.setTransform(702.5,961.5);

	this.LA_NamNgum = new lib.Symbol78();
	this.LA_NamNgum.name = "LA_NamNgum";
	this.LA_NamNgum.parent = this;
	this.LA_NamNgum.setTransform(490.5,971);

	this.LA_Houixai = new lib.Symbol77();
	this.LA_Houixai.name = "LA_Houixai";
	this.LA_Houixai.parent = this;
	this.LA_Houixai.setTransform(107.5,547.5);

	this.LA_LuangPrabang = new lib.Symbol76();
	this.LA_LuangPrabang.name = "LA_LuangPrabang";
	this.LA_LuangPrabang.parent = this;
	this.LA_LuangPrabang.setTransform(382,673);

	this.LA_NongKhiaw = new lib.Symbol75();
	this.LA_NongKhiaw.name = "LA_NongKhiaw";
	this.LA_NongKhiaw.parent = this;
	this.LA_NongKhiaw.setTransform(562,583);

	this.LA_MuangNgoy = new lib.Symbol74();
	this.LA_MuangNgoy.name = "LA_MuangNgoy";
	this.LA_MuangNgoy.parent = this;
	this.LA_MuangNgoy.setTransform(559.5,533.5);

	this.LA_MuongKhua = new lib.Symbol73();
	this.LA_MuongKhua.name = "LA_MuongKhua";
	this.LA_MuongKhua.parent = this;
	this.LA_MuongKhua.setTransform(418.5,471);

	this.LA_LuangNamtha = new lib.Symbol72();
	this.LA_LuangNamtha.name = "LA_LuangNamtha";
	this.LA_LuangNamtha.parent = this;
	this.LA_LuangNamtha.setTransform(240.5,497);

	this.LA_MuangSing = new lib.Symbol71();
	this.LA_MuangSing.name = "LA_MuangSing";
	this.LA_MuangSing.parent = this;
	this.LA_MuangSing.setTransform(184.5,403);

	this.LA_Phongsali = new lib.Symbol70();
	this.LA_Phongsali.name = "LA_Phongsali";
	this.LA_Phongsali.parent = this;
	this.LA_Phongsali.setTransform(376.5,366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.LA_Phongsali},{t:this.LA_MuangSing},{t:this.LA_LuangNamtha},{t:this.LA_MuongKhua},{t:this.LA_MuangNgoy},{t:this.LA_NongKhiaw},{t:this.LA_LuangPrabang},{t:this.LA_Houixai},{t:this.LA_NamNgum},{t:this.LA_Pakxan},{t:this.LA_VangVieng},{t:this.LA_Phonxavan},{t:this.LA_MuangKham},{t:this.VN_NamCan},{t:this.LA_PlainOfJars},{t:this.LA_Vientiane},{t:this.LA_Hongsa},{t:this.LA_XamNeua},{t:this.LA_Kenethao},{t:this.LA_Thakek},{t:this.LA_Savannakhet},{t:this.LA_Laongam},{t:this.LA_Thateng},{t:this.LA_Pakse},{t:this.LA_Attapeu},{t:this.LA_WatPhou},{t:this.LA_DonDeang},{t:this.LA_BanKhietNgong},{t:this.LA_Champassak},{t:this.LA_IledeKhnong},{t:this.KH_PreahVihear},{t:this.KH_Kohker},{t:this.KH_KrongPoiPet},{t:this.KH_SereiSaoPhoan},{t:this.KH_SiemReap},{t:this.KH_KompongThom},{t:this.KH_StungTreng},{t:this.KH_BanLung},{t:this.KH_Rattanakiri},{t:this.KH_Mondulkiri},{t:this.KH_Kratie},{t:this.KH_KompongCham},{t:this.KH_KohTrong},{t:this.KH_Battambang},{t:this.KH_Pursat},{t:this.KH_KompongChhnang},{t:this.KH_PhnomPenh},{t:this.KH_TonleSap},{t:this.KH_Kampot},{t:this.KH_Kep},{t:this.KH_Sihanoukville},{t:this.VN_BaBe},{t:this.VN_DongVan},{t:this.VN_DuongLam},{t:this.VN_HoangSuPhi},{t:this.VN_HaGiang},{t:this.VN_HaLong},{t:this.VN_HaiPhong},{t:this.VN_HaNoi},{t:this.VN_HoaBinh},{t:this.VN_LungKhauNhin},{t:this.VN_LaiChau},{t:this.VN_LangSon},{t:this.VN_LaoCai},{t:this.VN_LungCu},{t:this.VN_MuCangChai},{t:this.VN_MaiChau},{t:this.VN_MeoVac},{t:this.VN_MocChau},{t:this.VN_MongCai},{t:this.VN_MuongHum},{t:this.VN_MuongLay},{t:this.VN_NamDinh},{t:this.VN_PhongTho},{t:this.VN_PhuYen},{t:this.VN_NinhBinh},{t:this.VN_PuLuong},{t:this.VN_NghiaLo},{t:this.VN_QuanBa},{t:this.VN_QuangUyen},{t:this.VN_Sapa},{t:this.VN_SinCheng},{t:this.VN_SinHo},{t:this.VN_SonLa},{t:this.VN_TanTrao},{t:this.VN_ThaiBinh},{t:this.VN_BaKhe},{t:this.VN_BacGiang},{t:this.VN_BacHa},{t:this.VN_BacMe},{t:this.VN_BacNinh},{t:this.VN_BacSon},{t:this.VN_BanGioc},{t:this.VN_BaoLac},{t:this.VN_BinhLu},{t:this.VN_CanCau},{t:this.VN_CaoBang},{t:this.VN_CaoSon},{t:this.VN_CatBa},{t:this.VN_CocLy},{t:this.VN_DienBienPhu},{t:this.VN_DongKhe},{t:this.VN_ThanUyen},{t:this.VN_ThanhHoa},{t:this.VN_ThatKhe},{t:this.VN_TienYen},{t:this.VN_TuanGiao},{t:this.VN_TuyenQuang},{t:this.VN_VinhPhuc},{t:this.VN_XinMan},{t:this.VN_YenMinh},{t:this.VN_ThaiNguyen},{t:this.VN_TayTrang},{t:this.VN_ThacBa},{t:this.VN_Vinh},{t:this.VN_HaTinh},{t:this.VN_DongHoi},{t:this.VN_VinhMocTunnels},{t:this.VN_QuangTri},{t:this.VN_Hue},{t:this.VN_CauTreo},{t:this.VN_PhongNha},{t:this.VN_KheXanh},{t:this.VN_MySon},{t:this.VN_DaNang},{t:this.VN_HoiAn},{t:this.VN_ARoang},{t:this.VN_DongGiang},{t:this.VN_NamGiang},{t:this.VN_CuLaoCham},{t:this.VN_LySon},{t:this.VN_QuangNgai},{t:this.VN_SonHa},{t:this.VN_PhuocSon},{t:this.VN_HoangSa},{t:this.VN_QuyNhon},{t:this.VN_TuyHoa},{t:this.VN_NhaTrang},{t:this.VN_BinhBa},{t:this.VN_PhanRang},{t:this.VN_KonTum},{t:this.VN_BuonHo},{t:this.VN_BoY},{t:this.VN_Pleiku},{t:this.VN_BuonMeThuot},{t:this.VN_LacLake},{t:this.VN_DaLat},{t:this.VN_NinhGia},{t:this.VN_MuiNe},{t:this.VN_PhanThiet},{t:this.VN_GiaNghia},{t:this.VN_BaoLoc},{t:this.VN_DongNai},{t:this.VN_DongXoai},{t:this.VN_TayNinh},{t:this.VN_HoChiMinhCity},{t:this.VN_CuChi},{t:this.VN_MocBai},{t:this.VN_LongXuyen},{t:this.VN_SaDec},{t:this.VN_CaiLay},{t:this.VN_MyTho},{t:this.VN_VungTau},{t:this.VN_BenTre},{t:this.VN_CaiBe},{t:this.VN_VinhLong},{t:this.VN_TraVinh},{t:this.VN_SocTrang},{t:this.VN_BacLieu},{t:this.VN_CanTho},{t:this.VN_BangLang},{t:this.VN_HaTien},{t:this.VN_TraSu},{t:this.VN_RachGia},{t:this.VN_CaMau},{t:this.VN_ConDao},{t:this.VN_TruongSa},{t:this.VN_ChauDoc},{t:this.KH_Takeo},{t:this.VN_PhuQuoc},{t:this.VN_DuGia},{t:this.LA_Oudomxai},{t:this.VN_XuanMai},{t:this.LA_PakBeng},{t:this.VN_GotFerry},{t:this.VN_TuLe},{t:this.VN_DinhLap},{t:this.VN_YenThuy},{t:this.LA_Sekong},{t:this.LA_Paksong},{t:this.LA_Sanamxai},{t:this.VN_BuonDon},{t:this.VN_DraySap},{t:this.VN_CaoLanh},{t:this.VN_TanChau},{t:this.VN_TramChim},{t:this.VN_BacQuang},{t:this.VN_PhoRang},{t:this.VN_BacKan},{t:this.VN_BinhChau},{t:this.VN_CatTien},{t:this.VN_TanAn},{t:this.VN_TinhBien},{t:this.VN_ALuoi},{t:this.VN_BachMa},{t:this.VN_MyLai}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8copy, new cjs.Rectangle(48.5,3,1886.5,2715), null);


(lib.Symbol1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_3 = new lib.Symbol2_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0.5,0,0.2857,0.2857,0,0,0,14,14);
	this.instance_3.alpha = 0.1914;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:0.3364,scaleY:0.3364,y:-0.1,alpha:1},14).to({scaleX:0.2857,scaleY:0.2857,x:0.4,y:0.05,alpha:0.1914},15).wait(1));

	// Layer_2
	this.instance_4 = new lib.Symbol3_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0.5,-0.1,0.4464,0.4464,0,0,0,14,14);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.7,-6.3,12.600000000000001,12.6);


(lib.btnDot3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol4_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.3333,scaleY:1.3333},0).wait(1).to({scaleX:1,scaleY:1},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.3,-9.3,18.700000000000003,18.700000000000003);


(lib.Symbol8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.mcCity = new lib.Symbol8copy();
	this.mcCity.name = "mcCity";
	this.mcCity.parent = this;
	this.mcCity.setTransform(1013.5,1436,1,1,0,0,0,991.5,1403);

	this.instance_1 = new lib.map3nuoc1pngcopy();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.mcCity}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8_1, new cjs.Rectangle(0,0,2048,2854), null);


(lib.Symbol1copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hnpoint_png
	this.instance = new lib.hnpoint();
	this.instance.parent = this;
	this.instance.setTransform(-12,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// mcAnim
	this.mcAnim = new lib.Symbol1_2();
	this.mcAnim.name = "mcAnim";
	this.mcAnim.parent = this;
	this.mcAnim.setTransform(0.5,-1.2,1.7037,1.7037);

	this.timeline.addTween(cjs.Tween.get(this.mcAnim).wait(1));

	// mcPoint
	this.mcPoint = new lib.btnDot3();
	this.mcPoint.name = "mcPoint";
	this.mcPoint.parent = this;
	this.mcPoint.setTransform(0.9,-0.9);
	new cjs.ButtonHelper(this.mcPoint, 0, 1, 2, false, new lib.btnDot3(), 3);

	this.timeline.addTween(cjs.Tween.get(this.mcPoint).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy5, new cjs.Rectangle(-12,-12,24.3,24), null);


(lib.Symbol3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.mcAnim = new lib.Symbol1_2();
	this.mcAnim.name = "mcAnim";
	this.mcAnim.parent = this;
	this.mcAnim.setTransform(-0.4,-0.3,1.7037,1.7037);

	this.timeline.addTween(cjs.Tween.get(this.mcAnim).wait(1));

	// Layer_1
	this.mcPoint = new lib.btnDot3();
	this.mcPoint.name = "mcPoint";
	this.mcPoint.parent = this;
	new cjs.ButtonHelper(this.mcPoint, 0, 1, 2, false, new lib.btnDot3(), 3);

	this.timeline.addTween(cjs.Tween.get(this.mcPoint).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3_2, new cjs.Rectangle(-10.1,-11.1,21.5,21.5), null);


(lib.Symbol1copy_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.VN_TinhBien = new lib.Symbol3_2();
	this.VN_TinhBien.name = "VN_TinhBien";
	this.VN_TinhBien.parent = this;
	this.VN_TinhBien.setTransform(902.3,2437.75);

	this.VN_TanAn = new lib.Symbol3_2();
	this.VN_TanAn.name = "VN_TanAn";
	this.VN_TanAn.parent = this;
	this.VN_TanAn.setTransform(1204.35,2439.45);

	this.VN_BinhChau = new lib.Symbol3_2();
	this.VN_BinhChau.name = "VN_BinhChau";
	this.VN_BinhChau.parent = this;
	this.VN_BinhChau.setTransform(1408.3,2426.75);

	this.VN_DongNai = new lib.Symbol3_2();
	this.VN_DongNai.name = "VN_DongNai";
	this.VN_DongNai.parent = this;
	this.VN_DongNai.setTransform(1339.3,2335.55);

	this.VN_CatTien = new lib.Symbol3_2();
	this.VN_CatTien.name = "VN_CatTien";
	this.VN_CatTien.parent = this;
	this.VN_CatTien.setTransform(1364.6,2247.2);

	this.VN_ALuoi = new lib.Symbol3_2();
	this.VN_ALuoi.name = "VN_ALuoi";
	this.VN_ALuoi.parent = this;
	this.VN_ALuoi.setTransform(1334,1391.1);

	this.VN_BachMa = new lib.Symbol3_2();
	this.VN_BachMa.name = "VN_BachMa";
	this.VN_BachMa.parent = this;
	this.VN_BachMa.setTransform(1433.3,1400.3);

	this.VN_MyLai = new lib.Symbol3_2();
	this.VN_MyLai.name = "VN_MyLai";
	this.VN_MyLai.parent = this;
	this.VN_MyLai.setTransform(1665.45,1649);

	this.VN_BacQuang = new lib.Symbol3_2();
	this.VN_BacQuang.name = "VN_BacQuang";
	this.VN_BacQuang.parent = this;
	this.VN_BacQuang.setTransform(900.65,268.35);

	this.VN_PhoRang = new lib.Symbol3_2();
	this.VN_PhoRang.name = "VN_PhoRang";
	this.VN_PhoRang.parent = this;
	this.VN_PhoRang.setTransform(844.15,305.65);

	this.VN_BacKan = new lib.Symbol3_2();
	this.VN_BacKan.name = "VN_BacKan";
	this.VN_BacKan.parent = this;
	this.VN_BacKan.setTransform(1081.25,306.35);

	this.VN_TanChau = new lib.Symbol3_2();
	this.VN_TanChau.name = "VN_TanChau";
	this.VN_TanChau.parent = this;
	this.VN_TanChau.setTransform(935.55,2379.75);

	this.VN_TramChim = new lib.Symbol3_2();
	this.VN_TramChim.name = "VN_TramChim";
	this.VN_TramChim.parent = this;
	this.VN_TramChim.setTransform(1052.85,2410.45);

	this.VN_YenThuy = new lib.Symbol3_2();
	this.VN_YenThuy.name = "VN_YenThuy";
	this.VN_YenThuy.parent = this;
	this.VN_YenThuy.setTransform(1054.85,630.35);

	this.VN_TuLe = new lib.Symbol3_2();
	this.VN_TuLe.name = "VN_TuLe";
	this.VN_TuLe.parent = this;
	this.VN_TuLe.setTransform(819.35,421.85);

	this.VN_DinhLap = new lib.Symbol3_2();
	this.VN_DinhLap.name = "VN_DinhLap";
	this.VN_DinhLap.parent = this;
	this.VN_DinhLap.setTransform(1296.35,404.85);

	this.VN_GotFerry = new lib.Symbol3_2();
	this.VN_GotFerry.name = "VN_GotFerry";
	this.VN_GotFerry.parent = this;
	this.VN_GotFerry.setTransform(1277.35,575.85);

	this.LA_Sekong = new lib.Symbol3_2();
	this.LA_Sekong.name = "LA_Sekong";
	this.LA_Sekong.parent = this;
	this.LA_Sekong.setTransform(1257.35,1462.1);

	this.LA_Paksong = new lib.Symbol3_2();
	this.LA_Paksong.name = "LA_Paksong";
	this.LA_Paksong.parent = this;
	this.LA_Paksong.setTransform(1130.35,1473.8);

	this.LA_Sanamxai = new lib.Symbol3_2();
	this.LA_Sanamxai.name = "LA_Sanamxai";
	this.LA_Sanamxai.parent = this;
	this.LA_Sanamxai.setTransform(1202.35,1654.3);

	this.VN_DraySap = new lib.Symbol3_2();
	this.VN_DraySap.name = "VN_DraySap";
	this.VN_DraySap.parent = this;
	this.VN_DraySap.setTransform(1433.3,2000.75);

	this.VN_BuonDon = new lib.Symbol3_2();
	this.VN_BuonDon.name = "VN_BuonDon";
	this.VN_BuonDon.parent = this;
	this.VN_BuonDon.setTransform(1414.8,1961.75);

	this.VN_CaoLanh = new lib.Symbol3_2();
	this.VN_CaoLanh.name = "VN_CaoLanh";
	this.VN_CaoLanh.parent = this;
	this.VN_CaoLanh.setTransform(1059.85,2443.75);

	this.LA_PakBeng = new lib.Symbol3_2();
	this.LA_PakBeng.name = "LA_PakBeng";
	this.LA_PakBeng.parent = this;
	this.LA_PakBeng.setTransform(209.9,715);

	this.VN_XuanMai = new lib.Symbol3_2();
	this.VN_XuanMai.name = "VN_XuanMai";
	this.VN_XuanMai.parent = this;
	this.VN_XuanMai.setTransform(1048.55,558.4);

	this.VN_HaNoi = new lib.Symbol1copy5();
	this.VN_HaNoi.name = "VN_HaNoi";
	this.VN_HaNoi.parent = this;
	this.VN_HaNoi.setTransform(1067.35,517.85);

	this.KH_KrongPoiPet = new lib.Symbol3_2();
	this.KH_KrongPoiPet.name = "KH_KrongPoiPet";
	this.KH_KrongPoiPet.parent = this;
	this.KH_KrongPoiPet.setTransform(577.15,1752.1);

	this.LA_Thateng = new lib.Symbol3_2();
	this.LA_Thateng.name = "LA_Thateng";
	this.LA_Thateng.parent = this;
	this.LA_Thateng.setTransform(1141.85,1411.8);

	this.LA_Laongam = new lib.Symbol3_2();
	this.LA_Laongam.name = "LA_Laongam";
	this.LA_Laongam.parent = this;
	this.LA_Laongam.setTransform(1086.35,1364.8);

	this.LA_Pakse = new lib.Symbol3_2();
	this.LA_Pakse.name = "LA_Pakse";
	this.LA_Pakse.parent = this;
	this.LA_Pakse.setTransform(1024.35,1465.1);

	this.KH_BanLung = new lib.Symbol3_2();
	this.KH_BanLung.name = "KH_BanLung";
	this.KH_BanLung.parent = this;
	this.KH_BanLung.setTransform(1245.35,1854.8);

	this.VN_PhanThiet = new lib.Symbol3_2();
	this.VN_PhanThiet.name = "VN_PhanThiet";
	this.VN_PhanThiet.parent = this;
	this.VN_PhanThiet.setTransform(1581.8,2333.25);

	this.VN_KheXanh = new lib.Symbol3_2();
	this.VN_KheXanh.name = "VN_KheXanh";
	this.VN_KheXanh.parent = this;
	this.VN_KheXanh.setTransform(1249.85,1331.5);

	this.VN_PhongNha = new lib.Symbol3_2();
	this.VN_PhongNha.name = "VN_PhongNha";
	this.VN_PhongNha.parent = this;
	this.VN_PhongNha.setTransform(1150.55,1170.8);

	this.VN_TanTrao = new lib.Symbol3_2();
	this.VN_TanTrao.name = "VN_TanTrao";
	this.VN_TanTrao.parent = this;
	this.VN_TanTrao.setTransform(1045.05,343.85);

	this.VN_TuanGiao = new lib.Symbol3_2();
	this.VN_TuanGiao.name = "VN_TuanGiao";
	this.VN_TuanGiao.parent = this;
	this.VN_TuanGiao.setTransform(653.65,386.05);

	this.LA_PlainOfJars = new lib.Symbol3_2();
	this.LA_PlainOfJars.name = "LA_PlainOfJars";
	this.LA_PlainOfJars.parent = this;
	this.LA_PlainOfJars.setTransform(559.85,841.15);

	this.KH_Sihanoukville = new lib.Symbol3_2();
	this.KH_Sihanoukville.name = "KH_Sihanoukville";
	this.KH_Sihanoukville.parent = this;
	this.KH_Sihanoukville.setTransform(667.5,2419.55);

	this.VN_ConDao = new lib.Symbol3_2();
	this.VN_ConDao.name = "VN_ConDao";
	this.VN_ConDao.parent = this;
	this.VN_ConDao.setTransform(1418,2741.35);

	this.VN_BinhBa = new lib.Symbol3_2();
	this.VN_BinhBa.name = "VN_BinhBa";
	this.VN_BinhBa.parent = this;
	this.VN_BinhBa.setTransform(1748.3,2077);

	this.VN_TuyHoa = new lib.Symbol3_2();
	this.VN_TuyHoa.name = "VN_TuyHoa";
	this.VN_TuyHoa.parent = this;
	this.VN_TuyHoa.setTransform(1718.75,1891.8);

	this.VN_LySon = new lib.Symbol3_2();
	this.VN_LySon.name = "VN_LySon";
	this.VN_LySon.parent = this;
	this.VN_LySon.setTransform(1832.05,1597.6);

	this.VN_BaoLoc = new lib.Symbol3_2();
	this.VN_BaoLoc.name = "VN_BaoLoc";
	this.VN_BaoLoc.parent = this;
	this.VN_BaoLoc.setTransform(1506.3,2233.5);

	this.VN_PhanRang = new lib.Symbol3_2();
	this.VN_PhanRang.name = "VN_PhanRang";
	this.VN_PhanRang.parent = this;
	this.VN_PhanRang.setTransform(1673.25,2236.75);

	this.LA_MuangNgoy = new lib.Symbol3_2();
	this.LA_MuangNgoy.name = "LA_MuangNgoy";
	this.LA_MuangNgoy.parent = this;
	this.LA_MuangNgoy.setTransform(499.35,563.85);

	this.VN_VinhPhuc = new lib.Symbol3_2();
	this.VN_VinhPhuc.name = "VN_VinhPhuc";
	this.VN_VinhPhuc.parent = this;
	this.VN_VinhPhuc.setTransform(1014.35,465.85);

	this.VN_PhongTho = new lib.Symbol3_2();
	this.VN_PhongTho.name = "VN_PhongTho";
	this.VN_PhongTho.parent = this;
	this.VN_PhongTho.setTransform(589.85,239.35);

	this.VN_MuongLay = new lib.Symbol3_2();
	this.VN_MuongLay.name = "VN_MuongLay";
	this.VN_MuongLay.parent = this;
	this.VN_MuongLay.setTransform(560.85,340.35);

	this.LA_XamNeua = new lib.Symbol3_2();
	this.LA_XamNeua.name = "LA_XamNeua";
	this.LA_XamNeua.parent = this;
	this.LA_XamNeua.setTransform(731.35,635.35);

	this.KH_Kampot = new lib.Symbol3_2();
	this.KH_Kampot.name = "KH_Kampot";
	this.KH_Kampot.parent = this;
	this.KH_Kampot.setTransform(743.85,2423.75);

	this.KH_Kep = new lib.Symbol3_2();
	this.KH_Kep.name = "KH_Kep";
	this.KH_Kep.parent = this;
	this.KH_Kep.setTransform(790.85,2437.75);

	this.KH_Takeo = new lib.Symbol3_2();
	this.KH_Takeo.name = "KH_Takeo";
	this.KH_Takeo.parent = this;
	this.KH_Takeo.setTransform(879.85,2359.75);

	this.KH_SereiSaoPhoan = new lib.Symbol3_2();
	this.KH_SereiSaoPhoan.name = "KH_SereiSaoPhoan";
	this.KH_SereiSaoPhoan.parent = this;
	this.KH_SereiSaoPhoan.setTransform(638.85,1800.3);

	this.KH_SiemReap = new lib.Symbol3_2();
	this.KH_SiemReap.name = "KH_SiemReap";
	this.KH_SiemReap.parent = this;
	this.KH_SiemReap.setTransform(699.35,1855.8);

	this.KH_TonleSap = new lib.Symbol3_2();
	this.KH_TonleSap.name = "KH_TonleSap";
	this.KH_TonleSap.parent = this;
	this.KH_TonleSap.setTransform(705.35,1936.75);

	this.KH_Battambang = new lib.Symbol3_2();
	this.KH_Battambang.name = "KH_Battambang";
	this.KH_Battambang.parent = this;
	this.KH_Battambang.setTransform(563.85,1927.75);

	this.KH_Pursat = new lib.Symbol3_2();
	this.KH_Pursat.name = "KH_Pursat";
	this.KH_Pursat.parent = this;
	this.KH_Pursat.setTransform(687.35,2029.75);

	this.KH_PhnomPenh = new lib.Symbol3_2();
	this.KH_PhnomPenh.name = "KH_PhnomPenh";
	this.KH_PhnomPenh.parent = this;
	this.KH_PhnomPenh.setTransform(909.35,2262.25);

	this.KH_KompongChhnang = new lib.Symbol3_2();
	this.KH_KompongChhnang.name = "KH_KompongChhnang";
	this.KH_KompongChhnang.parent = this;
	this.KH_KompongChhnang.setTransform(769.85,2086);

	this.KH_KompongCham = new lib.Symbol3_2();
	this.KH_KompongCham.name = "KH_KompongCham";
	this.KH_KompongCham.parent = this;
	this.KH_KompongCham.setTransform(1128.35,2135.25);

	this.KH_KohTrong = new lib.Symbol3_2();
	this.KH_KohTrong.name = "KH_KohTrong";
	this.KH_KohTrong.parent = this;
	this.KH_KohTrong.setTransform(1133.35,2087.25);

	this.KH_KompongThom = new lib.Symbol3_2();
	this.KH_KompongThom.name = "KH_KompongThom";
	this.KH_KompongThom.parent = this;
	this.KH_KompongThom.setTransform(950.35,2045.75);

	this.KH_Kratie = new lib.Symbol3_2();
	this.KH_Kratie.name = "KH_Kratie";
	this.KH_Kratie.parent = this;
	this.KH_Kratie.setTransform(1108.35,2059.75);

	this.KH_Mondulkiri = new lib.Symbol3_2();
	this.KH_Mondulkiri.name = "KH_Mondulkiri";
	this.KH_Mondulkiri.parent = this;
	this.KH_Mondulkiri.setTransform(1279.35,2008.75);

	this.KH_Rattanakiri = new lib.Symbol3_2();
	this.KH_Rattanakiri.name = "KH_Rattanakiri";
	this.KH_Rattanakiri.parent = this;
	this.KH_Rattanakiri.setTransform(1268.35,1826.8);

	this.KH_StungTreng = new lib.Symbol3_2();
	this.KH_StungTreng.name = "KH_StungTreng";
	this.KH_StungTreng.parent = this;
	this.KH_StungTreng.setTransform(1136.55,1842.8);

	this.KH_Kohker = new lib.Symbol3_2();
	this.KH_Kohker.name = "KH_Kohker";
	this.KH_Kohker.parent = this;
	this.KH_Kohker.setTransform(828.85,1807.3);

	this.KH_PreahVihear = new lib.Symbol3_2();
	this.KH_PreahVihear.name = "KH_PreahVihear";
	this.KH_PreahVihear.parent = this;
	this.KH_PreahVihear.setTransform(933.85,1768.1);

	this.LA_IledeKhnong = new lib.Symbol3_2();
	this.LA_IledeKhnong.name = "LA_IledeKhnong";
	this.LA_IledeKhnong.parent = this;
	this.LA_IledeKhnong.setTransform(1070.85,1759.8);

	this.LA_Champassak = new lib.Symbol3_2();
	this.LA_Champassak.name = "LA_Champassak";
	this.LA_Champassak.parent = this;
	this.LA_Champassak.setTransform(1060.35,1553.8);

	this.LA_BanKhietNgong = new lib.Symbol3_2();
	this.LA_BanKhietNgong.name = "LA_BanKhietNgong";
	this.LA_BanKhietNgong.parent = this;
	this.LA_BanKhietNgong.setTransform(1095.35,1653.3);

	this.LA_Attapeu = new lib.Symbol3_2();
	this.LA_Attapeu.name = "LA_Attapeu";
	this.LA_Attapeu.parent = this;
	this.LA_Attapeu.setTransform(1277.85,1633.8);

	this.LA_DonDeang = new lib.Symbol3_2();
	this.LA_DonDeang.name = "LA_DonDeang";
	this.LA_DonDeang.parent = this;
	this.LA_DonDeang.setTransform(1080.85,1593.6);

	this.LA_WatPhou = new lib.Symbol3_2();
	this.LA_WatPhou.name = "LA_WatPhou";
	this.LA_WatPhou.parent = this;
	this.LA_WatPhou.setTransform(1052.85,1618.8);

	this.LA_Savannakhet = new lib.Symbol3_2();
	this.LA_Savannakhet.name = "LA_Savannakhet";
	this.LA_Savannakhet.parent = this;
	this.LA_Savannakhet.setTransform(876.35,1364.8);

	this.LA_Thakek = new lib.Symbol3_2();
	this.LA_Thakek.name = "LA_Thakek";
	this.LA_Thakek.parent = this;
	this.LA_Thakek.setTransform(894.35,1193.8);

	this.LA_Kenethao = new lib.Symbol3_2();
	this.LA_Kenethao.name = "LA_Kenethao";
	this.LA_Kenethao.parent = this;
	this.LA_Kenethao.setTransform(296.4,1109.85);

	this.LA_Vientiane = new lib.Symbol3_2();
	this.LA_Vientiane.name = "LA_Vientiane";
	this.LA_Vientiane.parent = this;
	this.LA_Vientiane.setTransform(474.9,1078.35);

	this.LA_Pakxan = new lib.Symbol3_2();
	this.LA_Pakxan.name = "LA_Pakxan";
	this.LA_Pakxan.parent = this;
	this.LA_Pakxan.setTransform(670.35,996.35);

	this.LA_NamNgum = new lib.Symbol3_2();
	this.LA_NamNgum.name = "LA_NamNgum";
	this.LA_NamNgum.parent = this;
	this.LA_NamNgum.setTransform(514.85,969.85);

	this.LA_VangVieng = new lib.Symbol3_2();
	this.LA_VangVieng.name = "LA_VangVieng";
	this.LA_VangVieng.parent = this;
	this.LA_VangVieng.setTransform(453.4,886.85);

	this.LA_Phonxavan = new lib.Symbol3_2();
	this.LA_Phonxavan.name = "LA_Phonxavan";
	this.LA_Phonxavan.parent = this;
	this.LA_Phonxavan.setTransform(581.85,799.85);

	this.LA_MuangKham = new lib.Symbol3_2();
	this.LA_MuangKham.name = "LA_MuangKham";
	this.LA_MuangKham.parent = this;
	this.LA_MuangKham.setTransform(663.85,769.85);

	this.LA_LuangPrabang = new lib.Symbol3_2();
	this.LA_LuangPrabang.name = "LA_LuangPrabang";
	this.LA_LuangPrabang.parent = this;
	this.LA_LuangPrabang.setTransform(402.35,733.35);

	this.LA_Hongsa = new lib.Symbol3_2();
	this.LA_Hongsa.name = "LA_Hongsa";
	this.LA_Hongsa.parent = this;
	this.LA_Hongsa.setTransform(238.4,755.55);

	this.LA_Houixai = new lib.Symbol3_2();
	this.LA_Houixai.name = "LA_Houixai";
	this.LA_Houixai.parent = this;
	this.LA_Houixai.setTransform(90.4,632.35);

	this.LA_MuangSing = new lib.Symbol3_2();
	this.LA_MuangSing.name = "LA_MuangSing";
	this.LA_MuangSing.parent = this;
	this.LA_MuangSing.setTransform(225.9,466.35);

	this.LA_LuangNamtha = new lib.Symbol3_2();
	this.LA_LuangNamtha.name = "LA_LuangNamtha";
	this.LA_LuangNamtha.parent = this;
	this.LA_LuangNamtha.setTransform(266.9,499.85);

	this.LA_Oudomxai = new lib.Symbol3_2();
	this.LA_Oudomxai.name = "LA_Oudomxai";
	this.LA_Oudomxai.parent = this;
	this.LA_Oudomxai.setTransform(356.9,595.05);

	this.LA_NongKhiaw = new lib.Symbol3_2();
	this.LA_NongKhiaw.name = "LA_NongKhiaw";
	this.LA_NongKhiaw.parent = this;
	this.LA_NongKhiaw.setTransform(505.9,613.35);

	this.LA_MuongKhua = new lib.Symbol3_2();
	this.LA_MuongKhua.name = "LA_MuongKhua";
	this.LA_MuongKhua.parent = this;
	this.LA_MuongKhua.setTransform(451.4,528.35);

	this.LA_Phongsali = new lib.Symbol3_2();
	this.LA_Phongsali.name = "LA_Phongsali";
	this.LA_Phongsali.parent = this;
	this.LA_Phongsali.setTransform(394.4,424.35);

	this.VN_CaMau = new lib.Symbol3_2();
	this.VN_CaMau.name = "VN_CaMau";
	this.VN_CaMau.parent = this;
	this.VN_CaMau.setTransform(913.85,2712.75);

	this.VN_PhuQuoc = new lib.Symbol3_2();
	this.VN_PhuQuoc.name = "VN_PhuQuoc";
	this.VN_PhuQuoc.parent = this;
	this.VN_PhuQuoc.setTransform(747.35,2584.25);

	this.VN_HaTien = new lib.Symbol3_2();
	this.VN_HaTien.name = "VN_HaTien";
	this.VN_HaTien.parent = this;
	this.VN_HaTien.setTransform(821.85,2468.25);

	this.VN_RachGia = new lib.Symbol3_2();
	this.VN_RachGia.name = "VN_RachGia";
	this.VN_RachGia.parent = this;
	this.VN_RachGia.setTransform(924.6,2530.75);

	this.VN_BacLieu = new lib.Symbol3_2();
	this.VN_BacLieu.name = "VN_BacLieu";
	this.VN_BacLieu.parent = this;
	this.VN_BacLieu.setTransform(1016.35,2681.75);

	this.VN_SocTrang = new lib.Symbol3_2();
	this.VN_SocTrang.name = "VN_SocTrang";
	this.VN_SocTrang.parent = this;
	this.VN_SocTrang.setTransform(1078.85,2636.75);

	this.VN_CanTho = new lib.Symbol3_2();
	this.VN_CanTho.name = "VN_CanTho";
	this.VN_CanTho.parent = this;
	this.VN_CanTho.setTransform(1060.85,2544.75);

	this.VN_TraVinh = new lib.Symbol3_2();
	this.VN_TraVinh.name = "VN_TraVinh";
	this.VN_TraVinh.parent = this;
	this.VN_TraVinh.setTransform(1163.85,2556.75);

	this.VN_BenTre = new lib.Symbol3_2();
	this.VN_BenTre.name = "VN_BenTre";
	this.VN_BenTre.parent = this;
	this.VN_BenTre.setTransform(1204.35,2498.75);

	this.VN_CaiBe = new lib.Symbol3_2();
	this.VN_CaiBe.name = "VN_CaiBe";
	this.VN_CaiBe.parent = this;
	this.VN_CaiBe.setTransform(1109.85,2476.25);

	this.VN_VinhLong = new lib.Symbol3_2();
	this.VN_VinhLong.name = "VN_VinhLong";
	this.VN_VinhLong.parent = this;
	this.VN_VinhLong.setTransform(1116.85,2508.75);

	this.VN_BangLang = new lib.Symbol3_2();
	this.VN_BangLang.name = "VN_BangLang";
	this.VN_BangLang.parent = this;
	this.VN_BangLang.setTransform(1010.35,2503.75);

	this.VN_LongXuyen = new lib.Symbol3_2();
	this.VN_LongXuyen.name = "VN_LongXuyen";
	this.VN_LongXuyen.parent = this;
	this.VN_LongXuyen.setTransform(1002.35,2458.75);

	this.VN_TraSu = new lib.Symbol3_2();
	this.VN_TraSu.name = "VN_TraSu";
	this.VN_TraSu.parent = this;
	this.VN_TraSu.setTransform(933.85,2442.75);

	this.VN_ChauDoc = new lib.Symbol3_2();
	this.VN_ChauDoc.name = "VN_ChauDoc";
	this.VN_ChauDoc.parent = this;
	this.VN_ChauDoc.setTransform(930.85,2405.75);

	this.VN_SaDec = new lib.Symbol3_2();
	this.VN_SaDec.name = "VN_SaDec";
	this.VN_SaDec.parent = this;
	this.VN_SaDec.setTransform(1071.35,2484.75);

	this.VN_CaiLay = new lib.Symbol3_2();
	this.VN_CaiLay.name = "VN_CaiLay";
	this.VN_CaiLay.parent = this;
	this.VN_CaiLay.setTransform(1124.35,2448.75);

	this.VN_MyTho = new lib.Symbol3_2();
	this.VN_MyTho.name = "VN_MyTho";
	this.VN_MyTho.parent = this;
	this.VN_MyTho.setTransform(1201.35,2467.25);

	this.VN_VungTau = new lib.Symbol3_2();
	this.VN_VungTau.name = "VN_VungTau";
	this.VN_VungTau.parent = this;
	this.VN_VungTau.setTransform(1341.3,2462.25);

	this.VN_MocBai = new lib.Symbol3_2();
	this.VN_MocBai.name = "VN_MocBai";
	this.VN_MocBai.parent = this;
	this.VN_MocBai.setTransform(1150.85,2322.25);

	this.VN_HoChiMinhCity = new lib.Symbol3_2();
	this.VN_HoChiMinhCity.name = "VN_HoChiMinhCity";
	this.VN_HoChiMinhCity.parent = this;
	this.VN_HoChiMinhCity.setTransform(1232.35,2380.75);

	this.VN_CuChi = new lib.Symbol3_2();
	this.VN_CuChi.name = "VN_CuChi";
	this.VN_CuChi.parent = this;
	this.VN_CuChi.setTransform(1195.85,2353.75);

	this.VN_TayNinh = new lib.Symbol3_2();
	this.VN_TayNinh.name = "VN_TayNinh";
	this.VN_TayNinh.parent = this;
	this.VN_TayNinh.setTransform(1149.85,2283.5);

	this.VN_DongXoai = new lib.Symbol3_2();
	this.VN_DongXoai.name = "VN_DongXoai";
	this.VN_DongXoai.parent = this;
	this.VN_DongXoai.setTransform(1286.35,2265.5);

	this.VN_MuiNe = new lib.Symbol3_2();
	this.VN_MuiNe.name = "VN_MuiNe";
	this.VN_MuiNe.parent = this;
	this.VN_MuiNe.setTransform(1624.25,2325.25);

	this.VN_NinhGia = new lib.Symbol3_2();
	this.VN_NinhGia.name = "VN_NinhGia";
	this.VN_NinhGia.parent = this;
	this.VN_NinhGia.setTransform(1530.8,2216.75);

	this.VN_GiaNghia = new lib.Symbol3_2();
	this.VN_GiaNghia.name = "VN_GiaNghia";
	this.VN_GiaNghia.parent = this;
	this.VN_GiaNghia.setTransform(1408.3,2135.25);

	this.VN_DaLat = new lib.Symbol3_2();
	this.VN_DaLat.name = "VN_DaLat";
	this.VN_DaLat.parent = this;
	this.VN_DaLat.setTransform(1544.95,2157.25);

	this.VN_LacLake = new lib.Symbol3_2();
	this.VN_LacLake.name = "VN_LacLake";
	this.VN_LacLake.parent = this;
	this.VN_LacLake.setTransform(1490.35,2013.75);

	this.VN_BuonMeThuot = new lib.Symbol3_2();
	this.VN_BuonMeThuot.name = "VN_BuonMeThuot";
	this.VN_BuonMeThuot.parent = this;
	this.VN_BuonMeThuot.setTransform(1483.3,1977.75);

	this.VN_NhaTrang = new lib.Symbol3_2();
	this.VN_NhaTrang.name = "VN_NhaTrang";
	this.VN_NhaTrang.parent = this;
	this.VN_NhaTrang.setTransform(1734.25,2022.25);

	this.VN_BuonHo = new lib.Symbol3_2();
	this.VN_BuonHo.name = "VN_BuonHo";
	this.VN_BuonHo.parent = this;
	this.VN_BuonHo.setTransform(1503.3,1943.3);

	this.VN_Pleiku = new lib.Symbol3_2();
	this.VN_Pleiku.name = "VN_Pleiku";
	this.VN_Pleiku.parent = this;
	this.VN_Pleiku.setTransform(1484.3,1839.3);

	this.VN_QuyNhon = new lib.Symbol3_2();
	this.VN_QuyNhon.name = "VN_QuyNhon";
	this.VN_QuyNhon.parent = this;
	this.VN_QuyNhon.setTransform(1711.75,1851.3);

	this.VN_KonTum = new lib.Symbol3_2();
	this.VN_KonTum.name = "VN_KonTum";
	this.VN_KonTum.parent = this;
	this.VN_KonTum.setTransform(1463.8,1802.3);

	this.VN_BoY = new lib.Symbol3_2();
	this.VN_BoY.name = "VN_BoY";
	this.VN_BoY.parent = this;
	this.VN_BoY.setTransform(1373,1741.8);

	this.VN_SonHa = new lib.Symbol3_2();
	this.VN_SonHa.name = "VN_SonHa";
	this.VN_SonHa.parent = this;
	this.VN_SonHa.setTransform(1577.8,1710.8);

	this.VN_QuangNgai = new lib.Symbol3_2();
	this.VN_QuangNgai.name = "VN_QuangNgai";
	this.VN_QuangNgai.parent = this;
	this.VN_QuangNgai.setTransform(1659.25,1669.3);

	this.VN_PhuocSon = new lib.Symbol3_2();
	this.VN_PhuocSon.name = "VN_PhuocSon";
	this.VN_PhuocSon.parent = this;
	this.VN_PhuocSon.setTransform(1435.3,1561.8);

	this.VN_CuLaoCham = new lib.Symbol3_2();
	this.VN_CuLaoCham.name = "VN_CuLaoCham";
	this.VN_CuLaoCham.parent = this;
	this.VN_CuLaoCham.setTransform(1656.25,1462.1);

	this.VN_HoiAn = new lib.Symbol3_2();
	this.VN_HoiAn.name = "VN_HoiAn";
	this.VN_HoiAn.parent = this;
	this.VN_HoiAn.setTransform(1555.1,1465.1);

	this.VN_NamGiang = new lib.Symbol3_2();
	this.VN_NamGiang.name = "VN_NamGiang";
	this.VN_NamGiang.parent = this;
	this.VN_NamGiang.setTransform(1366.8,1496.8);

	this.VN_DongGiang = new lib.Symbol3_2();
	this.VN_DongGiang.name = "VN_DongGiang";
	this.VN_DongGiang.parent = this;
	this.VN_DongGiang.setTransform(1415.3,1434.8);

	this.VN_DaNang = new lib.Symbol3_2();
	this.VN_DaNang.name = "VN_DaNang";
	this.VN_DaNang.parent = this;
	this.VN_DaNang.setTransform(1521.8,1433.8);

	this.VN_MySon = new lib.Symbol3_2();
	this.VN_MySon.name = "VN_MySon";
	this.VN_MySon.parent = this;
	this.VN_MySon.setTransform(1486.3,1485.8);

	this.VN_ARoang = new lib.Symbol3_2();
	this.VN_ARoang.name = "VN_ARoang";
	this.VN_ARoang.parent = this;
	this.VN_ARoang.setTransform(1347.3,1408.8);

	this.VN_Hue = new lib.Symbol3_2();
	this.VN_Hue.name = "VN_Hue";
	this.VN_Hue.parent = this;
	this.VN_Hue.setTransform(1401,1366.8);

	this.VN_QuangTri = new lib.Symbol3_2();
	this.VN_QuangTri.name = "VN_QuangTri";
	this.VN_QuangTri.parent = this;
	this.VN_QuangTri.setTransform(1344.3,1311.3);

	this.VN_VinhMocTunnels = new lib.Symbol3_2();
	this.VN_VinhMocTunnels.name = "VN_VinhMocTunnels";
	this.VN_VinhMocTunnels.parent = this;
	this.VN_VinhMocTunnels.setTransform(1346.3,1271.3);

	this.VN_DongHoi = new lib.Symbol3_2();
	this.VN_DongHoi.name = "VN_DongHoi";
	this.VN_DongHoi.parent = this;
	this.VN_DongHoi.setTransform(1215.85,1175.8);

	this.VN_HaTinh = new lib.Symbol3_2();
	this.VN_HaTinh.name = "VN_HaTinh";
	this.VN_HaTinh.parent = this;
	this.VN_HaTinh.setTransform(1099.3,1023.8);

	this.VN_CauTreo = new lib.Symbol3_2();
	this.VN_CauTreo.name = "VN_CauTreo";
	this.VN_CauTreo.parent = this;
	this.VN_CauTreo.setTransform(963.35,1012.8);

	this.VN_NamCan = new lib.Symbol3_2();
	this.VN_NamCan.name = "VN_NamCan";
	this.VN_NamCan.parent = this;
	this.VN_NamCan.setTransform(739.85,804.85);

	this.VN_Vinh = new lib.Symbol3_2();
	this.VN_Vinh.name = "VN_Vinh";
	this.VN_Vinh.parent = this;
	this.VN_Vinh.setTransform(1049.35,950.35);

	this.VN_ThanhHoa = new lib.Symbol3_2();
	this.VN_ThanhHoa.name = "VN_ThanhHoa";
	this.VN_ThanhHoa.parent = this;
	this.VN_ThanhHoa.setTransform(1037.3,796.95);

	this.VN_MuongHum = new lib.Symbol3_2();
	this.VN_MuongHum.name = "VN_MuongHum";
	this.VN_MuongHum.parent = this;
	this.VN_MuongHum.setTransform(673.85,241.85);

	this.VN_DuGia = new lib.Symbol3_2();
	this.VN_DuGia.name = "VN_DuGia";
	this.VN_DuGia.parent = this;
	this.VN_DuGia.setTransform(951.4,169.35);

	this.VN_BaKhe = new lib.Symbol3_2();
	this.VN_BaKhe.name = "VN_BaKhe";
	this.VN_BaKhe.parent = this;
	this.VN_BaKhe.setTransform(892.4,474.55);

	this.VN_BacMe = new lib.Symbol3_2();
	this.VN_BacMe.name = "VN_BacMe";
	this.VN_BacMe.parent = this;
	this.VN_BacMe.setTransform(976.85,224.35);

	this.VN_BacHa = new lib.Symbol3_2();
	this.VN_BacHa.name = "VN_BacHa";
	this.VN_BacHa.parent = this;
	this.VN_BacHa.setTransform(803.35,257.35);

	this.VN_CanCau = new lib.Symbol3_2();
	this.VN_CanCau.name = "VN_CanCau";
	this.VN_CanCau.parent = this;
	this.VN_CanCau.setTransform(804.35,229.85);

	this.VN_HoangSuPhi = new lib.Symbol3_2();
	this.VN_HoangSuPhi.name = "VN_HoangSuPhi";
	this.VN_HoangSuPhi.parent = this;
	this.VN_HoangSuPhi.setTransform(860.85,217.35);

	this.VN_MeoVac = new lib.Symbol3_2();
	this.VN_MeoVac.name = "VN_MeoVac";
	this.VN_MeoVac.parent = this;
	this.VN_MeoVac.setTransform(1001.3,141.4);

	this.VN_DongVan = new lib.Symbol3_2();
	this.VN_DongVan.name = "VN_DongVan";
	this.VN_DongVan.parent = this;
	this.VN_DongVan.setTransform(982.85,111.9);

	this.VN_LungCu = new lib.Symbol3_2();
	this.VN_LungCu.name = "VN_LungCu";
	this.VN_LungCu.parent = this;
	this.VN_LungCu.setTransform(975.3,81.4);

	this.VN_YenMinh = new lib.Symbol3_2();
	this.VN_YenMinh.name = "VN_YenMinh";
	this.VN_YenMinh.parent = this;
	this.VN_YenMinh.setTransform(933.85,136.4);

	this.VN_QuanBa = new lib.Symbol3_2();
	this.VN_QuanBa.name = "VN_QuanBa";
	this.VN_QuanBa.parent = this;
	this.VN_QuanBa.setTransform(902.3,150.9);

	this.VN_XinMan = new lib.Symbol3_2();
	this.VN_XinMan.name = "VN_XinMan";
	this.VN_XinMan.parent = this;
	this.VN_XinMan.setTransform(837.3,196.9);

	this.VN_SinCheng = new lib.Symbol3_2();
	this.VN_SinCheng.name = "VN_SinCheng";
	this.VN_SinCheng.parent = this;
	this.VN_SinCheng.setTransform(784.85,219.4);

	this.VN_LungKhauNhin = new lib.Symbol3_2();
	this.VN_LungKhauNhin.name = "VN_LungKhauNhin";
	this.VN_LungKhauNhin.parent = this;
	this.VN_LungKhauNhin.setTransform(744.85,199.35);

	this.VN_CaoSon = new lib.Symbol3_2();
	this.VN_CaoSon.name = "VN_CaoSon";
	this.VN_CaoSon.parent = this;
	this.VN_CaoSon.setTransform(744.35,221.85);

	this.VN_CocLy = new lib.Symbol3_2();
	this.VN_CocLy.name = "VN_CocLy";
	this.VN_CocLy.parent = this;
	this.VN_CocLy.setTransform(765.05,236.15);

	this.VN_LaoCai = new lib.Symbol3_2();
	this.VN_LaoCai.name = "VN_LaoCai";
	this.VN_LaoCai.parent = this;
	this.VN_LaoCai.setTransform(717.85,245.85);

	this.VN_LaiChau = new lib.Symbol3_2();
	this.VN_LaiChau.name = "VN_LaiChau";
	this.VN_LaiChau.parent = this;
	this.VN_LaiChau.setTransform(638.85,261.85);

	this.VN_Sapa = new lib.Symbol3_2();
	this.VN_Sapa.name = "VN_Sapa";
	this.VN_Sapa.parent = this;
	this.VN_Sapa.setTransform(699.85,284.35);

	this.VN_BinhLu = new lib.Symbol3_2();
	this.VN_BinhLu.name = "VN_BinhLu";
	this.VN_BinhLu.parent = this;
	this.VN_BinhLu.setTransform(679.85,295.35);

	this.VN_SinHo = new lib.Symbol3_2();
	this.VN_SinHo.name = "VN_SinHo";
	this.VN_SinHo.parent = this;
	this.VN_SinHo.setTransform(590.85,291.85);

	this.VN_TayTrang = new lib.Symbol3_2();
	this.VN_TayTrang.name = "VN_TayTrang";
	this.VN_TayTrang.parent = this;
	this.VN_TayTrang.setTransform(524.35,491.85);

	this.VN_DienBienPhu = new lib.Symbol3_2();
	this.VN_DienBienPhu.name = "VN_DienBienPhu";
	this.VN_DienBienPhu.parent = this;
	this.VN_DienBienPhu.setTransform(544.85,445.05);

	this.VN_ThanUyen = new lib.Symbol3_2();
	this.VN_ThanUyen.name = "VN_ThanUyen";
	this.VN_ThanUyen.parent = this;
	this.VN_ThanUyen.setTransform(719.85,353.85);

	this.VN_MuCangChai = new lib.Symbol3_2();
	this.VN_MuCangChai.name = "VN_MuCangChai";
	this.VN_MuCangChai.parent = this;
	this.VN_MuCangChai.setTransform(789.85,396.85);

	this.VN_NghiaLo = new lib.Symbol3_2();
	this.VN_NghiaLo.name = "VN_NghiaLo";
	this.VN_NghiaLo.parent = this;
	this.VN_NghiaLo.setTransform(879.35,458.35);

	this.VN_PhuYen = new lib.Symbol3_2();
	this.VN_PhuYen.name = "VN_PhuYen";
	this.VN_PhuYen.parent = this;
	this.VN_PhuYen.setTransform(864.6,482.85);

	this.VN_SonLa = new lib.Symbol3_2();
	this.VN_SonLa.name = "VN_SonLa";
	this.VN_SonLa.parent = this;
	this.VN_SonLa.setTransform(741.35,498.1);

	this.VN_PuLuong = new lib.Symbol3_2();
	this.VN_PuLuong.name = "VN_PuLuong";
	this.VN_PuLuong.parent = this;
	this.VN_PuLuong.setTransform(957.85,646.85);

	this.VN_MocChau = new lib.Symbol3_2();
	this.VN_MocChau.name = "VN_MocChau";
	this.VN_MocChau.parent = this;
	this.VN_MocChau.setTransform(890.85,567.2);

	this.VN_MaiChau = new lib.Symbol3_2();
	this.VN_MaiChau.name = "VN_MaiChau";
	this.VN_MaiChau.parent = this;
	this.VN_MaiChau.setTransform(965.3,583.05);

	this.VN_DuongLam = new lib.Symbol3_2();
	this.VN_DuongLam.name = "VN_DuongLam";
	this.VN_DuongLam.parent = this;
	this.VN_DuongLam.setTransform(983.85,496.85);

	this.VN_ThacBa = new lib.Symbol3_2();
	this.VN_ThacBa.name = "VN_ThacBa";
	this.VN_ThacBa.parent = this;
	this.VN_ThacBa.setTransform(981.85,405.85);

	this.VN_TuyenQuang = new lib.Symbol3_2();
	this.VN_TuyenQuang.name = "VN_TuyenQuang";
	this.VN_TuyenQuang.parent = this;
	this.VN_TuyenQuang.setTransform(1006.75,396.05);

	this.VN_ThaiNguyen = new lib.Symbol3_2();
	this.VN_ThaiNguyen.name = "VN_ThaiNguyen";
	this.VN_ThaiNguyen.parent = this;
	this.VN_ThaiNguyen.setTransform(1072.25,415.35);

	this.VN_BacSon = new lib.Symbol3_2();
	this.VN_BacSon.name = "VN_BacSon";
	this.VN_BacSon.parent = this;
	this.VN_BacSon.setTransform(1140.85,337.85);

	this.VN_HaGiang = new lib.Symbol3_2();
	this.VN_HaGiang.name = "VN_HaGiang";
	this.VN_HaGiang.parent = this;
	this.VN_HaGiang.setTransform(897.55,203.05);

	this.VN_BaBe = new lib.Symbol3_2();
	this.VN_BaBe.name = "VN_BaBe";
	this.VN_BaBe.parent = this;
	this.VN_BaBe.setTransform(1055.85,269.35);

	this.VN_BaoLac = new lib.Symbol3_2();
	this.VN_BaoLac.name = "VN_BaoLac";
	this.VN_BaoLac.parent = this;
	this.VN_BaoLac.setTransform(1084.85,192.65);

	this.VN_CaoBang = new lib.Symbol3_2();
	this.VN_CaoBang.name = "VN_CaoBang";
	this.VN_CaoBang.parent = this;
	this.VN_CaoBang.setTransform(1158.8,221.35);

	this.VN_BanGioc = new lib.Symbol3_2();
	this.VN_BanGioc.name = "VN_BanGioc";
	this.VN_BanGioc.parent = this;
	this.VN_BanGioc.setTransform(1245.85,183.85);

	this.VN_QuangUyen = new lib.Symbol3_2();
	this.VN_QuangUyen.name = "VN_QuangUyen";
	this.VN_QuangUyen.parent = this;
	this.VN_QuangUyen.setTransform(1203.85,224.85);

	this.VN_DongKhe = new lib.Symbol3_2();
	this.VN_DongKhe.name = "VN_DongKhe";
	this.VN_DongKhe.parent = this;
	this.VN_DongKhe.setTransform(1196.85,255.35);

	this.VN_ThatKhe = new lib.Symbol3_2();
	this.VN_ThatKhe.name = "VN_ThatKhe";
	this.VN_ThatKhe.parent = this;
	this.VN_ThatKhe.setTransform(1213.85,306.35);

	this.VN_LangSon = new lib.Symbol3_2();
	this.VN_LangSon.name = "VN_LangSon";
	this.VN_LangSon.parent = this;
	this.VN_LangSon.setTransform(1242.85,357.35);

	this.VN_BacGiang = new lib.Symbol3_2();
	this.VN_BacGiang.name = "VN_BacGiang";
	this.VN_BacGiang.parent = this;
	this.VN_BacGiang.setTransform(1117.35,480.35);

	this.VN_BacNinh = new lib.Symbol3_2();
	this.VN_BacNinh.name = "VN_BacNinh";
	this.VN_BacNinh.parent = this;
	this.VN_BacNinh.setTransform(1100.55,510.85);

	this.VN_HoaBinh = new lib.Symbol3_2();
	this.VN_HoaBinh.name = "VN_HoaBinh";
	this.VN_HoaBinh.parent = this;
	this.VN_HoaBinh.setTransform(1023.35,574.85);

	this.VN_NinhBinh = new lib.Symbol3_2();
	this.VN_NinhBinh.name = "VN_NinhBinh";
	this.VN_NinhBinh.parent = this;
	this.VN_NinhBinh.setTransform(1102.85,658.85);

	this.VN_NamDinh = new lib.Symbol3_2();
	this.VN_NamDinh.name = "VN_NamDinh";
	this.VN_NamDinh.parent = this;
	this.VN_NamDinh.setTransform(1145.35,647.35);

	this.VN_ThaiBinh = new lib.Symbol3_2();
	this.VN_ThaiBinh.name = "VN_ThaiBinh";
	this.VN_ThaiBinh.parent = this;
	this.VN_ThaiBinh.setTransform(1176.35,628.35);

	this.VN_HaLong = new lib.Symbol3_2();
	this.VN_HaLong.name = "VN_HaLong";
	this.VN_HaLong.parent = this;
	this.VN_HaLong.setTransform(1275.85,535.85);

	this.VN_HaiPhong = new lib.Symbol3_2();
	this.VN_HaiPhong.name = "VN_HaiPhong";
	this.VN_HaiPhong.parent = this;
	this.VN_HaiPhong.setTransform(1216.35,591.7);

	this.VN_MongCai = new lib.Symbol3_2();
	this.VN_MongCai.name = "VN_MongCai";
	this.VN_MongCai.parent = this;
	this.VN_MongCai.setTransform(1494.35,427.55);

	this.VN_TienYen = new lib.Symbol3_2();
	this.VN_TienYen.name = "VN_TienYen";
	this.VN_TienYen.parent = this;
	this.VN_TienYen.setTransform(1374,458.35);

	this.VN_CatBa = new lib.Symbol3_2();
	this.VN_CatBa.name = "VN_CatBa";
	this.VN_CatBa.parent = this;
	this.VN_CatBa.setTransform(1301.35,590.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.VN_CatBa},{t:this.VN_TienYen},{t:this.VN_MongCai},{t:this.VN_HaiPhong},{t:this.VN_HaLong},{t:this.VN_ThaiBinh},{t:this.VN_NamDinh},{t:this.VN_NinhBinh},{t:this.VN_HoaBinh},{t:this.VN_BacNinh},{t:this.VN_BacGiang},{t:this.VN_LangSon},{t:this.VN_ThatKhe},{t:this.VN_DongKhe},{t:this.VN_QuangUyen},{t:this.VN_BanGioc},{t:this.VN_CaoBang},{t:this.VN_BaoLac},{t:this.VN_BaBe},{t:this.VN_HaGiang},{t:this.VN_BacSon},{t:this.VN_ThaiNguyen},{t:this.VN_TuyenQuang},{t:this.VN_ThacBa},{t:this.VN_DuongLam},{t:this.VN_MaiChau},{t:this.VN_MocChau},{t:this.VN_PuLuong},{t:this.VN_SonLa},{t:this.VN_PhuYen},{t:this.VN_NghiaLo},{t:this.VN_MuCangChai},{t:this.VN_ThanUyen},{t:this.VN_DienBienPhu},{t:this.VN_TayTrang},{t:this.VN_SinHo},{t:this.VN_BinhLu},{t:this.VN_Sapa},{t:this.VN_LaiChau},{t:this.VN_LaoCai},{t:this.VN_CocLy},{t:this.VN_CaoSon},{t:this.VN_LungKhauNhin},{t:this.VN_SinCheng},{t:this.VN_XinMan},{t:this.VN_QuanBa},{t:this.VN_YenMinh},{t:this.VN_LungCu},{t:this.VN_DongVan},{t:this.VN_MeoVac},{t:this.VN_HoangSuPhi},{t:this.VN_CanCau},{t:this.VN_BacHa},{t:this.VN_BacMe},{t:this.VN_BaKhe},{t:this.VN_DuGia},{t:this.VN_MuongHum},{t:this.VN_ThanhHoa},{t:this.VN_Vinh},{t:this.VN_NamCan},{t:this.VN_CauTreo},{t:this.VN_HaTinh},{t:this.VN_DongHoi},{t:this.VN_VinhMocTunnels},{t:this.VN_QuangTri},{t:this.VN_Hue},{t:this.VN_ARoang},{t:this.VN_MySon},{t:this.VN_DaNang},{t:this.VN_DongGiang},{t:this.VN_NamGiang},{t:this.VN_HoiAn},{t:this.VN_CuLaoCham},{t:this.VN_PhuocSon},{t:this.VN_QuangNgai},{t:this.VN_SonHa},{t:this.VN_BoY},{t:this.VN_KonTum},{t:this.VN_QuyNhon},{t:this.VN_Pleiku},{t:this.VN_BuonHo},{t:this.VN_NhaTrang},{t:this.VN_BuonMeThuot},{t:this.VN_LacLake},{t:this.VN_DaLat},{t:this.VN_GiaNghia},{t:this.VN_NinhGia},{t:this.VN_MuiNe},{t:this.VN_DongXoai},{t:this.VN_TayNinh},{t:this.VN_CuChi},{t:this.VN_HoChiMinhCity},{t:this.VN_MocBai},{t:this.VN_VungTau},{t:this.VN_MyTho},{t:this.VN_CaiLay},{t:this.VN_SaDec},{t:this.VN_ChauDoc},{t:this.VN_TraSu},{t:this.VN_LongXuyen},{t:this.VN_BangLang},{t:this.VN_VinhLong},{t:this.VN_CaiBe},{t:this.VN_BenTre},{t:this.VN_TraVinh},{t:this.VN_CanTho},{t:this.VN_SocTrang},{t:this.VN_BacLieu},{t:this.VN_RachGia},{t:this.VN_HaTien},{t:this.VN_PhuQuoc},{t:this.VN_CaMau},{t:this.LA_Phongsali},{t:this.LA_MuongKhua},{t:this.LA_NongKhiaw},{t:this.LA_Oudomxai},{t:this.LA_LuangNamtha},{t:this.LA_MuangSing},{t:this.LA_Houixai},{t:this.LA_Hongsa},{t:this.LA_LuangPrabang},{t:this.LA_MuangKham},{t:this.LA_Phonxavan},{t:this.LA_VangVieng},{t:this.LA_NamNgum},{t:this.LA_Pakxan},{t:this.LA_Vientiane},{t:this.LA_Kenethao},{t:this.LA_Thakek},{t:this.LA_Savannakhet},{t:this.LA_WatPhou},{t:this.LA_DonDeang},{t:this.LA_Attapeu},{t:this.LA_BanKhietNgong},{t:this.LA_Champassak},{t:this.LA_IledeKhnong},{t:this.KH_PreahVihear},{t:this.KH_Kohker},{t:this.KH_StungTreng},{t:this.KH_Rattanakiri},{t:this.KH_Mondulkiri},{t:this.KH_Kratie},{t:this.KH_KompongThom},{t:this.KH_KohTrong},{t:this.KH_KompongCham},{t:this.KH_KompongChhnang},{t:this.KH_PhnomPenh},{t:this.KH_Pursat},{t:this.KH_Battambang},{t:this.KH_TonleSap},{t:this.KH_SiemReap},{t:this.KH_SereiSaoPhoan},{t:this.KH_Takeo},{t:this.KH_Kep},{t:this.KH_Kampot},{t:this.LA_XamNeua},{t:this.VN_MuongLay},{t:this.VN_PhongTho},{t:this.VN_VinhPhuc},{t:this.LA_MuangNgoy},{t:this.VN_PhanRang},{t:this.VN_BaoLoc},{t:this.VN_LySon},{t:this.VN_TuyHoa},{t:this.VN_BinhBa},{t:this.VN_ConDao},{t:this.KH_Sihanoukville},{t:this.LA_PlainOfJars},{t:this.VN_TuanGiao},{t:this.VN_TanTrao},{t:this.VN_PhongNha},{t:this.VN_KheXanh},{t:this.VN_PhanThiet},{t:this.KH_BanLung},{t:this.LA_Pakse},{t:this.LA_Laongam},{t:this.LA_Thateng},{t:this.KH_KrongPoiPet},{t:this.VN_HaNoi},{t:this.VN_XuanMai},{t:this.LA_PakBeng},{t:this.VN_CaoLanh},{t:this.VN_BuonDon},{t:this.VN_DraySap},{t:this.LA_Sanamxai},{t:this.LA_Paksong},{t:this.LA_Sekong},{t:this.VN_GotFerry},{t:this.VN_DinhLap},{t:this.VN_TuLe},{t:this.VN_YenThuy},{t:this.VN_TramChim},{t:this.VN_TanChau},{t:this.VN_BacKan},{t:this.VN_PhoRang},{t:this.VN_BacQuang},{t:this.VN_MyLai},{t:this.VN_BachMa},{t:this.VN_ALuoi},{t:this.VN_CatTien},{t:this.VN_DongNai},{t:this.VN_BinhChau},{t:this.VN_TanAn},{t:this.VN_TinhBien}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy_1, new cjs.Rectangle(80.2,70.3,1763.2,2681.3999999999996), null);


(lib.map_viet_nam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.mcDriver = new lib.Symbol19();
	this.mcDriver.name = "mcDriver";
	this.mcDriver.parent = this;
	this.mcDriver.setTransform(23,2672.15);

	this.timeline.addTween(cjs.Tween.get(this.mcDriver).wait(1));

	// Layer_4
	this.mcRoutes = new lib.Symbol1copy_1();
	this.mcRoutes.name = "mcRoutes";
	this.mcRoutes.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.mcRoutes).wait(1));

}).prototype = getMCSymbolPrototype(lib.map_viet_nam, new cjs.Rectangle(23,70.3,1820.4,2734), null);


// stage content:
(lib.ui_viet_nam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.mcGame = new lib.map_viet_nam();
	this.mcGame.name = "mcGame";
	this.mcGame.parent = this;
	this.mcGame.setTransform(4,-6);

	this.timeline.addTween(cjs.Tween.get(this.mcGame).wait(1));

	// Layer_2
	this.map = new lib.Symbol8_1();
	this.map.name = "map";
	this.map.parent = this;
	this.map.setTransform(1028,1421,1,1,0,0,0,1024,1427);

	this.timeline.addTween(cjs.Tween.get(this.map).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1032,1415,1020,1433);
// library properties:
lib.properties = {
	id: '1FD19714E65D4E4DB044A37B9F30D6F9',
	width: 2056,
	height: 2842,
	fps: 24,
	color: "#666666",
	opacity: 1.00,
	manifest: [
		{src:"images/map3nuoc1pngcopy.jpg", id:"map3nuoc1pngcopy"},
		{src:"images/ui_viet_nam_atlas_.png", id:"ui_viet_nam_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['1FD19714E65D4E4DB044A37B9F30D6F9'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;