(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"ui_viet_nam_atlas_", frames: [[1600,1322,89,37],[1879,1798,46,19],[562,1732,62,24],[1315,1412,86,34],[1600,1292,122,28],[1461,411,59,26],[969,1088,50,20],[207,1690,72,24],[1746,1643,73,26],[878,1788,58,19],[802,1528,86,28],[119,1795,53,19],[0,1492,94,28],[1942,1643,80,24],[1431,1579,82,27],[1069,1774,63,20],[1489,1492,93,28],[974,1370,123,25],[723,1291,100,34],[128,1666,77,24],[81,1608,82,26],[1457,1788,57,19],[753,909,133,36],[1431,1608,81,26],[82,1578,80,28],[671,1734,75,20],[1650,1715,68,24],[392,1620,48,42],[47,1682,70,25],[1405,494,46,26],[666,1756,73,19],[400,1776,64,19],[0,1608,79,27],[1829,248,100,100],[853,522,80,78],[1773,1037,66,64],[1274,1090,65,63],[443,1117,64,62],[1549,1142,63,62],[1679,1168,63,61],[812,1191,62,60],[1663,1231,61,59],[599,1259,60,58],[1178,1280,59,58],[0,1309,58,57],[935,523,80,78],[680,1327,58,56],[478,1355,57,55],[1099,1370,56,54],[287,1387,55,54],[1721,1423,54,53],[1864,1439,54,52],[1379,1466,53,51],[1718,1478,52,50],[336,1496,51,50],[1397,1519,50,49],[1811,593,79,77],[252,1548,49,48],[1165,1558,49,47],[1843,1587,48,46],[627,1596,47,46],[1335,1619,46,45],[0,1637,45,44],[831,1642,45,43],[1872,1647,44,43],[1178,1668,43,42],[1396,1691,42,41],[164,617,78,76],[44,1709,41,40],[1293,1710,41,39],[307,1721,40,39],[1605,1735,39,38],[1952,1750,38,37],[361,1762,37,36],[1134,1775,36,35],[81,1775,36,35],[553,1780,35,34],[197,1785,34,33],[80,654,77,75],[1941,1789,33,32],[1281,1795,32,31],[731,1796,32,31],[662,1798,31,30],[817,1558,68,34],[479,254,100,100],[1023,353,88,86],[176,369,86,84],[896,682,76,75],[1703,416,84,81],[814,439,83,81],[899,439,83,81],[984,441,83,80],[1153,487,82,80],[1237,487,82,80],[687,503,81,79],[1797,512,81,79],[770,522,81,78],[332,546,80,78],[159,695,76,74],[250,546,80,78],[496,578,80,77],[913,603,79,77],[994,603,79,77],[1075,649,78,76],[244,626,78,76],[1704,653,78,75],[1784,672,77,75],[1517,659,77,75],[974,682,77,74],[1973,593,75,73],[1315,720,76,74],[393,713,76,74],[471,734,75,73],[77,731,75,73],[1471,736,75,73],[382,789,74,72],[230,780,74,72],[306,780,74,72],[1439,811,73,71],[458,809,73,71],[974,758,74,72],[224,854,72,70],[298,854,72,70],[1588,860,72,70],[1006,873,71,69],[0,879,71,69],[73,879,71,69],[146,917,70,68],[218,926,70,68],[824,947,69,67],[753,947,69,67],[0,806,73,71],[1122,946,69,67],[1426,982,68,66],[142,987,68,66],[1022,984,68,66],[1943,1005,67,65],[505,1012,67,65],[421,1022,66,65],[954,1022,66,64],[1299,1024,66,64],[1207,1083,65,63],[843,351,88,86],[1150,835,72,71],[902,1088,65,63],[835,1088,65,63],[607,1110,64,62],[1341,1116,64,62],[0,1123,63,62],[65,1159,63,61],[130,1167,63,61],[1308,1180,62,61],[1057,1184,62,60],[0,1187,62,60],[1662,860,72,70],[951,1222,61,59],[127,1230,61,59],[1247,1243,60,59],[0,1249,60,58],[844,1253,60,58],[1539,1268,59,58],[123,1291,59,57],[1724,1292,59,57],[1785,1308,58,57],[1624,766,58,56],[446,882,71,69],[60,1343,57,56],[1691,1351,57,55],[1910,1354,57,55],[1606,1361,56,55],[1750,1367,56,54],[0,1368,56,54],[421,1381,55,54],[1664,1408,55,53],[1157,1420,54,53],[1213,1420,54,53],[290,926,70,68],[1088,1426,54,52],[1324,1448,53,52],[1663,1463,53,51],[414,1466,53,51],[846,1475,52,51],[363,1329,52,50],[590,1495,51,50],[1982,1493,51,50],[990,1506,51,49],[389,1519,50,49],[0,950,69,67],[1638,1516,50,49],[1043,1532,50,48],[1977,1545,49,48],[887,1558,49,47],[354,1570,48,47],[1331,1570,48,47],[1032,1582,48,46],[1515,1594,47,46],[1776,1595,47,46],[1893,1600,47,45],[843,247,68,67],[983,1619,46,45],[935,1619,46,45],[1031,1630,45,44],[1825,1635,45,44],[1699,1640,45,43],[523,1645,44,43],[723,1646,44,43],[1561,1663,44,42],[468,1665,43,42],[1262,1666,43,42],[352,1005,67,66],[711,1691,42,41],[584,1689,42,41],[755,1691,42,41],[986,1703,41,40],[628,1700,41,40],[590,1454,41,39],[859,1720,40,39],[901,1720,40,39],[1336,1734,39,38],[1841,1734,39,38],[574,1012,67,65],[1377,1734,39,38],[1762,1746,38,37],[1482,1749,38,37],[1522,1749,38,37],[283,1762,37,36],[244,1762,37,36],[1365,1774,36,35],[981,1767,36,35],[1327,1774,36,35],[2013,1595,35,34],[1705,1037,66,64],[1725,1764,35,34],[1602,1775,35,34],[806,1783,34,33],[842,1783,34,33],[938,1788,33,32],[1551,1788,33,32],[1516,1788,33,32],[764,1421,32,31],[1297,1582,32,31],[47,1637,32,31],[376,1089,65,63],[900,1475,31,30],[543,1559,31,30],[953,1557,68,34],[1578,250,100,100],[1523,352,88,86],[0,369,86,84],[1375,411,84,81],[1875,429,83,81],[1959,0,86,84],[1774,1103,64,63],[353,464,82,80],[1714,499,81,79],[1487,523,80,78],[0,575,80,77],[751,602,79,77],[324,626,78,76],[1863,672,77,75],[1393,720,76,74],[1844,749,75,73],[702,758,75,72],[1982,1138,63,62],[1363,796,74,72],[1855,824,73,71],[1224,870,72,70],[1809,897,71,69],[918,905,71,68],[1589,932,70,68],[434,953,69,67],[282,996,68,66],[817,1016,67,65],[643,1044,66,64],[1614,1168,63,61],[1367,1050,66,64],[190,1102,65,63],[509,1117,64,62],[1744,1168,63,61],[1933,1202,62,60],[1121,1212,61,60],[1726,1231,61,59],[661,1259,60,58],[1371,1296,59,57],[740,1327,58,56],[748,1191,62,60],[119,1350,57,56],[1199,1363,56,55],[363,1381,56,54],[798,1409,55,53],[1920,1439,54,52],[935,1453,53,52],[1198,1475,52,51],[1086,1480,52,50],[900,1507,51,49],[1228,1532,50,48],[1600,1231,61,59],[303,1548,49,48],[404,1571,48,47],[543,1597,47,46],[886,1607,47,45],[1099,523,46,44],[1131,1637,45,44],[1612,1648,44,43],[1918,1669,43,42],[119,1692,42,41],[1866,1692,42,40],[1309,1243,60,59],[446,1709,41,40],[1720,1723,40,39],[1218,1736,39,38],[1992,1750,38,37],[1686,1764,37,36],[0,1766,37,36],[1172,1775,36,35],[1639,1780,35,34],[1762,1785,34,33],[2011,1789,33,32],[1117,1274,59,58],[1976,1789,33,32],[765,1796,32,31],[695,1798,31,30],[1095,1558,68,34],[369,256,100,100],[1113,353,88,86],[264,369,86,84],[1789,416,84,81],[524,1296,59,57],[1461,440,83,81],[1546,440,83,81],[84,493,82,80],[0,493,82,80],[1321,494,82,79],[1880,512,81,79],[1963,512,81,79],[1099,569,80,78],[414,555,80,78],[1569,580,80,77],[418,1323,58,56],[1436,603,79,77],[1355,603,79,77],[1155,651,78,76],[1235,651,78,76],[0,654,78,75],[817,681,77,75],[738,681,77,75],[1209,729,76,74],[1131,729,76,74],[548,758,75,73],[1969,1354,57,55],[1921,749,75,73],[625,758,75,73],[779,797,74,72],[855,797,74,72],[931,832,73,71],[702,832,73,71],[1930,824,73,71],[533,871,72,70],[1298,870,72,70],[1955,897,71,69],[1845,1361,56,55],[1882,897,71,69],[680,905,71,69],[362,935,70,68],[1661,932,70,68],[1355,955,69,67],[1733,968,69,67],[1804,968,68,67],[1496,1002,68,66],[1566,1002,68,66],[1161,1016,67,65],[917,1381,55,54],[1230,1016,67,65],[1022,1052,66,64],[122,1055,66,64],[0,1057,66,64],[1707,1103,65,63],[1640,1103,65,63],[969,1118,64,62],[673,1119,64,62],[1178,1148,63,62],[1407,1172,63,61],[708,1421,54,53],[1472,1172,63,61],[195,1206,62,60],[259,1206,62,60],[1184,1218,61,60],[536,1235,61,59],[1372,1235,61,59],[1931,1264,60,58],[190,1268,60,58],[62,1283,59,58],[1239,1304,59,57],[56,1438,54,52],[1849,1302,59,57],[184,1328,58,56],[244,1328,58,56],[800,1351,57,56],[1360,1355,57,55],[1257,1363,56,55],[859,1381,56,54],[650,1385,56,54],[974,1397,55,54],[478,1412,55,53],[1031,1452,53,52],[0,1424,54,53],[639,1441,54,52],[1976,1439,54,52],[535,1454,53,52],[1434,1466,53,51],[695,1476,52,51],[1831,1493,52,50],[1584,1492,52,50],[749,1500,51,50],[523,1508,51,49],[1144,1475,52,51],[441,1520,50,49],[695,1529,50,48],[1545,1544,49,48],[1792,1545,49,48],[1913,1551,49,47],[166,1570,48,47],[694,1579,48,46],[1082,1594,47,46],[837,1594,47,46],[295,1598,47,45],[283,1496,51,50],[344,1619,46,45],[1153,441,46,44],[676,1627,45,44],[213,1628,45,44],[592,1644,44,43],[260,1645,44,43],[878,1654,44,42],[1315,1363,43,42],[2005,830,43,42],[815,1687,42,41],[1345,1519,50,49],[1130,1683,42,41],[163,1692,42,40],[943,1695,41,40],[1607,1693,41,40],[1910,1713,40,39],[1440,1717,40,39],[0,1726,40,38],[748,1734,39,38],[163,1734,39,38],[204,1746,38,37],[576,1547,49,48],[1029,1743,38,37],[42,1751,37,36],[1418,1758,37,36],[1802,1746,37,36],[454,1571,36,35],[1658,1648,36,35],[1808,1367,35,34],[1613,1418,35,34],[953,1507,35,34],[626,1781,34,33],[643,1546,49,48],[1019,1782,34,33],[592,1597,33,32],[671,1700,33,32],[128,1735,33,32],[334,1176,32,31],[1548,1328,32,31],[643,1012,31,30],[478,1323,31,30],[1690,1556,68,34],[1931,248,100,100],[1381,1570,48,47],[933,351,88,86],[1959,86,86,84],[1289,403,84,82],[729,420,83,81],[269,464,82,80],[185,455,82,80],[1631,499,81,79],[1017,523,80,78],[1964,1595,47,46],[1405,523,80,78],[1892,593,79,77],[578,622,78,76],[658,622,78,76],[484,657,77,75],[237,704,76,74],[315,704,76,74],[0,731,75,73],[1548,766,74,72],[154,771,74,72],[1287,1619,46,45],[75,806,73,71],[1514,840,72,70],[150,845,72,70],[607,871,71,69],[1445,912,70,68],[607,942,69,68],[519,943,69,67],[678,976,68,66],[1636,1002,67,66],[1874,1005,67,65],[1468,1636,45,44],[886,1022,66,64],[1959,1072,65,64],[309,1073,65,63],[1703,352,64,62],[739,1119,63,62],[1243,1155,63,61],[1869,1178,62,61],[1537,1206,61,60],[64,1222,61,59],[1869,1241,60,59],[81,1636,45,44],[252,1268,59,58],[1631,440,59,57],[1300,1304,58,57],[304,1329,57,56],[1569,523,57,55],[1548,1361,56,55],[1993,1264,55,54],[1031,1397,55,53],[1808,1418,54,53],[1269,1448,53,52],[769,1646,44,43],[1777,1473,52,51],[469,1467,52,51],[1997,1202,51,50],[643,1495,50,49],[1517,603,50,49],[1280,1532,49,48],[493,1559,48,47],[1596,1567,48,47],[1727,1592,47,46],[1564,1616,46,45],[1307,1666,43,42],[165,1619,46,45],[1782,303,45,44],[1515,1642,44,43],[1078,1642,44,43],[1242,805,43,42],[1822,1681,42,41],[0,1683,42,41],[931,759,41,40],[1157,1370,40,39],[1475,682,40,39],[1352,1691,42,41],[799,1730,39,38],[1646,1741,38,37],[626,1742,38,37],[1223,1668,37,36],[2012,1006,36,35],[1736,860,36,35],[711,1044,35,34],[590,1780,34,33],[1320,978,33,33],[1372,1180,33,32],[1519,1707,41,40],[1409,282,32,31],[1841,1037,31,31],[479,222,31,30],[1843,1551,68,34],[563,700,101,56],[707,354,114,64],[1704,593,105,58],[990,1453,39,39],[581,254,43,43],[369,0,144,144],[1562,1707,41,40],[515,0,141,141],[658,0,140,138],[658,140,140,85],[1453,0,126,126],[1581,126,122,122],[1705,126,122,122],[1323,128,118,118],[800,0,132,132],[934,0,129,129],[1323,0,128,126],[1203,403,84,82],[265,1721,40,39],[1267,323,128,78],[1443,128,115,115],[1179,129,112,112],[1065,129,112,112],[515,143,109,109],[368,1154,61,63],[1194,0,127,127],[1581,0,124,124],[1833,0,124,122],[1397,334,124,75],[87,1735,39,38],[800,134,111,111],[369,146,108,108],[626,227,108,108],[913,244,105,105],[1809,1178,58,66],[1065,0,127,127],[1707,0,124,124],[1833,124,124,122],[581,337,124,75],[934,131,111,111],[1562,1749,38,37],[1157,243,108,108],[1047,243,108,108],[736,247,105,105],[1435,1070,78,54],[322,1762,37,36],[2012,968,36,36],[1841,1774,36,35],[1210,1776,35,34],[1802,1784,34,33],[39,1789,33,32],[1409,248,32,32],[644,420,83,81],[1247,1795,32,31],[1482,1717,31,30],[747,1558,68,34],[1680,250,100,100],[1613,352,88,86],[88,369,86,84],[558,414,84,81],[1960,429,83,81],[1069,441,82,80],[437,473,82,80],[604,503,81,79],[168,537,80,78],[82,575,80,77],[832,602,79,77],[404,635,78,76],[1942,672,77,75],[1053,727,76,74],[1689,730,76,73],[1767,749,75,73],[521,497,81,79],[1287,796,74,72],[1780,824,73,71],[372,863,72,70],[1372,884,71,69],[1736,897,71,69],[1517,932,70,68],[71,950,69,67],[212,996,68,66],[748,1016,67,65],[1092,1015,67,65],[306,1666,65,28],[1585,1454,76,36],[1224,849,60,19],[1140,1528,86,28],[1014,1246,101,35],[913,1153,36,106],[1882,1754,68,20],[1247,1218,59,19],[1267,248,140,73],[924,1666,67,27],[466,1788,58,19],[1885,1493,95,27],[777,871,139,36],[535,1424,102,28],[1355,575,48,24],[1560,128,19,91],[1885,1522,90,27],[843,316,67,28],[1407,1142,140,28],[1082,1340,115,28],[207,1716,56,28],[1526,1418,85,34],[1445,884,65,25],[1178,1642,82,24],[744,1620,85,24],[429,1249,97,36],[993,1676,71,25],[323,1256,97,36],[1435,1273,102,34],[1174,1712,42,38],[1746,1671,74,24],[1029,1717,65,24],[400,1797,49,19],[1612,1622,85,24],[0,0,367,367],[638,1673,71,25],[1722,1697,69,24],[281,1696,73,23],[745,1253,97,36],[1507,1454,76,36],[1216,1582,79,28],[946,1321,55,20],[68,1121,109,36],[876,1191,35,43],[1449,1550,86,27],[1293,129,24,24],[0,455,183,36],[315,1466,97,28],[462,396,94,75],[1066,1687,62,28],[764,1464,80,34],[1646,1592,79,28],[1548,736,44,26],[1596,702,91,62],[1959,172,84,73],[1782,350,123,64],[1003,1319,77,43],[913,134,14,14],[1403,1436,102,28],[257,1102,39,32],[581,299,40,34],[112,1443,100,28],[1131,1607,77,28],[642,1183,104,36],[1181,575,172,36],[369,358,206,36],[578,584,171,36],[0,1522,94,26],[1455,1687,62,28],[1624,824,154,34],[1006,835,142,36],[488,1766,63,20],[96,1505,90,28],[1432,1309,96,35],[1210,1612,75,28],[626,143,29,35],[1963,1697,69,24],[1789,1246,58,60],[1315,682,158,36],[1181,613,166,36],[537,1387,85,35],[1443,245,133,87],[165,1416,117,25],[96,1535,68,35],[214,1443,99,28],[0,1550,90,26],[373,1692,71,24],[1419,1406,105,28],[1432,1346,114,28],[1223,1710,68,24],[1035,1151,125,31],[533,833,143,36],[1216,942,137,34],[895,984,125,36],[454,1608,76,28],[938,1593,92,24],[666,700,65,50],[1079,908,135,36],[1515,1106,118,34],[1367,1024,47,24],[204,1473,77,35],[855,1437,78,36],[128,1774,67,19],[349,1740,74,20],[1782,250,43,51],[1383,1636,83,24],[1515,1070,123,34],[585,1319,93,36],[1840,1110,111,36],[344,1437,105,27],[479,146,33,74],[741,1774,63,20],[991,946,129,36],[537,1357,111,28],[1435,1235,99,36],[1952,1723,62,25],[1658,1685,62,28],[216,1598,77,28],[1090,1083,115,36],[859,1351,113,28],[431,1181,136,28],[190,1064,117,36],[442,1638,79,25],[642,1221,101,36],[825,1321,119,28],[313,1294,103,33],[1879,1776,60,20],[1762,1724,77,20],[711,1083,122,34],[1640,1070,63,28],[195,1176,137,28],[1003,1283,100,34],[1963,1669,69,26],[489,1741,63,23],[575,1174,65,59],[1193,978,125,36],[431,1211,103,36],[744,1594,91,24],[257,1138,109,36],[1252,1502,91,28],[1910,1324,116,28],[425,1751,61,23],[1069,1753,73,19],[1596,659,52,35],[1840,1148,140,28],[1121,1184,55,25],[352,396,108,66],[68,1057,48,62],[2021,668,27,160],[1651,580,51,120],[1047,131,7,30],[626,180,30,29],[1841,1072,116,36],[1035,1121,141,28],[392,1665,74,25],[1933,1178,47,19],[323,1219,104,35],[1055,1796,52,19],[1383,1662,70,27],[1874,968,129,35],[1079,873,66,28],[1403,1796,51,19],[1449,1522,94,26],[1259,1773,66,20],[906,1283,95,36],[112,1473,90,30],[166,1540,84,28],[1203,353,56,44],[554,1758,69,20],[2008,350,34,48],[0,1578,80,28],[489,1079,116,36],[859,1698,82,20],[840,1761,67,20],[1096,1726,61,25],[666,1777,63,19],[1144,1753,69,20],[951,1184,104,36],[233,1800,46,19],[188,1510,89,28],[356,1718,78,20],[1907,350,99,77],[2008,400,40,19],[1419,1376,109,28],[708,1385,88,34],[1690,1530,100,24],[0,1019,120,36],[178,1386,107,28],[804,1153,107,36],[1050,805,190,28],[943,1745,74,20],[521,473,34,20],[422,1287,100,34],[58,1408,105,28],[1903,1411,113,26],[489,1717,71,22],[909,1767,70,19],[1259,1751,70,20],[513,1690,69,25],[779,759,148,36]]}
];


// symbols:



(lib._66906 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ALuoi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ARoang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Attapeu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.BMeThuot = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.BaBe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bakhe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.BacGiang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.BacHa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.BacKan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.BacLieu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.BacMe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.BacNinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.BacQuang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.BacSon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.BachMa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.BanGioc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.BanKhietNgong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.BanLung = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.BangLang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.BaoLac = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.BaoLoc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Battambang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.BenTre = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.BinhBa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.BinhChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.BinhLu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1copy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.BoY = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.BuonDon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.BuonHo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CaMau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_1 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_10 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_100 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_101 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_102 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_103 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_104 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_105 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_106 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_107 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_108 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_109 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_11 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_110 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_111 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_112 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_113 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_114 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_115 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_116 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_117 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_118 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_119 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_12 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_120 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_121 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_122 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_123 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_124 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_125 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_126 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_127 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_128 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_129 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_13 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_130 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_131 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_132 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_133 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_134 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_135 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_136 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_137 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_138 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_139 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_14 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_140 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_141 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_142 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_143 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_144 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_145 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_146 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_147 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_15 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_150 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_151 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_152 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_153 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_154 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_155 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_156 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_157 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_158 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_159 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_16 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_160 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_161 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_162 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_163 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_164 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_165 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_166 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_167 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_168 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_169 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_17 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_170 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_171 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_172 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_173 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_174 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_175 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_176 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_177 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_178 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_179 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_18 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_180 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_181 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_182 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_183 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_184 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_185 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(126);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_186 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(127);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_187 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(128);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_188 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(129);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_189 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(130);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_19 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(131);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_190 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(132);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_191 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(133);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_192 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(134);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_193 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(135);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_194 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(136);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_195 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(137);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_196 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(138);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_197 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(139);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_198 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(140);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_199 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(141);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_2 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(142);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_20 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(143);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_200 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(144);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_201 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(145);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_202 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(146);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_203 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(147);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_204 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(148);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_205 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(149);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_206 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(150);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_207 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(151);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_208 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(152);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_209 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(153);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_21 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(154);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_210 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(155);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_211 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(156);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_212 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(157);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_213 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(158);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_214 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(159);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_215 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(160);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_216 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(161);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_217 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(162);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_218 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(163);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_219 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(164);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_22 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(165);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_220 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(166);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_221 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(167);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_222 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(168);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_223 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(169);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_224 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(170);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_225 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(171);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_226 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(172);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_227 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(173);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_228 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(174);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_229 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(175);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_23 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(176);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_230 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(177);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_231 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(178);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_232 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(179);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_233 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(180);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_234 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(181);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_235 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(182);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_236 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(183);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_237 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(184);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_238 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(185);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_239 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(186);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_24 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(187);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_240 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(188);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_241 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(189);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_242 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(190);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_243 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(191);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_244 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(192);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_245 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(193);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_246 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(194);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_247 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(195);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_248 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(196);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_249 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(197);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_25 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(198);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_250 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(199);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_251 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(200);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_252 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(201);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_253 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(202);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_254 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(203);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_255 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(204);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_256 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(205);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_257 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(206);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_258 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(207);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_259 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(208);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_26 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(209);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_260 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(210);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_261 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(211);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_262 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(212);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_263 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(213);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_264 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(214);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_265 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(215);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_266 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(216);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_267 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(217);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_268 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(218);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_269 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(219);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_27 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(220);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_270 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(221);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_271 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(222);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_272 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(223);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_273 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(224);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_274 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(225);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_275 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(226);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_276 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(227);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_277 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(228);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_278 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(229);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_279 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(230);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_28 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(231);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_280 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(232);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_281 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(233);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_282 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(234);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_283 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(235);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_284 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(236);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_285 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(237);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_286 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(238);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_287 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(239);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_288 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(240);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_289 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(241);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_29 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(242);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_290 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(243);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_291 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(244);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_292 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(245);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_293 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(246);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_294 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(247);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_295 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(248);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_298 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(249);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_299 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(250);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_3 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(251);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_30 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(252);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_300 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(253);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_301 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(254);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_302 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(255);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_303 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(256);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_304 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(257);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_305 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(258);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_306 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(259);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_307 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(260);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_308 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(261);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_309 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(262);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_31 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(263);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_310 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(264);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_311 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(265);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_312 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(266);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_313 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(267);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_314 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(268);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_315 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(269);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_316 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(270);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_317 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(271);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_318 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(272);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_319 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(273);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_32 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(274);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_320 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(275);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_321 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(276);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_322 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(277);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_323 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(278);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_324 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(279);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_325 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(280);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_326 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(281);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_327 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(282);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_328 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(283);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_329 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(284);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_33 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(285);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_330 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(286);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_331 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(287);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_332 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(288);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_333 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(289);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_334 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(290);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_335 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(291);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_336 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(292);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_337 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(293);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_338 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(294);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_339 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(295);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_34 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(296);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_340 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(297);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_341 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(298);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_342 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(299);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_343 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(300);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_344 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(301);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_345 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(302);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_346 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(303);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_347 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(304);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_348 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(305);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_349 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(306);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_35 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(307);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_350 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(308);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_351 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(309);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_352 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(310);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_353 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(311);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_354 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(312);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_355 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(313);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_356 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(314);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_357 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(315);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_358 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(316);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_359 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(317);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_36 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(318);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_360 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(319);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_361 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(320);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_362 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(321);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_363 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(322);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_364 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(323);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_365 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(324);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_366 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(325);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_369 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(326);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_37 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(327);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_370 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(328);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_371 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(329);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_372 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(330);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_373 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(331);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_374 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(332);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_375 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(333);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_376 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(334);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_377 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(335);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_378 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(336);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_379 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(337);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_38 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(338);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_380 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(339);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_381 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(340);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_382 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(341);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_383 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(342);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_384 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(343);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_385 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(344);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_386 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(345);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_387 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(346);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_388 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(347);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_389 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(348);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_39 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(349);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_390 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(350);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_391 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(351);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_392 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(352);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_393 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(353);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_394 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(354);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_395 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(355);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_396 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(356);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_397 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(357);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_398 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(358);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_399 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(359);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_40 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(360);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_400 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(361);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_401 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(362);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_402 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(363);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_403 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(364);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_404 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(365);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_405 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(366);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_406 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(367);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_407 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(368);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_408 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(369);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_409 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(370);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_41 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(371);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_410 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(372);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_411 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(373);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_412 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(374);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_413 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(375);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_414 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(376);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_415 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(377);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_416 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(378);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_417 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(379);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_418 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(380);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_419 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(381);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_42 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(382);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_420 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(383);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_421 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(384);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_422 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(385);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_423 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(386);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_424 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(387);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_425 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(388);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_426 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(389);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_427 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(390);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_428 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(391);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_429 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(392);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_43 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(393);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_430 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(394);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_431 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(395);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_432 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(396);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_433 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(397);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_434 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(398);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_435 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(399);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_436 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(400);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_437 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(401);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_438 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(402);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_439 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(403);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_44 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(404);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_440 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(405);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_441 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(406);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_442 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(407);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_443 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(408);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_444 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(409);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_445 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(410);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_446 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(411);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_447 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(412);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_448 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(413);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_449 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(414);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_45 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(415);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_450 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(416);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_451 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(417);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_452 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(418);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_453 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(419);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_454 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(420);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_455 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(421);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_456 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(422);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_457 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(423);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_458 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(424);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_459 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(425);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_46 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(426);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_460 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(427);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_461 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(428);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_462 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(429);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_463 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(430);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_464 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(431);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_465 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(432);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_466 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(433);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_467 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(434);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_468 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(435);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_469 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(436);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_47 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(437);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_470 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(438);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_471 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(439);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_472 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(440);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_473 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(441);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_474 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(442);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_475 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(443);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_476 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(444);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_477 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(445);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_478 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(446);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_479 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(447);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_48 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(448);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_480 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(449);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_481 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(450);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_482 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(451);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_483 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(452);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_484 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(453);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_485 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(454);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_486 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(455);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_487 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(456);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_488 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(457);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_489 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(458);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_49 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(459);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_490 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(460);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_491 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(461);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_492 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(462);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_493 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(463);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_494 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(464);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_495 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(465);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_496 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(466);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_497 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(467);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_498 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(468);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_499 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(469);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_50 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(470);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_500 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(471);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_501 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(472);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_504 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(473);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_505 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(474);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_506 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(475);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_507 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(476);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_508 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(477);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_509 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(478);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_51 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(479);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_510 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(480);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_511 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(481);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_512 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(482);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_513 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(483);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_514 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(484);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_515 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(485);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_516 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(486);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_517 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(487);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_518 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(488);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_519 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(489);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_52 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(490);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_520 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(491);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_521 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(492);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_522 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(493);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_523 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(494);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_524 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(495);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_525 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(496);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_526 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(497);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_527 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(498);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_528 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(499);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_529 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(500);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_53 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(501);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_530 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(502);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_531 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(503);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_532 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(504);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_533 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(505);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_534 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(506);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_535 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(507);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_536 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(508);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_537 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(509);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_538 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(510);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_539 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(511);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_54 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(512);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_540 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(513);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_541 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(514);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_542 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(515);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_543 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(516);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_544 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(517);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_545 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(518);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_546 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(519);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_547 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(520);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_548 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(521);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_549 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(522);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_55 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(523);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_550 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(524);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_551 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(525);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_552 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(526);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_553 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(527);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_554 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(528);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_555 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(529);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_556 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(530);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_557 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(531);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_558 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(532);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_559 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(533);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_56 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(534);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_560 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(535);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_561 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(536);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_562 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(537);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_563 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(538);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_564 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(539);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_565 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(540);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_566 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(541);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_567 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(542);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_568 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(543);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_569 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(544);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_57 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(545);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_570 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(546);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_571 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(547);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_572 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(548);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_573 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(549);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_574 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(550);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_575 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(551);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_576 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(552);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_577 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(553);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_578 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(554);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_579 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(555);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_58 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(556);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_580 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(557);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_581 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(558);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_582 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(559);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_583 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(560);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_584 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(561);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_585 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(562);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_586 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(563);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_587 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(564);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_588 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(565);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_589 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(566);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_59 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(567);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_590 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(568);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_591 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(569);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_592 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(570);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_593 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(571);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_594 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(572);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_595 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(573);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_596 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(574);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_597 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(575);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_598 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(576);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_599 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(577);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_6 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(578);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_60 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(579);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_600 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(580);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_601 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(581);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_602 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(582);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_603 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(583);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_604 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(584);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_605 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(585);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_606 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(586);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_607 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(587);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_608 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(588);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_609 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(589);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_61 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(590);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_610 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(591);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_611 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(592);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_612 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(593);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_613 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(594);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_614 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(595);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_615 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(596);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_616 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(597);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_617 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(598);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_618 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(599);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_619 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(600);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_62 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(601);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_620 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(602);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_621 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(603);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_622 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(604);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_623 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(605);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_63 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(606);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_64 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(607);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_65 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(608);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_66 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(609);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_67 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(610);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_68 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(611);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_69 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(612);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_7 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(613);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_70 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(614);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_71 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(615);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_72 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(616);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_73 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(617);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_74 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(618);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_75 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(619);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_78 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(620);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_79 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(621);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_8 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(622);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_80 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(623);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_81 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(624);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_82 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(625);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_83 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(626);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_84 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(627);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_85 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(628);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_86 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(629);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_87 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(630);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_88 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(631);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_89 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(632);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_9 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(633);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_90 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(634);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_91 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(635);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_92 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(636);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_93 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(637);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_94 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(638);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_95 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(639);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_96 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(640);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_97 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(641);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_98 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(642);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_99 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(643);
}).prototype = p = new cjs.Sprite();



(lib.CaiBe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(644);
}).prototype = p = new cjs.Sprite();



(lib.CaiLay = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(645);
}).prototype = p = new cjs.Sprite();



(lib.CanCau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(646);
}).prototype = p = new cjs.Sprite();



(lib.CanTho = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(647);
}).prototype = p = new cjs.Sprite();



(lib.CaoBang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(648);
}).prototype = p = new cjs.Sprite();



(lib.caobangpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(649);
}).prototype = p = new cjs.Sprite();



(lib.CaoLanh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(650);
}).prototype = p = new cjs.Sprite();



(lib.CaoSon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(651);
}).prototype = p = new cjs.Sprite();



(lib.caosonpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(652);
}).prototype = p = new cjs.Sprite();



(lib.CatBa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(653);
}).prototype = p = new cjs.Sprite();



(lib.CatTien = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(654);
}).prototype = p = new cjs.Sprite();



(lib.CauTreo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(655);
}).prototype = p = new cjs.Sprite();



(lib.Champassak = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(656);
}).prototype = p = new cjs.Sprite();



(lib.ChauDoc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(657);
}).prototype = p = new cjs.Sprite();



(lib.CocLy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(658);
}).prototype = p = new cjs.Sprite();



(lib.coclypngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(659);
}).prototype = p = new cjs.Sprite();



(lib.ConDao = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(660);
}).prototype = p = new cjs.Sprite();



(lib.CuChi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(661);
}).prototype = p = new cjs.Sprite();



(lib.CuLaoCham = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(662);
}).prototype = p = new cjs.Sprite();



(lib.DBienPhu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(663);
}).prototype = p = new cjs.Sprite();



(lib.DaLat = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(664);
}).prototype = p = new cjs.Sprite();



(lib.Danang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(665);
}).prototype = p = new cjs.Sprite();



(lib.DinhLap = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(666);
}).prototype = p = new cjs.Sprite();



(lib.DonDeang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(667);
}).prototype = p = new cjs.Sprite();



(lib.DongGiang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(668);
}).prototype = p = new cjs.Sprite();



(lib.DongHoi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(669);
}).prototype = p = new cjs.Sprite();



(lib.DongKhe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(670);
}).prototype = p = new cjs.Sprite();



(lib.DongNai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(671);
}).prototype = p = new cjs.Sprite();



(lib.DongVan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(672);
}).prototype = p = new cjs.Sprite();



(lib.dongvanpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(673);
}).prototype = p = new cjs.Sprite();



(lib.DongXoai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(674);
}).prototype = p = new cjs.Sprite();



(lib.DraySap = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(675);
}).prototype = p = new cjs.Sprite();



(lib.DuGia = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(676);
}).prototype = p = new cjs.Sprite();



(lib.DuongLam = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(677);
}).prototype = p = new cjs.Sprite();



(lib.ghichucacphuongtien = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(678);
}).prototype = p = new cjs.Sprite();



(lib.GiaNghia = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(679);
}).prototype = p = new cjs.Sprite();



(lib.GotFerry = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(680);
}).prototype = p = new cjs.Sprite();



(lib.HSuPhi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(681);
}).prototype = p = new cjs.Sprite();



(lib.HaGiang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(682);
}).prototype = p = new cjs.Sprite();



(lib.HaLong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(683);
}).prototype = p = new cjs.Sprite();



(lib.HaTien = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(684);
}).prototype = p = new cjs.Sprite();



(lib.HaTinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(685);
}).prototype = p = new cjs.Sprite();



(lib.HaiPhong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(686);
}).prototype = p = new cjs.Sprite();



(lib.HaNoiDongHoi = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(687);
}).prototype = p = new cjs.Sprite();



(lib.HANOI = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(688);
}).prototype = p = new cjs.Sprite();



(lib.hnpoint = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(689);
}).prototype = p = new cjs.Sprite();



(lib.HoChiMinhCity = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(690);
}).prototype = p = new cjs.Sprite();



(lib.HoaBinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(691);
}).prototype = p = new cjs.Sprite();



(lib.HoangSa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(692);
}).prototype = p = new cjs.Sprite();



(lib.HoiAn = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(693);
}).prototype = p = new cjs.Sprite();



(lib.Hongsa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(694);
}).prototype = p = new cjs.Sprite();



(lib.Houixai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(695);
}).prototype = p = new cjs.Sprite();



(lib.Hue = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(696);
}).prototype = p = new cjs.Sprite();



(lib.iconmoto = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(697);
}).prototype = p = new cjs.Sprite();



(lib.iconmáybay = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(698);
}).prototype = p = new cjs.Sprite();



(lib.icontàuthủy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(699);
}).prototype = p = new cjs.Sprite();



(lib.iconxeđạp = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(700);
}).prototype = p = new cjs.Sprite();



(lib.imgdot = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(701);
}).prototype = p = new cjs.Sprite();



(lib.Kenethao = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(702);
}).prototype = p = new cjs.Sprite();



(lib.kepcambodge = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(703);
}).prototype = p = new cjs.Sprite();



(lib.Kep = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(704);
}).prototype = p = new cjs.Sprite();



(lib.KheXanh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(705);
}).prototype = p = new cjs.Sprite();



(lib.Kohker = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(706);
}).prototype = p = new cjs.Sprite();



(lib.KohTrong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(707);
}).prototype = p = new cjs.Sprite();



(lib.KompongCham = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(708);
}).prototype = p = new cjs.Sprite();



(lib.KompongChhnang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(709);
}).prototype = p = new cjs.Sprite();



(lib.KompongThom = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(710);
}).prototype = p = new cjs.Sprite();



(lib.KonTum = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(711);
}).prototype = p = new cjs.Sprite();



(lib.Kratie = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(712);
}).prototype = p = new cjs.Sprite();



(lib.KrongKampot = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(713);
}).prototype = p = new cjs.Sprite();



(lib.KrongPoiPet = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(714);
}).prototype = p = new cjs.Sprite();



(lib.LacLake = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(715);
}).prototype = p = new cjs.Sprite();



(lib.LaiChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(716);
}).prototype = p = new cjs.Sprite();



(lib.LangSon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(717);
}).prototype = p = new cjs.Sprite();



(lib.LaoCai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(718);
}).prototype = p = new cjs.Sprite();



(lib.laocaipngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(719);
}).prototype = p = new cjs.Sprite();



(lib.Laongam = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(720);
}).prototype = p = new cjs.Sprite();



(lib.LongXuyen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(721);
}).prototype = p = new cjs.Sprite();



(lib.LuangNamtha = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(722);
}).prototype = p = new cjs.Sprite();



(lib.LuangPrabang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(723);
}).prototype = p = new cjs.Sprite();



(lib.LungCu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(724);
}).prototype = p = new cjs.Sprite();



(lib.lungkhaunhin = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(725);
}).prototype = p = new cjs.Sprite();



(lib.LungKhauNhinpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(726);
}).prototype = p = new cjs.Sprite();



(lib.LySon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(727);
}).prototype = p = new cjs.Sprite();



(lib.MaiChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(728);
}).prototype = p = new cjs.Sprite();



(lib.map3nuoc1pngcopy = function() {
	this.initialize(img.map3nuoc1pngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2048,2854);


(lib.MeoVac = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(729);
}).prototype = p = new cjs.Sprite();



(lib.MocBai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(730);
}).prototype = p = new cjs.Sprite();



(lib.MocChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(731);
}).prototype = p = new cjs.Sprite();



(lib.Mondulkiri = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(732);
}).prototype = p = new cjs.Sprite();



(lib.MongCai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(733);
}).prototype = p = new cjs.Sprite();



(lib.MuCangChai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(734);
}).prototype = p = new cjs.Sprite();



(lib.MuangKham = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(735);
}).prototype = p = new cjs.Sprite();



(lib.MuangNgoy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(736);
}).prototype = p = new cjs.Sprite();



(lib.MuangSing = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(737);
}).prototype = p = new cjs.Sprite();



(lib.MuiNe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(738);
}).prototype = p = new cjs.Sprite();



(lib.MuongHum = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(739);
}).prototype = p = new cjs.Sprite();



(lib.muonghumpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(740);
}).prototype = p = new cjs.Sprite();



(lib.MuongKhua = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(741);
}).prototype = p = new cjs.Sprite();



(lib.MuongLay = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(742);
}).prototype = p = new cjs.Sprite();



(lib.MyLai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(743);
}).prototype = p = new cjs.Sprite();



(lib.MySon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(744);
}).prototype = p = new cjs.Sprite();



(lib.MyTho = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(745);
}).prototype = p = new cjs.Sprite();



(lib.NamCan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(746);
}).prototype = p = new cjs.Sprite();



(lib.NamDinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(747);
}).prototype = p = new cjs.Sprite();



(lib.namdinhpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(748);
}).prototype = p = new cjs.Sprite();



(lib.NamGiang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(749);
}).prototype = p = new cjs.Sprite();



(lib.NamNgum = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(750);
}).prototype = p = new cjs.Sprite();



(lib.NghiaLo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(751);
}).prototype = p = new cjs.Sprite();



(lib.NhaTrang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(752);
}).prototype = p = new cjs.Sprite();



(lib.NinhBinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(753);
}).prototype = p = new cjs.Sprite();



(lib.NinhBinhpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(754);
}).prototype = p = new cjs.Sprite();



(lib.NinhGia = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(755);
}).prototype = p = new cjs.Sprite();



(lib.NongKhiaw = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(756);
}).prototype = p = new cjs.Sprite();



(lib.Oudomxai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(757);
}).prototype = p = new cjs.Sprite();



(lib.PakBeng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(758);
}).prototype = p = new cjs.Sprite();



(lib.Paksong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(759);
}).prototype = p = new cjs.Sprite();



(lib.Paksé = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(760);
}).prototype = p = new cjs.Sprite();



(lib.Pakxan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(761);
}).prototype = p = new cjs.Sprite();



(lib.PhanRang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(762);
}).prototype = p = new cjs.Sprite();



(lib.PhanThiet = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(763);
}).prototype = p = new cjs.Sprite();



(lib.PhnomPenh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(764);
}).prototype = p = new cjs.Sprite();



(lib.PhongNha = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(765);
}).prototype = p = new cjs.Sprite();



(lib.PhongTho = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(766);
}).prototype = p = new cjs.Sprite();



(lib.Phongsali = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(767);
}).prototype = p = new cjs.Sprite();



(lib.Phonxavan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(768);
}).prototype = p = new cjs.Sprite();



(lib.PhuQuoc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(769);
}).prototype = p = new cjs.Sprite();



(lib.PhuYen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(770);
}).prototype = p = new cjs.Sprite();



(lib.PhuocSon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(771);
}).prototype = p = new cjs.Sprite();



(lib.PlainofJars = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(772);
}).prototype = p = new cjs.Sprite();



(lib.Pleiku = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(773);
}).prototype = p = new cjs.Sprite();



(lib.PreahVihear = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(774);
}).prototype = p = new cjs.Sprite();



(lib.PuLuong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(775);
}).prototype = p = new cjs.Sprite();



(lib.Pursat = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(776);
}).prototype = p = new cjs.Sprite();



(lib.QuanBa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(777);
}).prototype = p = new cjs.Sprite();



(lib.quanbapngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(778);
}).prototype = p = new cjs.Sprite();



(lib.QuangNgai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(779);
}).prototype = p = new cjs.Sprite();



(lib.QuangTri = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(780);
}).prototype = p = new cjs.Sprite();



(lib.QuangUyen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(781);
}).prototype = p = new cjs.Sprite();



(lib.QuyNhon = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(782);
}).prototype = p = new cjs.Sprite();



(lib.RachGia = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(783);
}).prototype = p = new cjs.Sprite();



(lib.Rattanakiri = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(784);
}).prototype = p = new cjs.Sprite();



(lib.SaDec = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(785);
}).prototype = p = new cjs.Sprite();



(lib.Sanamxai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(786);
}).prototype = p = new cjs.Sprite();



(lib.Sapa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(787);
}).prototype = p = new cjs.Sprite();



(lib.Savannakhet = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(788);
}).prototype = p = new cjs.Sprite();



(lib.Sekong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(789);
}).prototype = p = new cjs.Sprite();



(lib.SereiSaophoan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(790);
}).prototype = p = new cjs.Sprite();



(lib.Shape1319copy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(791);
}).prototype = p = new cjs.Sprite();



(lib.Shape1327 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(792);
}).prototype = p = new cjs.Sprite();



(lib.Shape1328 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(793);
}).prototype = p = new cjs.Sprite();



(lib.Shape1477 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(794);
}).prototype = p = new cjs.Sprite();



(lib.Shape1486 = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(795);
}).prototype = p = new cjs.Sprite();



(lib.SiemReap = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(796);
}).prototype = p = new cjs.Sprite();



(lib.Sihanoukville = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(797);
}).prototype = p = new cjs.Sprite();



(lib.SinCheng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(798);
}).prototype = p = new cjs.Sprite();



(lib.SinHo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(799);
}).prototype = p = new cjs.Sprite();



(lib.SocTrang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(800);
}).prototype = p = new cjs.Sprite();



(lib.SonHa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(801);
}).prototype = p = new cjs.Sprite();



(lib.SonLa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(802);
}).prototype = p = new cjs.Sprite();



(lib.StungTreng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(803);
}).prototype = p = new cjs.Sprite();



(lib.Takeo = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(804);
}).prototype = p = new cjs.Sprite();



(lib.TanAn = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(805);
}).prototype = p = new cjs.Sprite();



(lib.TanTrao = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(806);
}).prototype = p = new cjs.Sprite();



(lib.TanChau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(807);
}).prototype = p = new cjs.Sprite();



(lib.TayNinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(808);
}).prototype = p = new cjs.Sprite();



(lib.TayTrang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(809);
}).prototype = p = new cjs.Sprite();



(lib.ThacBa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(810);
}).prototype = p = new cjs.Sprite();



(lib.ThaiNguyen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(811);
}).prototype = p = new cjs.Sprite();



(lib.ThaiBinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(812);
}).prototype = p = new cjs.Sprite();



(lib.thaibinhpngcopy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(813);
}).prototype = p = new cjs.Sprite();



(lib.Thakek = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(814);
}).prototype = p = new cjs.Sprite();



(lib.ThanUyen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(815);
}).prototype = p = new cjs.Sprite();



(lib.ThanhHoa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(816);
}).prototype = p = new cjs.Sprite();



(lib.ThatKhe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(817);
}).prototype = p = new cjs.Sprite();



(lib.Thateng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(818);
}).prototype = p = new cjs.Sprite();



(lib.TienYen = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(819);
}).prototype = p = new cjs.Sprite();



(lib.TinhBien = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(820);
}).prototype = p = new cjs.Sprite();



(lib.TonléSap = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(821);
}).prototype = p = new cjs.Sprite();



(lib.TraSu = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(822);
}).prototype = p = new cjs.Sprite();



(lib.TraVinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(823);
}).prototype = p = new cjs.Sprite();



(lib.TramChim = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(824);
}).prototype = p = new cjs.Sprite();



(lib.TruongSa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(825);
}).prototype = p = new cjs.Sprite();



(lib.TuLe = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(826);
}).prototype = p = new cjs.Sprite();



(lib.TuanGiao = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(827);
}).prototype = p = new cjs.Sprite();



(lib.TuyHoa = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(828);
}).prototype = p = new cjs.Sprite();



(lib.TuyenQuang = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(829);
}).prototype = p = new cjs.Sprite();



(lib.VangVieng = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(830);
}).prototype = p = new cjs.Sprite();



(lib.Vientiane = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(831);
}).prototype = p = new cjs.Sprite();



(lib.VinhLong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(832);
}).prototype = p = new cjs.Sprite();



(lib.VinhMocTunnels = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(833);
}).prototype = p = new cjs.Sprite();



(lib.VinhPhuc = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(834);
}).prototype = p = new cjs.Sprite();



(lib.Vinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(835);
}).prototype = p = new cjs.Sprite();



(lib.VungTau = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(836);
}).prototype = p = new cjs.Sprite();



(lib.WatPhou = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(837);
}).prototype = p = new cjs.Sprite();



(lib.XamNeua = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(838);
}).prototype = p = new cjs.Sprite();



(lib.XinMan = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(839);
}).prototype = p = new cjs.Sprite();



(lib.XuanMai = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(840);
}).prototype = p = new cjs.Sprite();



(lib.YenMinh = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(841);
}).prototype = p = new cjs.Sprite();



(lib.YenThuy = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(842);
}).prototype = p = new cjs.Sprite();



(lib.îledeKhnong = function() {
	this.initialize(ss["ui_viet_nam_atlas_"]);
	this.gotoAndStop(843);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MyLai();
	this.instance.parent = this;
	this.instance.setTransform(-23.5,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(-23.5,-12,47,24), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BachMa();
	this.instance.parent = this;
	this.instance.setTransform(-31.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-31.5,-10,63,20), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ALuoi();
	this.instance.parent = this;
	this.instance.setTransform(-23,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-23,-9.5,46,19), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TinhBien();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-34.5,-10,69,20), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TanAn();
	this.instance.parent = this;
	this.instance.setTransform(-25.5,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-25.5,-9.5,51,19), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CatTien();
	this.instance.parent = this;
	this.instance.setTransform(-29,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-29,-9.5,58,19), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BinhChau();
	this.instance.parent = this;
	this.instance.setTransform(-37.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-37.5,-10,75,20), null);


(lib.VN_MuCangChai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuCangChai();
	this.instance.parent = this;
	this.instance.setTransform(-63,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_MuCangChai, new cjs.Rectangle(-63,-13,125,31), null);


(lib.VN_DongKhe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongKhe();
	this.instance.parent = this;
	this.instance.setTransform(-51,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_DongKhe, new cjs.Rectangle(-51,-17,71,25), null);


(lib.VN_DienBienPhu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DBienPhu();
	this.instance.parent = this;
	this.instance.setTransform(-57.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_DienBienPhu, new cjs.Rectangle(-57.5,-13.5,115,28), null);


(lib.VN_CocLy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.coclypngcopy();
	this.instance.parent = this;
	this.instance.setTransform(30,1);

	this.instance_1 = new lib.CocLy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-19,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CocLy, new cjs.Rectangle(-19,-12,68,104), null);


(lib.VN_CatBa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CatBa();
	this.instance.parent = this;
	this.instance.setTransform(-33.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CatBa, new cjs.Rectangle(-33.5,-12.5,67,27), null);


(lib.VN_CaoSon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.caosonpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(36,5);

	this.instance_1 = new lib.CaoSon();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-28,-7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CaoSon, new cjs.Rectangle(-28,-7,204,85), null);


(lib.VN_CaoBang = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.caobangpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-93,2);

	this.instance_1 = new lib.CaoBang();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-54,-9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CaoBang, new cjs.Rectangle(-93,-9,140,117), null);


(lib.VN_CanCau = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Shape1327();
	this.instance.parent = this;
	this.instance.setTransform(64,-36);

	this.instance_1 = new lib.CanCau();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28,-63);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_CanCau, new cjs.Rectangle(28,-63,63,187), null);


(lib.VN_BinhLu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BinhLu();
	this.instance.parent = this;
	this.instance.setTransform(-39,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BinhLu, new cjs.Rectangle(-39,-13.5,68,24), null);


(lib.VN_BaoLac = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BaoLac();
	this.instance.parent = this;
	this.instance.setTransform(-40.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BaoLac, new cjs.Rectangle(-40.5,-12.5,82,26), null);


(lib.VN_BanGioc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BanGioc();
	this.instance.parent = this;
	this.instance.setTransform(-49,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BanGioc, new cjs.Rectangle(-49,-15,93,28), null);


(lib.VN_BaKhe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bakhe();
	this.instance.parent = this;
	this.instance.setTransform(-35.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BaKhe, new cjs.Rectangle(-35.5,-13.5,50,20), null);


(lib.VN_BacSon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacSon();
	this.instance.parent = this;
	this.instance.setTransform(-41,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacSon, new cjs.Rectangle(-41,-12.5,82,27), null);


(lib.VN_BacNinh = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacNinh();
	this.instance.parent = this;
	this.instance.setTransform(-47,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacNinh, new cjs.Rectangle(-47,-13.5,94,28), null);


(lib.VN_BacMe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacMe();
	this.instance.parent = this;
	this.instance.setTransform(-38,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacMe, new cjs.Rectangle(-38,-12.5,53,19), null);


(lib.VN_BacHa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacHa();
	this.instance.parent = this;
	this.instance.setTransform(-28,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacHa, new cjs.Rectangle(-28,-7,73,26), null);


(lib.VN_BacGiang = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacGiang();
	this.instance.parent = this;
	this.instance.setTransform(-52.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.VN_BacGiang, new cjs.Rectangle(-52.5,-16.5,72,24), null);


(lib.Symbol123 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Oudomxai();
	this.instance.parent = this;
	this.instance.setTransform(-55.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol123, new cjs.Rectangle(-55.5,-13.5,111,28), null);


(lib.Symbol122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DuGia();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol122, new cjs.Rectangle(-34.5,-13,49,19), null);


(lib.Symbol120 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Sihanoukville();
	this.instance.parent = this;
	this.instance.setTransform(-70.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol120, new cjs.Rectangle(-70.5,-13.5,141,28), null);


(lib.Symbol119 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.kepcambodge();
	this.instance.parent = this;
	this.instance.setTransform(4,-49);

	this.instance_1 = new lib.Kep();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-19.5,-16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol119, new cjs.Rectangle(-19.5,-49,62.5,67), null);


(lib.Symbol118 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Shape1319copy();
	this.instance.parent = this;
	this.instance.setTransform(83,-63);

	this.instance_1 = new lib.KrongKampot();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-77,-17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol118, new cjs.Rectangle(-77,-63,208,80), null);


(lib.Symbol117 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TonléSap();
	this.instance.parent = this;
	this.instance.setTransform(-52,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol117, new cjs.Rectangle(-52,-17,104,36), null);


(lib.Symbol116 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhnomPenh();
	this.instance.parent = this;
	this.instance.setTransform(-68,-14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol116, new cjs.Rectangle(-68,-14,136,28), null);


(lib.Symbol115 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KompongChhnang();
	this.instance.parent = this;
	this.instance.setTransform(-146,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol115, new cjs.Rectangle(-146,-24,206,36), null);


(lib.Symbol114 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Pursat();
	this.instance.parent = this;
	this.instance.setTransform(-34,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol114, new cjs.Rectangle(-34,-12.5,69,26), null);


(lib.Symbol113 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Battambang();
	this.instance.parent = this;
	this.instance.setTransform(-65.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol113, new cjs.Rectangle(-65.5,-17,133,36), null);


(lib.Symbol112 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KohTrong();
	this.instance.parent = this;
	this.instance.setTransform(-52,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol112, new cjs.Rectangle(-52,-17,104,36), null);


(lib.Symbol111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KompongCham();
	this.instance.parent = this;
	this.instance.setTransform(-47,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol111, new cjs.Rectangle(-47,-21,172,36), null);


(lib.Symbol110 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Kratie();
	this.instance.parent = this;
	this.instance.setTransform(-31,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol110, new cjs.Rectangle(-31,-13,62,28), null);


(lib.Symbol109 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Mondulkiri();
	this.instance.parent = this;
	this.instance.setTransform(-57,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol109, new cjs.Rectangle(-57,-13.5,114,28), null);


(lib.Symbol108 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rattanakiri();
	this.instance.parent = this;
	this.instance.setTransform(-58,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol108, new cjs.Rectangle(-58,-13.5,116,28), null);


(lib.Symbol107 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BanLung();
	this.instance.parent = this;
	this.instance.setTransform(-49.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol107, new cjs.Rectangle(-49.5,-16,100,34), null);


(lib.Symbol106 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.StungTreng();
	this.instance.parent = this;
	this.instance.setTransform(-64,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol106, new cjs.Rectangle(-64,-16,129,35), null);


(lib.Symbol105 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KompongThom();
	this.instance.parent = this;
	this.instance.setTransform(-18,-6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol105, new cjs.Rectangle(-18,-6,171,36), null);


(lib.Symbol104 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SiemReap();
	this.instance.parent = this;
	this.instance.setTransform(-55.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol104, new cjs.Rectangle(-55.5,-16.5,116,36), null);


(lib.Symbol103 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SereiSaophoan();
	this.instance.parent = this;
	this.instance.setTransform(-53,-31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol103, new cjs.Rectangle(-53,-31,108,66), null);


(lib.Symbol102 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KrongPoiPet();
	this.instance.parent = this;
	this.instance.setTransform(-102,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol102, new cjs.Rectangle(-102,-15,142,36), null);


(lib.Symbol101 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Kohker();
	this.instance.parent = this;
	this.instance.setTransform(-38,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol101, new cjs.Rectangle(-38,-13.5,77,28), null);


(lib.Symbol100 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PreahVihear();
	this.instance.parent = this;
	this.instance.setTransform(-68.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol100, new cjs.Rectangle(-68.5,-13.5,137,28), null);


(lib.Symbol99 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.îledeKhnong();
	this.instance.parent = this;
	this.instance.setTransform(-22,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol99, new cjs.Rectangle(-22,-23,148,36), null);


(lib.Symbol98 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Champassak();
	this.instance.parent = this;
	this.instance.setTransform(-68.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol98, new cjs.Rectangle(-68.5,-17,139,36), null);


(lib.Symbol97 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BanKhietNgong();
	this.instance.parent = this;
	this.instance.setTransform(-89,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol97, new cjs.Rectangle(-89,-17,123,25), null);


(lib.Symbol96 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DonDeang();
	this.instance.parent = this;
	this.instance.setTransform(-41,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol96, new cjs.Rectangle(-41,-12,82,24), null);


(lib.Symbol95 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.WatPhou();
	this.instance.parent = this;
	this.instance.setTransform(-51.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol95, new cjs.Rectangle(-51.5,-13.5,105,28), null);


(lib.Symbol94 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Attapeu();
	this.instance.parent = this;
	this.instance.setTransform(-43,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol94, new cjs.Rectangle(-43,-16,86,34), null);


(lib.Symbol93 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Paksé();
	this.instance.parent = this;
	this.instance.setTransform(-30.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol93, new cjs.Rectangle(-30.5,-13.5,62,28), null);


(lib.Symbol92 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Thateng();
	this.instance.parent = this;
	this.instance.setTransform(-44.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol92, new cjs.Rectangle(-44.5,-17,61,25), null);


(lib.Symbol91 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Laongam();
	this.instance.parent = this;
	this.instance.setTransform(-48.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol91, new cjs.Rectangle(-48.5,-16,69,24), null);


(lib.Symbol90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Savannakhet();
	this.instance.parent = this;
	this.instance.setTransform(-69.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol90, new cjs.Rectangle(-69.5,-13.5,140,28), null);


(lib.Symbol89 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Thakek();
	this.instance.parent = this;
	this.instance.setTransform(-39.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol89, new cjs.Rectangle(-39.5,-13.5,80,28), null);


(lib.Symbol88 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Kenethao();
	this.instance.parent = this;
	this.instance.setTransform(-51,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol88, new cjs.Rectangle(-51,-13.5,102,28), null);


(lib.Symbol87 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.XamNeua();
	this.instance.parent = this;
	this.instance.setTransform(-55.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol87, new cjs.Rectangle(-55.5,-12.5,113,26), null);


(lib.Symbol86 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Hongsa();
	this.instance.parent = this;
	this.instance.setTransform(-39,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol86, new cjs.Rectangle(-39,-16,80,34), null);


(lib.Symbol85 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Vientiane();
	this.instance.parent = this;
	this.instance.setTransform(-50.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol85, new cjs.Rectangle(-50.5,-13,107,28), null);


(lib.Symbol84 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PlainofJars();
	this.instance.parent = this;
	this.instance.setTransform(-61.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol84, new cjs.Rectangle(-61.5,-16.5,122,34), null);


(lib.Symbol83 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NamCan();
	this.instance.parent = this;
	this.instance.setTransform(-48,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol83, new cjs.Rectangle(-48,-12.5,67,19), null);


(lib.Symbol82 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuangKham();
	this.instance.parent = this;
	this.instance.setTransform(-70.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol82, new cjs.Rectangle(-70.5,-17,143,36), null);


(lib.Symbol81 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Phonxavan();
	this.instance.parent = this;
	this.instance.setTransform(-58.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol81, new cjs.Rectangle(-58.5,-13.5,119,28), null);


(lib.Symbol80 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VangVieng();
	this.instance.parent = this;
	this.instance.setTransform(-59.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol80, new cjs.Rectangle(-59.5,-16.5,120,36), null);


(lib.Symbol79 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Pakxan();
	this.instance.parent = this;
	this.instance.setTransform(-38,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol79, new cjs.Rectangle(-38,-13.5,77,28), null);


(lib.Symbol78 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NamNgum();
	this.instance.parent = this;
	this.instance.setTransform(-60.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol78, new cjs.Rectangle(-60.5,-16,123,34), null);


(lib.Symbol77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Houixai();
	this.instance.parent = this;
	this.instance.setTransform(-59,4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol77, new cjs.Rectangle(-59,4,79,28), null);


(lib.Symbol76 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LuangPrabang();
	this.instance.parent = this;
	this.instance.setTransform(-80,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol76, new cjs.Rectangle(-80,-17,166,36), null);


(lib.Symbol75 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NongKhiaw();
	this.instance.parent = this;
	this.instance.setTransform(-64,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol75, new cjs.Rectangle(-64,-17,129,36), null);


(lib.Symbol74 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuangNgoy();
	this.instance.parent = this;
	this.instance.setTransform(-67.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol74, new cjs.Rectangle(-67.5,-16,137,34), null);


(lib.Symbol73 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuongKhua();
	this.instance.parent = this;
	this.instance.setTransform(-66.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol73, new cjs.Rectangle(-66.5,-17,135,36), null);


(lib.Symbol72 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LuangNamtha();
	this.instance.parent = this;
	this.instance.setTransform(-78.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol72, new cjs.Rectangle(-78.5,-17,158,36), null);


(lib.Symbol71 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuangSing();
	this.instance.parent = this;
	this.instance.setTransform(-61.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol71, new cjs.Rectangle(-61.5,-16.5,125,36), null);


(lib.Symbol70 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Phongsali();
	this.instance.parent = this;
	this.instance.setTransform(-50.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol70, new cjs.Rectangle(-50.5,-17,101,36), null);


(lib.Symbol68 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhuQuoc();
	this.instance.parent = this;
	this.instance.setTransform(-51.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol68, new cjs.Rectangle(-51.5,-16,103,33), null);


(lib.Symbol67 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Takeo();
	this.instance.parent = this;
	this.instance.setTransform(-32,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol67, new cjs.Rectangle(-32,-13.5,66,28), null);


(lib.Symbol66 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ChauDoc();
	this.instance.parent = this;
	this.instance.setTransform(-50.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol66, new cjs.Rectangle(-50.5,-13.5,102,28), null);


(lib.Symbol65 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TruongSa();
	this.instance.parent = this;
	this.instance.setTransform(-50.5,-38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol65, new cjs.Rectangle(-50.5,-38.5,99,77), null);


(lib.Symbol64 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ConDao();
	this.instance.parent = this;
	this.instance.setTransform(-44.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol64, new cjs.Rectangle(-44.5,-12.5,90,27), null);


(lib.Symbol63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CaMau();
	this.instance.parent = this;
	this.instance.setTransform(-39.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol63, new cjs.Rectangle(-39.5,-12.5,79,27), null);


(lib.Symbol62 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.RachGia();
	this.instance.parent = this;
	this.instance.setTransform(-61,-14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol62, new cjs.Rectangle(-61,-14,91,28), null);


(lib.Symbol61 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TraSu();
	this.instance.parent = this;
	this.instance.setTransform(-33,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol61, new cjs.Rectangle(-33,-12.5,46,19), null);


(lib.Symbol60 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaTien();
	this.instance.parent = this;
	this.instance.setTransform(-39,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol60, new cjs.Rectangle(-39,-13,79,28), null);


(lib.Symbol59 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BangLang();
	this.instance.parent = this;
	this.instance.setTransform(-55,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol59, new cjs.Rectangle(-55,-16,77,24), null);


(lib.Symbol58 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CanTho();
	this.instance.parent = this;
	this.instance.setTransform(-43,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol58, new cjs.Rectangle(-43,-13.5,86,28), null);


(lib.Symbol57 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacLieu();
	this.instance.parent = this;
	this.instance.setTransform(-43,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol57, new cjs.Rectangle(-43,-13,86,28), null);


(lib.Symbol56 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SocTrang();
	this.instance.parent = this;
	this.instance.setTransform(-51.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol56, new cjs.Rectangle(-51.5,-16,104,35), null);


(lib.Symbol55 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TraVinh();
	this.instance.parent = this;
	this.instance.setTransform(-44,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol55, new cjs.Rectangle(-44,-13.5,89,28), null);


(lib.Symbol54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VinhLong();
	this.instance.parent = this;
	this.instance.setTransform(-53.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol54, new cjs.Rectangle(-53.5,-17,107,36), null);


(lib.Symbol53 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CaiBe();
	this.instance.parent = this;
	this.instance.setTransform(-32.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol53, new cjs.Rectangle(-32.5,-13,65,28), null);


(lib.Symbol52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BenTre();
	this.instance.parent = this;
	this.instance.setTransform(-40,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol52, new cjs.Rectangle(-40,-12.5,81,26), null);


(lib.Symbol51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VungTau();
	this.instance.parent = this;
	this.instance.setTransform(-49.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol51, new cjs.Rectangle(-49.5,-16,100,34), null);


(lib.Symbol50 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MyTho();
	this.instance.parent = this;
	this.instance.setTransform(-38.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol50, new cjs.Rectangle(-38.5,-17,78,36), null);


(lib.Symbol49copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CaiLay();
	this.instance.parent = this;
	this.instance.setTransform(-37.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol49copy, new cjs.Rectangle(-37.5,-16.5,76,36), null);


(lib.Symbol49 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThacBa();
	this.instance.parent = this;
	this.instance.setTransform(-41.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol49, new cjs.Rectangle(-41.5,-13.5,84,28), null);


(lib.Symbol48copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SaDec();
	this.instance.parent = this;
	this.instance.setTransform(-35,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol48copy, new cjs.Rectangle(-35,-12.5,61,23), null);


(lib.Symbol48 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TayTrang();
	this.instance.parent = this;
	this.instance.setTransform(-53,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol48, new cjs.Rectangle(-53,-16,90,30), null);


(lib.Symbol47copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LongXuyen();
	this.instance.parent = this;
	this.instance.setTransform(-43,-42);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol47copy, new cjs.Rectangle(-43,-42,58,60), null);


(lib.Symbol47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThaiNguyen();
	this.instance.parent = this;
	this.instance.setTransform(-40.5,-26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol47, new cjs.Rectangle(-40.5,-26.5,56,44), null);


(lib.Symbol46copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MocBai();
	this.instance.parent = this;
	this.instance.setTransform(-41,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol46copy, new cjs.Rectangle(-41,-13,71,24), null);


(lib.Symbol45copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CuChi();
	this.instance.parent = this;
	this.instance.setTransform(-33.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol45copy, new cjs.Rectangle(-33.5,-13.5,67,28), null);


(lib.Symbol45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Shape1486();
	this.instance.parent = this;
	this.instance.setTransform(-15,5);

	this.instance_1 = new lib.YenMinh();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-53,-17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol45, new cjs.Rectangle(-53,-17,70,51), null);


(lib.Symbol44copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HoChiMinhCity();
	this.instance.parent = this;
	this.instance.setTransform(-23,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol44copy, new cjs.Rectangle(-23,-16,183,36), null);


(lib.Symbol44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.XinMan();
	this.instance.parent = this;
	this.instance.setTransform(-44,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol44, new cjs.Rectangle(-44,-13,71,22), null);


(lib.Symbol43copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TayNinh();
	this.instance.parent = this;
	this.instance.setTransform(-47.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol43copy, new cjs.Rectangle(-47.5,-17,95,36), null);


(lib.Symbol43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VinhPhuc();
	this.instance.parent = this;
	this.instance.setTransform(-53.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol43, new cjs.Rectangle(-53.5,-13.5,74,20), null);


(lib.Symbol42copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongXoai();
	this.instance.parent = this;
	this.instance.setTransform(-53,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42copy, new cjs.Rectangle(-53,-16.5,74,24), null);


(lib.Symbol42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TuyenQuang();
	this.instance.parent = this;
	this.instance.setTransform(-77,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42, new cjs.Rectangle(-77,-16,100,24), null);


(lib.Symbol41copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongNai();
	this.instance.parent = this;
	this.instance.setTransform(-48.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol41copy, new cjs.Rectangle(-48.5,-16.5,97,36), null);


(lib.Symbol41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TuanGiao();
	this.instance.parent = this;
	this.instance.setTransform(-54.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol41, new cjs.Rectangle(-54.5,-13,109,28), null);


(lib.Symbol40copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BaoLoc();
	this.instance.parent = this;
	this.instance.setTransform(-41,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol40copy, new cjs.Rectangle(-41,-12.5,57,19), null);


(lib.Symbol40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TienYen();
	this.instance.parent = this;
	this.instance.setTransform(-45.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol40, new cjs.Rectangle(-45.5,-13,63,19), null);


(lib.Symbol39copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.GiaNghia();
	this.instance.parent = this;
	this.instance.setTransform(-51,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol39copy, new cjs.Rectangle(-51,-17,71,25), null);


(lib.Symbol39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThatKhe();
	this.instance.parent = this;
	this.instance.setTransform(-47.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol39, new cjs.Rectangle(-47.5,-13.5,67,20), null);


(lib.Symbol38copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhanThiet();
	this.instance.parent = this;
	this.instance.setTransform(-56.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol38copy, new cjs.Rectangle(-56.5,-13.5,113,28), null);


(lib.Symbol38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThanhHoa();
	this.instance.parent = this;
	this.instance.setTransform(-58.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol38, new cjs.Rectangle(-58.5,-13.5,82,20), null);


(lib.Symbol37copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuiNe();
	this.instance.parent = this;
	this.instance.setTransform(-37.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol37copy, new cjs.Rectangle(-37.5,-13,76,28), null);


(lib.Symbol37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ThanUyen();
	this.instance.parent = this;
	this.instance.setTransform(-57,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol37, new cjs.Rectangle(-57,-17,116,36), null);


(lib.Symbol36copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NinhGia();
	this.instance.parent = this;
	this.instance.setTransform(-45.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol36copy, new cjs.Rectangle(-45.5,-13.5,63,20), null);


(lib.Symbol36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.thaibinhpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-89,-39);

	this.instance_1 = new lib.ThaiBinh();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-57,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol36, new cjs.Rectangle(-89,-39,101,48), null);


(lib.Symbol35copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DaLat();
	this.instance.parent = this;
	this.instance.setTransform(-33.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol35copy, new cjs.Rectangle(-33.5,-12.5,56,28), null);


(lib.Symbol35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TanTrao();
	this.instance.parent = this;
	this.instance.setTransform(-47,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol35, new cjs.Rectangle(-47,-12.5,94,26), null);


(lib.Symbol34copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LacLake();
	this.instance.parent = this;
	this.instance.setTransform(-40,-14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol34copy, new cjs.Rectangle(-40,-14,63,20), null);


(lib.Symbol33copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BMeThuot();
	this.instance.parent = this;
	this.instance.setTransform(-61,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol33copy, new cjs.Rectangle(-61,-13.5,122,28), null);


(lib.Symbol33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SonLa();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol33, new cjs.Rectangle(-34.5,-12.5,70,27), null);


(lib.Symbol32copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Pleiku();
	this.instance.parent = this;
	this.instance.setTransform(-31.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol32copy, new cjs.Rectangle(-31.5,-13.5,63,28), null);


(lib.Symbol31copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BoY();
	this.instance.parent = this;
	this.instance.setTransform(-23,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol31copy, new cjs.Rectangle(-23,-12.5,46,26), null);


(lib.Symbol31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SinHo();
	this.instance.parent = this;
	this.instance.setTransform(-11,-8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol31, new cjs.Rectangle(-11,-8,47,19), null);


(lib.Symbol30copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BuonHo();
	this.instance.parent = this;
	this.instance.setTransform(-45.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol30copy, new cjs.Rectangle(-45.5,-12.5,64,19), null);


(lib.Symbol30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Shape1328();
	this.instance.parent = this;
	this.instance.setTransform(-6,29);

	this.instance_1 = new lib.SinCheng();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-83,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol30, new cjs.Rectangle(-83,17,128,132), null);


(lib.Symbol29copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KonTum();
	this.instance.parent = this;
	this.instance.setTransform(-47,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol29copy, new cjs.Rectangle(-47,-12.5,94,26), null);


(lib.Symbol29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Sapa();
	this.instance.parent = this;
	this.instance.setTransform(-25,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol29, new cjs.Rectangle(-25,-16,52,35), null);


(lib.Symbol28copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhanRang();
	this.instance.parent = this;
	this.instance.setTransform(-56.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol28copy, new cjs.Rectangle(-56.5,-17,115,36), null);


(lib.Symbol28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.QuangUyen();
	this.instance.parent = this;
	this.instance.setTransform(-65.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol28, new cjs.Rectangle(-65.5,-16,91,24), null);


(lib.Symbol27copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BinhBa();
	this.instance.parent = this;
	this.instance.setTransform(-40,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol27copy, new cjs.Rectangle(-40,-13.5,80,28), null);


(lib.Symbol27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.quanbapngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-19,8);

	this.instance_1 = new lib.QuanBa();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-51,-13);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol27, new cjs.Rectangle(-51,-13,97,80), null);


(lib.Symbol26copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NhaTrang();
	this.instance.parent = this;
	this.instance.setTransform(-55.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26copy, new cjs.Rectangle(-55.5,-17,111,36), null);


(lib.Symbol26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NghiaLo();
	this.instance.parent = this;
	this.instance.setTransform(-46,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26, new cjs.Rectangle(-46,-17,93,36), null);


(lib.Symbol25copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TuyHoa();
	this.instance.parent = this;
	this.instance.setTransform(-43.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol25copy, new cjs.Rectangle(-43.5,-16,88,34), null);


(lib.Symbol25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PuLuong();
	this.instance.parent = this;
	this.instance.setTransform(-49.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol25, new cjs.Rectangle(-49.5,-16,100,34), null);


(lib.Symbol24copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.QuyNhon();
	this.instance.parent = this;
	this.instance.setTransform(-53.5,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol24copy, new cjs.Rectangle(-53.5,-17,109,36), null);


(lib.Symbol24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NinhBinhpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-93,-64);

	this.instance_1 = new lib.NinhBinh();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-53,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol24, new cjs.Rectangle(-93,-64,145,79), null);


(lib.Symbol23copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HoangSa();
	this.instance.parent = this;
	this.instance.setTransform(-46.5,-38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol23copy, new cjs.Rectangle(-46.5,-38.5,94,75), null);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhuYen();
	this.instance.parent = this;
	this.instance.setTransform(-42.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol23, new cjs.Rectangle(-42.5,-13.5,60,20), null);


(lib.Symbol22copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhuocSon();
	this.instance.parent = this;
	this.instance.setTransform(-55,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol22copy, new cjs.Rectangle(-55,-13.5,77,20), null);


(lib.Symbol22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhongTho();
	this.instance.parent = this;
	this.instance.setTransform(-32,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol22, new cjs.Rectangle(-32,-7,79,25), null);


(lib.Symbol21copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SonHa();
	this.instance.parent = this;
	this.instance.setTransform(-37,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol21copy, new cjs.Rectangle(-37,-12.5,52,19), null);


(lib.Symbol21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.namdinhpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-102,-49);

	this.instance_1 = new lib.NamDinh();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-56,-11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol21, new cjs.Rectangle(-102,-49,120,58), null);


(lib.Symbol20copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.QuangNgai();
	this.instance.parent = this;
	this.instance.setTransform(-62,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol20copy, new cjs.Rectangle(-62,-16.5,125,36), null);


(lib.Symbol20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MuongLay();
	this.instance.parent = this;
	this.instance.setTransform(-58.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol20, new cjs.Rectangle(-58.5,-16,118,34), null);


(lib.Symbol19copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LySon();
	this.instance.parent = this;
	this.instance.setTransform(-33.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19copy2, new cjs.Rectangle(-33.5,-16,68,35), null);


(lib.Symbol19copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.muonghumpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(30,8);

	this.instance_1 = new lib.MuongHum();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-28,-19);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19copy, new cjs.Rectangle(-28,-19,123,77), null);


(lib.Symbol18copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CuLaoCham();
	this.instance.parent = this;
	this.instance.setTransform(-54,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18copy2, new cjs.Rectangle(-54,-10,140,28), null);


(lib.Symbol18copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MongCai();
	this.instance.parent = this;
	this.instance.setTransform(-48.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18copy, new cjs.Rectangle(-48.5,-16.5,68,24), null);


(lib.Symbol17copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MocChau();
	this.instance.parent = this;
	this.instance.setTransform(-52,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17copy, new cjs.Rectangle(-52,-13.5,105,28), null);


(lib.Symbol16copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NamGiang();
	this.instance.parent = this;
	this.instance.setTransform(-59,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol16copy2, new cjs.Rectangle(-59,-16.5,83,24), null);


(lib.Symbol16copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MeoVac();
	this.instance.parent = this;
	this.instance.setTransform(-47,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol16copy, new cjs.Rectangle(-47,-13,90,26), null);


(lib.Symbol15copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongGiang();
	this.instance.parent = this;
	this.instance.setTransform(-61.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol15copy2, new cjs.Rectangle(-61.5,-16.5,85,24), null);


(lib.Symbol15copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MaiChau();
	this.instance.parent = this;
	this.instance.setTransform(-23,-11);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol15copy, new cjs.Rectangle(-23,-11,99,28), null);


(lib.Symbol14copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ARoang();
	this.instance.parent = this;
	this.instance.setTransform(-44,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14copy2, new cjs.Rectangle(-44,-16,62,24), null);


(lib.Symbol14copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LungCu();
	this.instance.parent = this;
	this.instance.setTransform(-42,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14copy, new cjs.Rectangle(-42,-16,85,35), null);


(lib.Symbol13copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HoiAn();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol13copy2, new cjs.Rectangle(-34.5,-13,62,28), null);


(lib.Symbol13copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.laocaipngcopy();
	this.instance.parent = this;
	this.instance.setTransform(62,13);

	this.instance_1 = new lib.LaoCai();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-16,-9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol13copy, new cjs.Rectangle(-16,-9,107,57), null);


(lib.Symbol12copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Danang();
	this.instance.parent = this;
	this.instance.setTransform(-49,-11);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12copy2, new cjs.Rectangle(-49,-11,85,34), null);


(lib.Symbol12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LangSon();
	this.instance.parent = this;
	this.instance.setTransform(-47,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12copy, new cjs.Rectangle(-47,-16,96,35), null);


(lib.Symbol11copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MySon();
	this.instance.parent = this;
	this.instance.setTransform(-38,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11copy2, new cjs.Rectangle(-38,-16,77,35), null);


(lib.Symbol11copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LaiChau();
	this.instance.parent = this;
	this.instance.setTransform(-22,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11copy, new cjs.Rectangle(-22,-10,90,28), null);


(lib.Symbol10copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.KheXanh();
	this.instance.parent = this;
	this.instance.setTransform(-50,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10copy2, new cjs.Rectangle(-50,-13.5,100,28), null);


(lib.Symbol10copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LungKhauNhinpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-95,-8);

	this.instance_1 = new lib.lungkhaunhin();
	this.instance_1.parent = this;
	this.instance_1.setTransform(31,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10copy, new cjs.Rectangle(-95,-8,259,100), null);


(lib.Symbol9copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PhongNha();
	this.instance.parent = this;
	this.instance.setTransform(-58,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9copy2, new cjs.Rectangle(-58,-17,117,36), null);


(lib.Symbol9copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HoaBinh();
	this.instance.parent = this;
	this.instance.setTransform(-46,-14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9copy, new cjs.Rectangle(-46,-14,97,28), null);


(lib.Symbol8copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CauTreo();
	this.instance.parent = this;
	this.instance.setTransform(-47,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8copy3, new cjs.Rectangle(-47,-12.5,95,27), null);


(lib.Symbol8copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HANOI();
	this.instance.parent = this;
	this.instance.setTransform(-37,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8copy2, new cjs.Rectangle(-37,-12.5,86,27), null);


(lib.Symbol7copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Hue();
	this.instance.parent = this;
	this.instance.setTransform(-21,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7copy4, new cjs.Rectangle(-21,-12.5,44,26), null);


(lib.Symbol7copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaiPhong();
	this.instance.parent = this;
	this.instance.setTransform(-54,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7copy3, new cjs.Rectangle(-54,-17,109,36), null);


(lib.Symbol6copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.QuangTri();
	this.instance.parent = this;
	this.instance.setTransform(-51.5,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6copy3, new cjs.Rectangle(-51.5,-16.5,103,36), null);


(lib.Symbol6copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaLong();
	this.instance.parent = this;
	this.instance.setTransform(-43,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6copy2, new cjs.Rectangle(-43,-16,76,36), null);


(lib.Symbol5copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VinhMocTunnels();
	this.instance.parent = this;
	this.instance.setTransform(-95,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5copy3, new cjs.Rectangle(-95,-13.5,190,28), null);


(lib.Symbol5copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaGiang();
	this.instance.parent = this;
	this.instance.setTransform(-48,-16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5copy2, new cjs.Rectangle(-48,-16.5,97,36), null);


(lib.Symbol4copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DongHoi();
	this.instance.parent = this;
	this.instance.setTransform(-68,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4copy4, new cjs.Rectangle(-68,-17,97,36), null);


(lib.Symbol4copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HSuPhi();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4copy3, new cjs.Rectangle(0,0,73,23), null);


(lib.Symbol4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.imgdot();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-7,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4_1, new cjs.Rectangle(-7,-7,14,14), null);


(lib.Symbol3copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaTinh();
	this.instance.parent = this;
	this.instance.setTransform(-40,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3copy3, new cjs.Rectangle(-40,-13.5,55,20), null);


(lib.Symbol3copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DuongLam();
	this.instance.parent = this;
	this.instance.setTransform(-60.5,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3copy2, new cjs.Rectangle(-60.5,-16,85,24), null);


(lib.Symbol3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.CachedTexturedBitmap_588();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.6574,0.6574);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3_1, new cjs.Rectangle(0,0,28.3,28.3), null);


(lib.Symbol2copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.PakBeng();
	this.instance.parent = this;
	this.instance.setTransform(-35.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy4, new cjs.Rectangle(-35.5,-12.5,99,36), null);


(lib.Symbol2copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Vinh();
	this.instance.parent = this;
	this.instance.setTransform(-24,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy3, new cjs.Rectangle(-24,-13,34,20), null);


(lib.Symbol2copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.dongvanpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-100,0);

	this.instance_1 = new lib.DongVan();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-52,-9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy2, new cjs.Rectangle(-100,-9,150,47), null);


(lib.Symbol2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.HaNoiDongHoi();
	this.instance.parent = this;
	this.instance.setTransform(310,305,0.9418,0.9418);

	this.instance_1 = new lib.ghichucacphuongtien();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy, new cjs.Rectangle(0,0,367,367), null);


(lib.Symbol2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.CachedTexturedBitmap_587();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.8,-2.8,0.8725,0.8725);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2_1, new cjs.Rectangle(-2.8,-2.8,34.1,34.1), null);


(lib.Symbol1copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.XuanMai();
	this.instance.parent = this;
	this.instance.setTransform(-29,-8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy6, new cjs.Rectangle(-29,-8,70,19), null);


(lib.Symbol1copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BaBe();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy3, new cjs.Rectangle(0,0,59,26), null);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_586();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5701,0.5701);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(0,0,59.9,33.1), null);


(lib.Path_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_585();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5228,0.5228);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_0, new cjs.Rectangle(0,0,59.6,33.5), null);


(lib.Path = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_584();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5906,0.5906);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0,0,59.7,33.1), null);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.icontàuthủy();
	this.instance.parent = this;
	this.instance.setTransform(-61.5,-32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(-61.5,-32,123,64), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.iconmoto();
	this.instance.parent = this;
	this.instance.setTransform(-45.5,-31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(-45.5,-31,91,62), null);


(lib.Symbol7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib._66906();
	this.instance_1.parent = this;
	this.instance_1.setTransform(6.8,19.8,0.5798,0.5798);

	this.instance_2 = new lib.CachedTexturedBitmap_583();
	this.instance_2.parent = this;
	this.instance_2.setTransform(9.75,6.35,0.6325,0.6325);

	this.instance_3 = new lib.CachedTexturedBitmap_582();
	this.instance_3.parent = this;
	this.instance_3.setTransform(21.9,38.65,0.6325,0.6325);

	this.instance_4 = new lib.CachedTexturedBitmap_581();
	this.instance_4.parent = this;
	this.instance_4.setTransform(21.7,38.25,0.6325,0.6325);

	this.instance_5 = new lib.CachedTexturedBitmap_580();
	this.instance_5.parent = this;
	this.instance_5.setTransform(21.5,37.8,0.6325,0.6325);

	this.instance_6 = new lib.CachedTexturedBitmap_579();
	this.instance_6.parent = this;
	this.instance_6.setTransform(21.25,37.4,0.6325,0.6325);

	this.instance_7 = new lib.CachedTexturedBitmap_578();
	this.instance_7.parent = this;
	this.instance_7.setTransform(21.05,37,0.6325,0.6325);

	this.instance_8 = new lib.CachedTexturedBitmap_577();
	this.instance_8.parent = this;
	this.instance_8.setTransform(20.8,36.55,0.6325,0.6325);

	this.instance_9 = new lib.CachedTexturedBitmap_576();
	this.instance_9.parent = this;
	this.instance_9.setTransform(20.65,36.1,0.6325,0.6325);

	this.instance_10 = new lib.CachedTexturedBitmap_575();
	this.instance_10.parent = this;
	this.instance_10.setTransform(20.4,35.75,0.6325,0.6325);

	this.instance_11 = new lib.CachedTexturedBitmap_574();
	this.instance_11.parent = this;
	this.instance_11.setTransform(20.2,35.3,0.6325,0.6325);

	this.instance_12 = new lib.CachedTexturedBitmap_573();
	this.instance_12.parent = this;
	this.instance_12.setTransform(19.95,34.9,0.6325,0.6325);

	this.instance_13 = new lib.CachedTexturedBitmap_572();
	this.instance_13.parent = this;
	this.instance_13.setTransform(19.75,34.5,0.6325,0.6325);

	this.instance_14 = new lib.CachedTexturedBitmap_571();
	this.instance_14.parent = this;
	this.instance_14.setTransform(19.55,34.05,0.6325,0.6325);

	this.instance_15 = new lib.CachedTexturedBitmap_570();
	this.instance_15.parent = this;
	this.instance_15.setTransform(19.35,33.6,0.6325,0.6325);

	this.instance_16 = new lib.CachedTexturedBitmap_569();
	this.instance_16.parent = this;
	this.instance_16.setTransform(19.1,33.2,0.6325,0.6325);

	this.instance_17 = new lib.CachedTexturedBitmap_568();
	this.instance_17.parent = this;
	this.instance_17.setTransform(18.9,32.8,0.6325,0.6325);

	this.instance_18 = new lib.CachedTexturedBitmap_567();
	this.instance_18.parent = this;
	this.instance_18.setTransform(18.7,32.35,0.6325,0.6325);

	this.instance_19 = new lib.CachedTexturedBitmap_566();
	this.instance_19.parent = this;
	this.instance_19.setTransform(18.5,31.95,0.6325,0.6325);

	this.instance_20 = new lib.CachedTexturedBitmap_565();
	this.instance_20.parent = this;
	this.instance_20.setTransform(18.25,31.55,0.6325,0.6325);

	this.instance_21 = new lib.CachedTexturedBitmap_564();
	this.instance_21.parent = this;
	this.instance_21.setTransform(18.05,31.15,0.6325,0.6325);

	this.instance_22 = new lib.CachedTexturedBitmap_563();
	this.instance_22.parent = this;
	this.instance_22.setTransform(17.8,30.7,0.6325,0.6325);

	this.instance_23 = new lib.CachedTexturedBitmap_562();
	this.instance_23.parent = this;
	this.instance_23.setTransform(17.6,30.25,0.6325,0.6325);

	this.instance_24 = new lib.CachedTexturedBitmap_561();
	this.instance_24.parent = this;
	this.instance_24.setTransform(17.4,29.85,0.6325,0.6325);

	this.instance_25 = new lib.CachedTexturedBitmap_560();
	this.instance_25.parent = this;
	this.instance_25.setTransform(17.2,29.45,0.6325,0.6325);

	this.instance_26 = new lib.CachedTexturedBitmap_559();
	this.instance_26.parent = this;
	this.instance_26.setTransform(16.95,29,0.6325,0.6325);

	this.instance_27 = new lib.CachedTexturedBitmap_558();
	this.instance_27.parent = this;
	this.instance_27.setTransform(16.75,28.65,0.6325,0.6325);

	this.instance_28 = new lib.CachedTexturedBitmap_557();
	this.instance_28.parent = this;
	this.instance_28.setTransform(16.55,28.2,0.6325,0.6325);

	this.instance_29 = new lib.CachedTexturedBitmap_556();
	this.instance_29.parent = this;
	this.instance_29.setTransform(16.3,27.75,0.6325,0.6325);

	this.instance_30 = new lib.CachedTexturedBitmap_555();
	this.instance_30.parent = this;
	this.instance_30.setTransform(16.1,27.35,0.6325,0.6325);

	this.instance_31 = new lib.CachedTexturedBitmap_554();
	this.instance_31.parent = this;
	this.instance_31.setTransform(15.9,26.95,0.6325,0.6325);

	this.instance_32 = new lib.CachedTexturedBitmap_553();
	this.instance_32.parent = this;
	this.instance_32.setTransform(15.7,26.5,0.6325,0.6325);

	this.instance_33 = new lib.CachedTexturedBitmap_552();
	this.instance_33.parent = this;
	this.instance_33.setTransform(15.45,26.1,0.6325,0.6325);

	this.instance_34 = new lib.CachedTexturedBitmap_551();
	this.instance_34.parent = this;
	this.instance_34.setTransform(15.25,25.7,0.6325,0.6325);

	this.instance_35 = new lib.CachedTexturedBitmap_550();
	this.instance_35.parent = this;
	this.instance_35.setTransform(15.05,25.25,0.6325,0.6325);

	this.instance_36 = new lib.CachedTexturedBitmap_549();
	this.instance_36.parent = this;
	this.instance_36.setTransform(14.8,24.85,0.6325,0.6325);

	this.instance_37 = new lib.CachedTexturedBitmap_548();
	this.instance_37.parent = this;
	this.instance_37.setTransform(14.6,24.4,0.6325,0.6325);

	this.instance_38 = new lib.CachedTexturedBitmap_547();
	this.instance_38.parent = this;
	this.instance_38.setTransform(14.4,24,0.6325,0.6325);

	this.instance_39 = new lib.CachedTexturedBitmap_546();
	this.instance_39.parent = this;
	this.instance_39.setTransform(14.15,23.6,0.6325,0.6325);

	this.instance_40 = new lib.CachedTexturedBitmap_545();
	this.instance_40.parent = this;
	this.instance_40.setTransform(13.95,23.15,0.6325,0.6325);

	this.instance_41 = new lib.CachedTexturedBitmap_544();
	this.instance_41.parent = this;
	this.instance_41.setTransform(13.75,22.75,0.6325,0.6325);

	this.instance_42 = new lib.CachedTexturedBitmap_543();
	this.instance_42.parent = this;
	this.instance_42.setTransform(13.55,22.35,0.6325,0.6325);

	this.instance_43 = new lib.CachedTexturedBitmap_542();
	this.instance_43.parent = this;
	this.instance_43.setTransform(13.3,21.9,0.6325,0.6325);

	this.instance_44 = new lib.CachedTexturedBitmap_541();
	this.instance_44.parent = this;
	this.instance_44.setTransform(13.15,21.5,0.6325,0.6325);

	this.instance_45 = new lib.CachedTexturedBitmap_540();
	this.instance_45.parent = this;
	this.instance_45.setTransform(12.9,21.05,0.6325,0.6325);

	this.instance_46 = new lib.CachedTexturedBitmap_539();
	this.instance_46.parent = this;
	this.instance_46.setTransform(12.7,20.65,0.6325,0.6325);

	this.instance_47 = new lib.CachedTexturedBitmap_538();
	this.instance_47.parent = this;
	this.instance_47.setTransform(12.45,20.2,0.6325,0.6325);

	this.instance_48 = new lib.CachedTexturedBitmap_537();
	this.instance_48.parent = this;
	this.instance_48.setTransform(12.3,19.85,0.6325,0.6325);

	this.instance_49 = new lib.CachedTexturedBitmap_536();
	this.instance_49.parent = this;
	this.instance_49.setTransform(12.05,19.4,0.6325,0.6325);

	this.instance_50 = new lib.CachedTexturedBitmap_535();
	this.instance_50.parent = this;
	this.instance_50.setTransform(11.85,19,0.6325,0.6325);

	this.instance_51 = new lib.CachedTexturedBitmap_534();
	this.instance_51.parent = this;
	this.instance_51.setTransform(11.6,18.55,0.6325,0.6325);

	this.instance_52 = new lib.CachedTexturedBitmap_533();
	this.instance_52.parent = this;
	this.instance_52.setTransform(11.4,18.15,0.6325,0.6325);

	this.instance_53 = new lib.CachedTexturedBitmap_532();
	this.instance_53.parent = this;
	this.instance_53.setTransform(11.15,17.7,0.6325,0.6325);

	this.instance_54 = new lib.CachedTexturedBitmap_531();
	this.instance_54.parent = this;
	this.instance_54.setTransform(11,17.3,0.6325,0.6325);

	this.instance_55 = new lib.CachedTexturedBitmap_530();
	this.instance_55.parent = this;
	this.instance_55.setTransform(10.75,16.9,0.6325,0.6325);

	this.instance_56 = new lib.CachedTexturedBitmap_529();
	this.instance_56.parent = this;
	this.instance_56.setTransform(10.55,16.5,0.6325,0.6325);

	this.instance_57 = new lib.CachedTexturedBitmap_528();
	this.instance_57.parent = this;
	this.instance_57.setTransform(10.3,16.05,0.6325,0.6325);

	this.instance_58 = new lib.CachedTexturedBitmap_527();
	this.instance_58.parent = this;
	this.instance_58.setTransform(10.15,15.65,0.6325,0.6325);

	this.instance_59 = new lib.CachedTexturedBitmap_526();
	this.instance_59.parent = this;
	this.instance_59.setTransform(9.9,15.2,0.6325,0.6325);

	this.instance_60 = new lib.CachedTexturedBitmap_525();
	this.instance_60.parent = this;
	this.instance_60.setTransform(9.7,14.8,0.6325,0.6325);

	this.instance_61 = new lib.CachedTexturedBitmap_524();
	this.instance_61.parent = this;
	this.instance_61.setTransform(9.45,14.35,0.6325,0.6325);

	this.instance_62 = new lib.CachedTexturedBitmap_523();
	this.instance_62.parent = this;
	this.instance_62.setTransform(9.25,14,0.6325,0.6325);

	this.instance_63 = new lib.CachedTexturedBitmap_522();
	this.instance_63.parent = this;
	this.instance_63.setTransform(9,13.55,0.6325,0.6325);

	this.instance_64 = new lib.CachedTexturedBitmap_521();
	this.instance_64.parent = this;
	this.instance_64.setTransform(8.85,13.15,0.6325,0.6325);

	this.instance_65 = new lib.CachedTexturedBitmap_520();
	this.instance_65.parent = this;
	this.instance_65.setTransform(8.6,12.7,0.6325,0.6325);

	this.instance_66 = new lib.CachedTexturedBitmap_519();
	this.instance_66.parent = this;
	this.instance_66.setTransform(8.4,12.3,0.6325,0.6325);

	this.instance_67 = new lib.CachedTexturedBitmap_518();
	this.instance_67.parent = this;
	this.instance_67.setTransform(8.15,11.85,0.6325,0.6325);

	this.instance_68 = new lib.CachedTexturedBitmap_517();
	this.instance_68.parent = this;
	this.instance_68.setTransform(8,11.45,0.6325,0.6325);

	this.instance_69 = new lib.CachedTexturedBitmap_516();
	this.instance_69.parent = this;
	this.instance_69.setTransform(7.75,11.05,0.6325,0.6325);

	this.instance_70 = new lib.CachedTexturedBitmap_515();
	this.instance_70.parent = this;
	this.instance_70.setTransform(7.55,10.6,0.6325,0.6325);

	this.instance_71 = new lib.CachedTexturedBitmap_514();
	this.instance_71.parent = this;
	this.instance_71.setTransform(7.3,10.2,0.6325,0.6325);

	this.instance_72 = new lib.CachedTexturedBitmap_513();
	this.instance_72.parent = this;
	this.instance_72.setTransform(7.1,9.8,0.6325,0.6325);

	this.instance_73 = new lib.CachedTexturedBitmap_512();
	this.instance_73.parent = this;
	this.instance_73.setTransform(6.9,9.35,0.6325,0.6325);

	this.instance_74 = new lib.CachedTexturedBitmap_511();
	this.instance_74.parent = this;
	this.instance_74.setTransform(6.7,8.9,0.6325,0.6325);

	this.instance_75 = new lib.CachedTexturedBitmap_510();
	this.instance_75.parent = this;
	this.instance_75.setTransform(6.45,8.5,0.6325,0.6325);

	this.instance_76 = new lib.CachedTexturedBitmap_509();
	this.instance_76.parent = this;
	this.instance_76.setTransform(6.25,8.1,0.6325,0.6325);

	this.instance_77 = new lib.CachedTexturedBitmap_508();
	this.instance_77.parent = this;
	this.instance_77.setTransform(6,7.7,0.6325,0.6325);

	this.instance_78 = new lib.CachedTexturedBitmap_507();
	this.instance_78.parent = this;
	this.instance_78.setTransform(5.85,7.25,0.6325,0.6325);

	this.instance_79 = new lib.CachedTexturedBitmap_506();
	this.instance_79.parent = this;
	this.instance_79.setTransform(5.6,6.85,0.6325,0.6325);

	this.instance_80 = new lib.CachedTexturedBitmap_505();
	this.instance_80.parent = this;
	this.instance_80.setTransform(5.4,6.45,0.6325,0.6325);

	this.instance_81 = new lib.CachedTexturedBitmap_504();
	this.instance_81.parent = this;
	this.instance_81.setTransform(5.15,6,0.6325,0.6325);

	this.instance_82 = new lib.CachedTexturedBitmap_504();
	this.instance_82.parent = this;
	this.instance_82.setTransform(5.15,6,0.6325,0.6325);

	this.instance_83 = new lib.CachedTexturedBitmap_504();
	this.instance_83.parent = this;
	this.instance_83.setTransform(5.15,6,0.6325,0.6325);

	this.instance_84 = new lib.CachedTexturedBitmap_501();
	this.instance_84.parent = this;
	this.instance_84.setTransform(4.35,3.6,0.6325,0.6325);

	this.instance_85 = new lib.CachedTexturedBitmap_500();
	this.instance_85.parent = this;
	this.instance_85.setTransform(3.7,5.4,0.6325,0.6325);

	this.instance_86 = new lib.CachedTexturedBitmap_499();
	this.instance_86.parent = this;
	this.instance_86.setTransform(0,0,0.6325,0.6325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7_1, new cjs.Rectangle(0,0,63.3,63.3), null);


(lib.Symbol4_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.HaNoiDongHoi();
	this.instance_2.parent = this;
	this.instance_2.setTransform(13,11,0.6744,0.6744);

	this.instance_3 = new lib.CachedTexturedBitmap_363();
	this.instance_3.parent = this;
	this.instance_3.setTransform(7.65,5,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_362();
	this.instance_4.parent = this;
	this.instance_4.setTransform(17.25,30.4,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_361();
	this.instance_5.parent = this;
	this.instance_5.setTransform(17.05,30,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_360();
	this.instance_6.parent = this;
	this.instance_6.setTransform(16.85,29.6,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_359();
	this.instance_7.parent = this;
	this.instance_7.setTransform(16.65,29.2,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_358();
	this.instance_8.parent = this;
	this.instance_8.setTransform(16.45,28.8,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_357();
	this.instance_9.parent = this;
	this.instance_9.setTransform(16.25,28.4,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_356();
	this.instance_10.parent = this;
	this.instance_10.setTransform(16,28,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_355();
	this.instance_11.parent = this;
	this.instance_11.setTransform(15.8,27.6,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_354();
	this.instance_12.parent = this;
	this.instance_12.setTransform(15.6,27.2,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_353();
	this.instance_13.parent = this;
	this.instance_13.setTransform(15.4,26.8,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_352();
	this.instance_14.parent = this;
	this.instance_14.setTransform(15.2,26.4,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_351();
	this.instance_15.parent = this;
	this.instance_15.setTransform(15,26,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_350();
	this.instance_16.parent = this;
	this.instance_16.setTransform(14.8,25.6,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_349();
	this.instance_17.parent = this;
	this.instance_17.setTransform(14.55,25.2,0.5,0.5);

	this.instance_18 = new lib.CachedTexturedBitmap_348();
	this.instance_18.parent = this;
	this.instance_18.setTransform(14.35,24.8,0.5,0.5);

	this.instance_19 = new lib.CachedTexturedBitmap_347();
	this.instance_19.parent = this;
	this.instance_19.setTransform(14.15,24.4,0.5,0.5);

	this.instance_20 = new lib.CachedTexturedBitmap_346();
	this.instance_20.parent = this;
	this.instance_20.setTransform(13.95,24,0.5,0.5);

	this.instance_21 = new lib.CachedTexturedBitmap_345();
	this.instance_21.parent = this;
	this.instance_21.setTransform(13.75,23.6,0.5,0.5);

	this.instance_22 = new lib.CachedTexturedBitmap_344();
	this.instance_22.parent = this;
	this.instance_22.setTransform(13.55,23.2,0.5,0.5);

	this.instance_23 = new lib.CachedTexturedBitmap_343();
	this.instance_23.parent = this;
	this.instance_23.setTransform(13.35,22.75,0.5,0.5);

	this.instance_24 = new lib.CachedTexturedBitmap_342();
	this.instance_24.parent = this;
	this.instance_24.setTransform(13.1,22.4,0.5,0.5);

	this.instance_25 = new lib.CachedTexturedBitmap_341();
	this.instance_25.parent = this;
	this.instance_25.setTransform(12.95,21.95,0.5,0.5);

	this.instance_26 = new lib.CachedTexturedBitmap_340();
	this.instance_26.parent = this;
	this.instance_26.setTransform(12.7,21.6,0.5,0.5);

	this.instance_27 = new lib.CachedTexturedBitmap_339();
	this.instance_27.parent = this;
	this.instance_27.setTransform(12.5,21.15,0.5,0.5);

	this.instance_28 = new lib.CachedTexturedBitmap_338();
	this.instance_28.parent = this;
	this.instance_28.setTransform(12.3,20.8,0.5,0.5);

	this.instance_29 = new lib.CachedTexturedBitmap_337();
	this.instance_29.parent = this;
	this.instance_29.setTransform(12.1,20.35,0.5,0.5);

	this.instance_30 = new lib.CachedTexturedBitmap_336();
	this.instance_30.parent = this;
	this.instance_30.setTransform(11.9,19.95,0.5,0.5);

	this.instance_31 = new lib.CachedTexturedBitmap_335();
	this.instance_31.parent = this;
	this.instance_31.setTransform(11.7,19.55,0.5,0.5);

	this.instance_32 = new lib.CachedTexturedBitmap_334();
	this.instance_32.parent = this;
	this.instance_32.setTransform(11.5,19.15,0.5,0.5);

	this.instance_33 = new lib.CachedTexturedBitmap_333();
	this.instance_33.parent = this;
	this.instance_33.setTransform(11.25,18.75,0.5,0.5);

	this.instance_34 = new lib.CachedTexturedBitmap_332();
	this.instance_34.parent = this;
	this.instance_34.setTransform(11.05,18.35,0.5,0.5);

	this.instance_35 = new lib.CachedTexturedBitmap_331();
	this.instance_35.parent = this;
	this.instance_35.setTransform(10.85,17.95,0.5,0.5);

	this.instance_36 = new lib.CachedTexturedBitmap_330();
	this.instance_36.parent = this;
	this.instance_36.setTransform(10.65,17.55,0.5,0.5);

	this.instance_37 = new lib.CachedTexturedBitmap_329();
	this.instance_37.parent = this;
	this.instance_37.setTransform(10.45,17.15,0.5,0.5);

	this.instance_38 = new lib.CachedTexturedBitmap_328();
	this.instance_38.parent = this;
	this.instance_38.setTransform(10.25,16.75,0.5,0.5);

	this.instance_39 = new lib.CachedTexturedBitmap_327();
	this.instance_39.parent = this;
	this.instance_39.setTransform(10.05,16.35,0.5,0.5);

	this.instance_40 = new lib.CachedTexturedBitmap_326();
	this.instance_40.parent = this;
	this.instance_40.setTransform(9.8,15.95,0.5,0.5);

	this.instance_41 = new lib.CachedTexturedBitmap_325();
	this.instance_41.parent = this;
	this.instance_41.setTransform(9.6,15.55,0.5,0.5);

	this.instance_42 = new lib.CachedTexturedBitmap_324();
	this.instance_42.parent = this;
	this.instance_42.setTransform(9.4,15.15,0.5,0.5);

	this.instance_43 = new lib.CachedTexturedBitmap_323();
	this.instance_43.parent = this;
	this.instance_43.setTransform(9.2,14.75,0.5,0.5);

	this.instance_44 = new lib.CachedTexturedBitmap_322();
	this.instance_44.parent = this;
	this.instance_44.setTransform(9,14.35,0.5,0.5);

	this.instance_45 = new lib.CachedTexturedBitmap_321();
	this.instance_45.parent = this;
	this.instance_45.setTransform(8.8,13.95,0.5,0.5);

	this.instance_46 = new lib.CachedTexturedBitmap_320();
	this.instance_46.parent = this;
	this.instance_46.setTransform(8.6,13.55,0.5,0.5);

	this.instance_47 = new lib.CachedTexturedBitmap_319();
	this.instance_47.parent = this;
	this.instance_47.setTransform(8.35,13.15,0.5,0.5);

	this.instance_48 = new lib.CachedTexturedBitmap_318();
	this.instance_48.parent = this;
	this.instance_48.setTransform(8.15,12.75,0.5,0.5);

	this.instance_49 = new lib.CachedTexturedBitmap_317();
	this.instance_49.parent = this;
	this.instance_49.setTransform(7.95,12.35,0.5,0.5);

	this.instance_50 = new lib.CachedTexturedBitmap_316();
	this.instance_50.parent = this;
	this.instance_50.setTransform(7.75,11.95,0.5,0.5);

	this.instance_51 = new lib.CachedTexturedBitmap_315();
	this.instance_51.parent = this;
	this.instance_51.setTransform(7.55,11.55,0.5,0.5);

	this.instance_52 = new lib.CachedTexturedBitmap_314();
	this.instance_52.parent = this;
	this.instance_52.setTransform(7.35,11.15,0.5,0.5);

	this.instance_53 = new lib.CachedTexturedBitmap_313();
	this.instance_53.parent = this;
	this.instance_53.setTransform(7.15,10.75,0.5,0.5);

	this.instance_54 = new lib.CachedTexturedBitmap_312();
	this.instance_54.parent = this;
	this.instance_54.setTransform(6.9,10.35,0.5,0.5);

	this.instance_55 = new lib.CachedTexturedBitmap_311();
	this.instance_55.parent = this;
	this.instance_55.setTransform(6.75,9.95,0.5,0.5);

	this.instance_56 = new lib.CachedTexturedBitmap_310();
	this.instance_56.parent = this;
	this.instance_56.setTransform(6.5,9.55,0.5,0.5);

	this.instance_57 = new lib.CachedTexturedBitmap_309();
	this.instance_57.parent = this;
	this.instance_57.setTransform(6.3,9.15,0.5,0.5);

	this.instance_58 = new lib.CachedTexturedBitmap_308();
	this.instance_58.parent = this;
	this.instance_58.setTransform(6.1,8.7,0.5,0.5);

	this.instance_59 = new lib.CachedTexturedBitmap_307();
	this.instance_59.parent = this;
	this.instance_59.setTransform(5.9,8.3,0.5,0.5);

	this.instance_60 = new lib.CachedTexturedBitmap_306();
	this.instance_60.parent = this;
	this.instance_60.setTransform(5.7,7.9,0.5,0.5);

	this.instance_61 = new lib.CachedTexturedBitmap_305();
	this.instance_61.parent = this;
	this.instance_61.setTransform(5.5,7.5,0.5,0.5);

	this.instance_62 = new lib.CachedTexturedBitmap_304();
	this.instance_62.parent = this;
	this.instance_62.setTransform(5.3,7.1,0.5,0.5);

	this.instance_63 = new lib.CachedTexturedBitmap_303();
	this.instance_63.parent = this;
	this.instance_63.setTransform(5.05,6.7,0.5,0.5);

	this.instance_64 = new lib.CachedTexturedBitmap_302();
	this.instance_64.parent = this;
	this.instance_64.setTransform(4.85,6.3,0.5,0.5);

	this.instance_65 = new lib.CachedTexturedBitmap_301();
	this.instance_65.parent = this;
	this.instance_65.setTransform(4.65,5.9,0.5,0.5);

	this.instance_66 = new lib.CachedTexturedBitmap_300();
	this.instance_66.parent = this;
	this.instance_66.setTransform(4.45,5.5,0.5,0.5);

	this.instance_67 = new lib.CachedTexturedBitmap_299();
	this.instance_67.parent = this;
	this.instance_67.setTransform(4.25,5.1,0.5,0.5);

	this.instance_68 = new lib.CachedTexturedBitmap_298();
	this.instance_68.parent = this;
	this.instance_68.setTransform(4.05,4.7,0.5,0.5);

	this.instance_69 = new lib.CachedTexturedBitmap_298();
	this.instance_69.parent = this;
	this.instance_69.setTransform(4.05,4.7,0.5,0.5);

	this.instance_70 = new lib.CachedTexturedBitmap_298();
	this.instance_70.parent = this;
	this.instance_70.setTransform(4.05,4.7,0.5,0.5);

	this.instance_71 = new lib.CachedTexturedBitmap_295();
	this.instance_71.parent = this;
	this.instance_71.setTransform(3.35,2.8,0.5,0.5);

	this.instance_72 = new lib.CachedTexturedBitmap_294();
	this.instance_72.parent = this;
	this.instance_72.setTransform(2.85,4.2,0.5,0.5);

	this.instance_73 = new lib.CachedTexturedBitmap_293();
	this.instance_73.parent = this;
	this.instance_73.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4_2, new cjs.Rectangle(0,0,50,50), null);


(lib.Symbol2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.iconmáybay();
	this.instance_2.parent = this;
	this.instance_2.setTransform(8.9,10.5,0.4,0.4);

	this.instance_3 = new lib.CachedTexturedBitmap_144();
	this.instance_3.parent = this;
	this.instance_3.setTransform(7.65,5,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_143();
	this.instance_4.parent = this;
	this.instance_4.setTransform(17.3,30.4,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_142();
	this.instance_5.parent = this;
	this.instance_5.setTransform(17.05,30,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_141();
	this.instance_6.parent = this;
	this.instance_6.setTransform(16.85,29.65,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_140();
	this.instance_7.parent = this;
	this.instance_7.setTransform(16.65,29.25,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_139();
	this.instance_8.parent = this;
	this.instance_8.setTransform(16.45,28.85,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_138();
	this.instance_9.parent = this;
	this.instance_9.setTransform(16.25,28.45,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_137();
	this.instance_10.parent = this;
	this.instance_10.setTransform(16.05,28.05,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_136();
	this.instance_11.parent = this;
	this.instance_11.setTransform(15.85,27.65,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_135();
	this.instance_12.parent = this;
	this.instance_12.setTransform(15.65,27.25,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_134();
	this.instance_13.parent = this;
	this.instance_13.setTransform(15.45,26.85,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_133();
	this.instance_14.parent = this;
	this.instance_14.setTransform(15.25,26.45,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_132();
	this.instance_15.parent = this;
	this.instance_15.setTransform(15.05,26.1,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_131();
	this.instance_16.parent = this;
	this.instance_16.setTransform(14.85,25.7,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_130();
	this.instance_17.parent = this;
	this.instance_17.setTransform(14.65,25.3,0.5,0.5);

	this.instance_18 = new lib.CachedTexturedBitmap_129();
	this.instance_18.parent = this;
	this.instance_18.setTransform(14.45,24.9,0.5,0.5);

	this.instance_19 = new lib.CachedTexturedBitmap_128();
	this.instance_19.parent = this;
	this.instance_19.setTransform(14.25,24.5,0.5,0.5);

	this.instance_20 = new lib.CachedTexturedBitmap_127();
	this.instance_20.parent = this;
	this.instance_20.setTransform(14,24.1,0.5,0.5);

	this.instance_21 = new lib.CachedTexturedBitmap_126();
	this.instance_21.parent = this;
	this.instance_21.setTransform(13.8,23.7,0.5,0.5);

	this.instance_22 = new lib.CachedTexturedBitmap_125();
	this.instance_22.parent = this;
	this.instance_22.setTransform(13.6,23.3,0.5,0.5);

	this.instance_23 = new lib.CachedTexturedBitmap_124();
	this.instance_23.parent = this;
	this.instance_23.setTransform(13.4,22.9,0.5,0.5);

	this.instance_24 = new lib.CachedTexturedBitmap_123();
	this.instance_24.parent = this;
	this.instance_24.setTransform(13.2,22.5,0.5,0.5);

	this.instance_25 = new lib.CachedTexturedBitmap_122();
	this.instance_25.parent = this;
	this.instance_25.setTransform(13,22.15,0.5,0.5);

	this.instance_26 = new lib.CachedTexturedBitmap_121();
	this.instance_26.parent = this;
	this.instance_26.setTransform(12.8,21.7,0.5,0.5);

	this.instance_27 = new lib.CachedTexturedBitmap_120();
	this.instance_27.parent = this;
	this.instance_27.setTransform(12.6,21.35,0.5,0.5);

	this.instance_28 = new lib.CachedTexturedBitmap_119();
	this.instance_28.parent = this;
	this.instance_28.setTransform(12.4,20.95,0.5,0.5);

	this.instance_29 = new lib.CachedTexturedBitmap_118();
	this.instance_29.parent = this;
	this.instance_29.setTransform(12.2,20.55,0.5,0.5);

	this.instance_30 = new lib.CachedTexturedBitmap_117();
	this.instance_30.parent = this;
	this.instance_30.setTransform(12,20.15,0.5,0.5);

	this.instance_31 = new lib.CachedTexturedBitmap_116();
	this.instance_31.parent = this;
	this.instance_31.setTransform(11.8,19.75,0.5,0.5);

	this.instance_32 = new lib.CachedTexturedBitmap_115();
	this.instance_32.parent = this;
	this.instance_32.setTransform(11.6,19.35,0.5,0.5);

	this.instance_33 = new lib.CachedTexturedBitmap_114();
	this.instance_33.parent = this;
	this.instance_33.setTransform(11.35,18.95,0.5,0.5);

	this.instance_34 = new lib.CachedTexturedBitmap_113();
	this.instance_34.parent = this;
	this.instance_34.setTransform(11.2,18.55,0.5,0.5);

	this.instance_35 = new lib.CachedTexturedBitmap_112();
	this.instance_35.parent = this;
	this.instance_35.setTransform(11,18.15,0.5,0.5);

	this.instance_36 = new lib.CachedTexturedBitmap_111();
	this.instance_36.parent = this;
	this.instance_36.setTransform(10.75,17.75,0.5,0.5);

	this.instance_37 = new lib.CachedTexturedBitmap_110();
	this.instance_37.parent = this;
	this.instance_37.setTransform(10.55,17.4,0.5,0.5);

	this.instance_38 = new lib.CachedTexturedBitmap_109();
	this.instance_38.parent = this;
	this.instance_38.setTransform(10.35,17,0.5,0.5);

	this.instance_39 = new lib.CachedTexturedBitmap_108();
	this.instance_39.parent = this;
	this.instance_39.setTransform(10.15,16.6,0.5,0.5);

	this.instance_40 = new lib.CachedTexturedBitmap_107();
	this.instance_40.parent = this;
	this.instance_40.setTransform(9.95,16.2,0.5,0.5);

	this.instance_41 = new lib.CachedTexturedBitmap_106();
	this.instance_41.parent = this;
	this.instance_41.setTransform(9.75,15.8,0.5,0.5);

	this.instance_42 = new lib.CachedTexturedBitmap_105();
	this.instance_42.parent = this;
	this.instance_42.setTransform(9.55,15.4,0.5,0.5);

	this.instance_43 = new lib.CachedTexturedBitmap_104();
	this.instance_43.parent = this;
	this.instance_43.setTransform(9.35,15,0.5,0.5);

	this.instance_44 = new lib.CachedTexturedBitmap_103();
	this.instance_44.parent = this;
	this.instance_44.setTransform(9.15,14.6,0.5,0.5);

	this.instance_45 = new lib.CachedTexturedBitmap_102();
	this.instance_45.parent = this;
	this.instance_45.setTransform(8.95,14.2,0.5,0.5);

	this.instance_46 = new lib.CachedTexturedBitmap_101();
	this.instance_46.parent = this;
	this.instance_46.setTransform(8.75,13.8,0.5,0.5);

	this.instance_47 = new lib.CachedTexturedBitmap_100();
	this.instance_47.parent = this;
	this.instance_47.setTransform(8.55,13.45,0.5,0.5);

	this.instance_48 = new lib.CachedTexturedBitmap_99();
	this.instance_48.parent = this;
	this.instance_48.setTransform(8.35,13,0.5,0.5);

	this.instance_49 = new lib.CachedTexturedBitmap_98();
	this.instance_49.parent = this;
	this.instance_49.setTransform(8.1,12.65,0.5,0.5);

	this.instance_50 = new lib.CachedTexturedBitmap_97();
	this.instance_50.parent = this;
	this.instance_50.setTransform(7.9,12.25,0.5,0.5);

	this.instance_51 = new lib.CachedTexturedBitmap_96();
	this.instance_51.parent = this;
	this.instance_51.setTransform(7.7,11.85,0.5,0.5);

	this.instance_52 = new lib.CachedTexturedBitmap_95();
	this.instance_52.parent = this;
	this.instance_52.setTransform(7.5,11.45,0.5,0.5);

	this.instance_53 = new lib.CachedTexturedBitmap_94();
	this.instance_53.parent = this;
	this.instance_53.setTransform(7.3,11.05,0.5,0.5);

	this.instance_54 = new lib.CachedTexturedBitmap_93();
	this.instance_54.parent = this;
	this.instance_54.setTransform(7.1,10.65,0.5,0.5);

	this.instance_55 = new lib.CachedTexturedBitmap_92();
	this.instance_55.parent = this;
	this.instance_55.setTransform(6.9,10.25,0.5,0.5);

	this.instance_56 = new lib.CachedTexturedBitmap_91();
	this.instance_56.parent = this;
	this.instance_56.setTransform(6.7,9.85,0.5,0.5);

	this.instance_57 = new lib.CachedTexturedBitmap_90();
	this.instance_57.parent = this;
	this.instance_57.setTransform(6.5,9.45,0.5,0.5);

	this.instance_58 = new lib.CachedTexturedBitmap_89();
	this.instance_58.parent = this;
	this.instance_58.setTransform(6.3,9.05,0.5,0.5);

	this.instance_59 = new lib.CachedTexturedBitmap_88();
	this.instance_59.parent = this;
	this.instance_59.setTransform(6.1,8.7,0.5,0.5);

	this.instance_60 = new lib.CachedTexturedBitmap_87();
	this.instance_60.parent = this;
	this.instance_60.setTransform(5.9,8.3,0.5,0.5);

	this.instance_61 = new lib.CachedTexturedBitmap_86();
	this.instance_61.parent = this;
	this.instance_61.setTransform(5.7,7.9,0.5,0.5);

	this.instance_62 = new lib.CachedTexturedBitmap_85();
	this.instance_62.parent = this;
	this.instance_62.setTransform(5.5,7.5,0.5,0.5);

	this.instance_63 = new lib.CachedTexturedBitmap_84();
	this.instance_63.parent = this;
	this.instance_63.setTransform(5.3,7.1,0.5,0.5);

	this.instance_64 = new lib.CachedTexturedBitmap_83();
	this.instance_64.parent = this;
	this.instance_64.setTransform(5.05,6.7,0.5,0.5);

	this.instance_65 = new lib.CachedTexturedBitmap_82();
	this.instance_65.parent = this;
	this.instance_65.setTransform(4.85,6.3,0.5,0.5);

	this.instance_66 = new lib.CachedTexturedBitmap_81();
	this.instance_66.parent = this;
	this.instance_66.setTransform(4.65,5.9,0.5,0.5);

	this.instance_67 = new lib.CachedTexturedBitmap_80();
	this.instance_67.parent = this;
	this.instance_67.setTransform(4.45,5.5,0.5,0.5);

	this.instance_68 = new lib.CachedTexturedBitmap_79();
	this.instance_68.parent = this;
	this.instance_68.setTransform(4.25,5.1,0.5,0.5);

	this.instance_69 = new lib.CachedTexturedBitmap_78();
	this.instance_69.parent = this;
	this.instance_69.setTransform(4.05,4.75,0.5,0.5);

	this.instance_70 = new lib.CachedTexturedBitmap_78();
	this.instance_70.parent = this;
	this.instance_70.setTransform(4.05,4.75,0.5,0.5);

	this.instance_71 = new lib.CachedTexturedBitmap_78();
	this.instance_71.parent = this;
	this.instance_71.setTransform(4.05,4.75,0.5,0.5);

	this.instance_72 = new lib.CachedTexturedBitmap_75();
	this.instance_72.parent = this;
	this.instance_72.setTransform(3.4,2.85,0.5,0.5);

	this.instance_73 = new lib.CachedTexturedBitmap_74();
	this.instance_73.parent = this;
	this.instance_73.setTransform(2.9,4.25,0.5,0.5);

	this.instance_74 = new lib.CachedTexturedBitmap_73();
	this.instance_74.parent = this;
	this.instance_74.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2_2, new cjs.Rectangle(0,0,50,50), null);


(lib.Symbol1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.iconxeđạp();
	this.instance_1.parent = this;
	this.instance_1.setTransform(6.15,13.8,0.4724,0.4724);

	this.instance_2 = new lib.CachedTexturedBitmap_72();
	this.instance_2.parent = this;
	this.instance_2.setTransform(7.7,5.05,0.5025,0.5025);

	this.instance_3 = new lib.CachedTexturedBitmap_71();
	this.instance_3.parent = this;
	this.instance_3.setTransform(17.4,30.7,0.5025,0.5025);

	this.instance_4 = new lib.CachedTexturedBitmap_70();
	this.instance_4.parent = this;
	this.instance_4.setTransform(17.15,30.3,0.5025,0.5025);

	this.instance_5 = new lib.CachedTexturedBitmap_69();
	this.instance_5.parent = this;
	this.instance_5.setTransform(16.95,29.9,0.5025,0.5025);

	this.instance_6 = new lib.CachedTexturedBitmap_68();
	this.instance_6.parent = this;
	this.instance_6.setTransform(16.75,29.5,0.5025,0.5025);

	this.instance_7 = new lib.CachedTexturedBitmap_67();
	this.instance_7.parent = this;
	this.instance_7.setTransform(16.55,29.1,0.5025,0.5025);

	this.instance_8 = new lib.CachedTexturedBitmap_66();
	this.instance_8.parent = this;
	this.instance_8.setTransform(16.35,28.7,0.5025,0.5025);

	this.instance_9 = new lib.CachedTexturedBitmap_65();
	this.instance_9.parent = this;
	this.instance_9.setTransform(16.15,28.3,0.5025,0.5025);

	this.instance_10 = new lib.CachedTexturedBitmap_64();
	this.instance_10.parent = this;
	this.instance_10.setTransform(15.95,27.9,0.5025,0.5025);

	this.instance_11 = new lib.CachedTexturedBitmap_63();
	this.instance_11.parent = this;
	this.instance_11.setTransform(15.75,27.5,0.5025,0.5025);

	this.instance_12 = new lib.CachedTexturedBitmap_62();
	this.instance_12.parent = this;
	this.instance_12.setTransform(15.55,27.1,0.5025,0.5025);

	this.instance_13 = new lib.CachedTexturedBitmap_61();
	this.instance_13.parent = this;
	this.instance_13.setTransform(15.35,26.75,0.5025,0.5025);

	this.instance_14 = new lib.CachedTexturedBitmap_60();
	this.instance_14.parent = this;
	this.instance_14.setTransform(15.1,26.35,0.5025,0.5025);

	this.instance_15 = new lib.CachedTexturedBitmap_59();
	this.instance_15.parent = this;
	this.instance_15.setTransform(14.9,25.95,0.5025,0.5025);

	this.instance_16 = new lib.CachedTexturedBitmap_58();
	this.instance_16.parent = this;
	this.instance_16.setTransform(14.7,25.55,0.5025,0.5025);

	this.instance_17 = new lib.CachedTexturedBitmap_57();
	this.instance_17.parent = this;
	this.instance_17.setTransform(14.5,25.1,0.5025,0.5025);

	this.instance_18 = new lib.CachedTexturedBitmap_56();
	this.instance_18.parent = this;
	this.instance_18.setTransform(14.3,24.7,0.5025,0.5025);

	this.instance_19 = new lib.CachedTexturedBitmap_55();
	this.instance_19.parent = this;
	this.instance_19.setTransform(14.1,24.3,0.5025,0.5025);

	this.instance_20 = new lib.CachedTexturedBitmap_54();
	this.instance_20.parent = this;
	this.instance_20.setTransform(13.9,23.9,0.5025,0.5025);

	this.instance_21 = new lib.CachedTexturedBitmap_53();
	this.instance_21.parent = this;
	this.instance_21.setTransform(13.7,23.5,0.5025,0.5025);

	this.instance_22 = new lib.CachedTexturedBitmap_52();
	this.instance_22.parent = this;
	this.instance_22.setTransform(13.5,23.15,0.5025,0.5025);

	this.instance_23 = new lib.CachedTexturedBitmap_51();
	this.instance_23.parent = this;
	this.instance_23.setTransform(13.3,22.75,0.5025,0.5025);

	this.instance_24 = new lib.CachedTexturedBitmap_50();
	this.instance_24.parent = this;
	this.instance_24.setTransform(13.05,22.35,0.5025,0.5025);

	this.instance_25 = new lib.CachedTexturedBitmap_49();
	this.instance_25.parent = this;
	this.instance_25.setTransform(12.85,21.95,0.5025,0.5025);

	this.instance_26 = new lib.CachedTexturedBitmap_48();
	this.instance_26.parent = this;
	this.instance_26.setTransform(12.7,21.55,0.5025,0.5025);

	this.instance_27 = new lib.CachedTexturedBitmap_47();
	this.instance_27.parent = this;
	this.instance_27.setTransform(12.45,21.15,0.5025,0.5025);

	this.instance_28 = new lib.CachedTexturedBitmap_46();
	this.instance_28.parent = this;
	this.instance_28.setTransform(12.25,20.75,0.5025,0.5025);

	this.instance_29 = new lib.CachedTexturedBitmap_45();
	this.instance_29.parent = this;
	this.instance_29.setTransform(12.05,20.35,0.5025,0.5025);

	this.instance_30 = new lib.CachedTexturedBitmap_44();
	this.instance_30.parent = this;
	this.instance_30.setTransform(11.85,19.9,0.5025,0.5025);

	this.instance_31 = new lib.CachedTexturedBitmap_43();
	this.instance_31.parent = this;
	this.instance_31.setTransform(11.65,19.55,0.5025,0.5025);

	this.instance_32 = new lib.CachedTexturedBitmap_42();
	this.instance_32.parent = this;
	this.instance_32.setTransform(11.45,19.15,0.5025,0.5025);

	this.instance_33 = new lib.CachedTexturedBitmap_41();
	this.instance_33.parent = this;
	this.instance_33.setTransform(11.25,18.75,0.5025,0.5025);

	this.instance_34 = new lib.CachedTexturedBitmap_40();
	this.instance_34.parent = this;
	this.instance_34.setTransform(11.05,18.35,0.5025,0.5025);

	this.instance_35 = new lib.CachedTexturedBitmap_39();
	this.instance_35.parent = this;
	this.instance_35.setTransform(10.85,17.95,0.5025,0.5025);

	this.instance_36 = new lib.CachedTexturedBitmap_38();
	this.instance_36.parent = this;
	this.instance_36.setTransform(10.65,17.55,0.5025,0.5025);

	this.instance_37 = new lib.CachedTexturedBitmap_37();
	this.instance_37.parent = this;
	this.instance_37.setTransform(10.4,17.15,0.5025,0.5025);

	this.instance_38 = new lib.CachedTexturedBitmap_36();
	this.instance_38.parent = this;
	this.instance_38.setTransform(10.25,16.75,0.5025,0.5025);

	this.instance_39 = new lib.CachedTexturedBitmap_35();
	this.instance_39.parent = this;
	this.instance_39.setTransform(10,16.35,0.5025,0.5025);

	this.instance_40 = new lib.CachedTexturedBitmap_34();
	this.instance_40.parent = this;
	this.instance_40.setTransform(9.8,15.95,0.5025,0.5025);

	this.instance_41 = new lib.CachedTexturedBitmap_33();
	this.instance_41.parent = this;
	this.instance_41.setTransform(9.6,15.55,0.5025,0.5025);

	this.instance_42 = new lib.CachedTexturedBitmap_32();
	this.instance_42.parent = this;
	this.instance_42.setTransform(9.4,15.15,0.5025,0.5025);

	this.instance_43 = new lib.CachedTexturedBitmap_31();
	this.instance_43.parent = this;
	this.instance_43.setTransform(9.2,14.75,0.5025,0.5025);

	this.instance_44 = new lib.CachedTexturedBitmap_30();
	this.instance_44.parent = this;
	this.instance_44.setTransform(9,14.35,0.5025,0.5025);

	this.instance_45 = new lib.CachedTexturedBitmap_29();
	this.instance_45.parent = this;
	this.instance_45.setTransform(8.75,13.95,0.5025,0.5025);

	this.instance_46 = new lib.CachedTexturedBitmap_28();
	this.instance_46.parent = this;
	this.instance_46.setTransform(8.6,13.55,0.5025,0.5025);

	this.instance_47 = new lib.CachedTexturedBitmap_27();
	this.instance_47.parent = this;
	this.instance_47.setTransform(8.4,13.15,0.5025,0.5025);

	this.instance_48 = new lib.CachedTexturedBitmap_26();
	this.instance_48.parent = this;
	this.instance_48.setTransform(8.15,12.75,0.5025,0.5025);

	this.instance_49 = new lib.CachedTexturedBitmap_25();
	this.instance_49.parent = this;
	this.instance_49.setTransform(7.95,12.35,0.5025,0.5025);

	this.instance_50 = new lib.CachedTexturedBitmap_24();
	this.instance_50.parent = this;
	this.instance_50.setTransform(7.75,11.95,0.5025,0.5025);

	this.instance_51 = new lib.CachedTexturedBitmap_23();
	this.instance_51.parent = this;
	this.instance_51.setTransform(7.55,11.55,0.5025,0.5025);

	this.instance_52 = new lib.CachedTexturedBitmap_22();
	this.instance_52.parent = this;
	this.instance_52.setTransform(7.35,11.15,0.5025,0.5025);

	this.instance_53 = new lib.CachedTexturedBitmap_21();
	this.instance_53.parent = this;
	this.instance_53.setTransform(7.15,10.75,0.5025,0.5025);

	this.instance_54 = new lib.CachedTexturedBitmap_20();
	this.instance_54.parent = this;
	this.instance_54.setTransform(6.95,10.4,0.5025,0.5025);

	this.instance_55 = new lib.CachedTexturedBitmap_19();
	this.instance_55.parent = this;
	this.instance_55.setTransform(6.75,9.95,0.5025,0.5025);

	this.instance_56 = new lib.CachedTexturedBitmap_18();
	this.instance_56.parent = this;
	this.instance_56.setTransform(6.55,9.55,0.5025,0.5025);

	this.instance_57 = new lib.CachedTexturedBitmap_17();
	this.instance_57.parent = this;
	this.instance_57.setTransform(6.35,9.15,0.5025,0.5025);

	this.instance_58 = new lib.CachedTexturedBitmap_16();
	this.instance_58.parent = this;
	this.instance_58.setTransform(6.15,8.75,0.5025,0.5025);

	this.instance_59 = new lib.CachedTexturedBitmap_15();
	this.instance_59.parent = this;
	this.instance_59.setTransform(5.95,8.35,0.5025,0.5025);

	this.instance_60 = new lib.CachedTexturedBitmap_14();
	this.instance_60.parent = this;
	this.instance_60.setTransform(5.75,7.95,0.5025,0.5025);

	this.instance_61 = new lib.CachedTexturedBitmap_13();
	this.instance_61.parent = this;
	this.instance_61.setTransform(5.5,7.55,0.5025,0.5025);

	this.instance_62 = new lib.CachedTexturedBitmap_12();
	this.instance_62.parent = this;
	this.instance_62.setTransform(5.35,7.15,0.5025,0.5025);

	this.instance_63 = new lib.CachedTexturedBitmap_11();
	this.instance_63.parent = this;
	this.instance_63.setTransform(5.1,6.8,0.5025,0.5025);

	this.instance_64 = new lib.CachedTexturedBitmap_10();
	this.instance_64.parent = this;
	this.instance_64.setTransform(4.9,6.4,0.5025,0.5025);

	this.instance_65 = new lib.CachedTexturedBitmap_9();
	this.instance_65.parent = this;
	this.instance_65.setTransform(4.7,5.95,0.5025,0.5025);

	this.instance_66 = new lib.CachedTexturedBitmap_8();
	this.instance_66.parent = this;
	this.instance_66.setTransform(4.5,5.6,0.5025,0.5025);

	this.instance_67 = new lib.CachedTexturedBitmap_7();
	this.instance_67.parent = this;
	this.instance_67.setTransform(4.3,5.2,0.5025,0.5025);

	this.instance_68 = new lib.CachedTexturedBitmap_6();
	this.instance_68.parent = this;
	this.instance_68.setTransform(4.05,4.75,0.5025,0.5025);

	this.instance_69 = new lib.CachedTexturedBitmap_6();
	this.instance_69.parent = this;
	this.instance_69.setTransform(4.05,4.75,0.5025,0.5025);

	this.instance_70 = new lib.CachedTexturedBitmap_6();
	this.instance_70.parent = this;
	this.instance_70.setTransform(4.05,4.75,0.5025,0.5025);

	this.instance_71 = new lib.CachedTexturedBitmap_3();
	this.instance_71.parent = this;
	this.instance_71.setTransform(3.4,2.85,0.5025,0.5025);

	this.instance_72 = new lib.CachedTexturedBitmap_2();
	this.instance_72.parent = this;
	this.instance_72.setTransform(2.9,4.25,0.5025,0.5025);

	this.instance_73 = new lib.CachedTexturedBitmap_1();
	this.instance_73.parent = this;
	this.instance_73.setTransform(0,0,0.5025,0.5025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1_1, new cjs.Rectangle(0,0,50.3,50.3), null);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TramChim();
	this.instance.parent = this;
	this.instance.setTransform(-39,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(-39,-10,78,20), null);


(lib.Symbol11_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.TanChau();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-33,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11_1, new cjs.Rectangle(-33,-10,66,20), null);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CaoLanh();
	this.instance.parent = this;
	this.instance.setTransform(-34,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(-34,-10,68,20), null);


(lib.Symbol9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.DraySap();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-32.5,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9_1, new cjs.Rectangle(-32.5,-12,65,24), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BuonDon();
	this.instance.parent = this;
	this.instance.setTransform(-36.5,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-36.5,-9.5,73,19), null);


(lib.Symbol7_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_87 = new lib.Sanamxai();
	this.instance_87.parent = this;
	this.instance_87.setTransform(-36.5,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_87).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7_2, new cjs.Rectangle(-36.5,-9.5,73,19), null);


(lib.Symbol6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Paksong();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-31,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6_1, new cjs.Rectangle(-31,-12.5,62,25), null);


(lib.Symbol5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Sekong();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-27.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5_1, new cjs.Rectangle(-27.5,-12.5,55,25), null);


(lib.Symbol4_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_74 = new lib.YenThuy();
	this.instance_74.parent = this;
	this.instance_74.setTransform(-34.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_74).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4_3, new cjs.Rectangle(-34.5,-12.5,69,25), null);


(lib.Symbol3copy2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.BacKan();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-29,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3copy2_1, new cjs.Rectangle(-29,-9.5,58,19), null);


(lib.Symbol3copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.DinhLap();
	this.instance.parent = this;
	this.instance.setTransform(-32.5,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3copy, new cjs.Rectangle(-32.5,-12.5,65,25), null);


(lib.Symbol2copy_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.Bitmap1copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-35,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy_1, new cjs.Rectangle(-35,-12.5,70,25), null);


(lib.Symbol2_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_75 = new lib.TuLe();
	this.instance_75.parent = this;
	this.instance_75.setTransform(-20,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_75).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2_3, new cjs.Rectangle(-20,-9.5,40,19), null);


(lib.Symbol1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BacQuang();
	this.instance.parent = this;
	this.instance.setTransform(-40,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy, new cjs.Rectangle(-40,-12,80,24), null);


(lib.Symbol1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_74 = new lib.Shape1477();
	this.instance_74.parent = this;
	this.instance_74.setTransform(-2,-45);

	this.instance_75 = new lib.GotFerry();
	this.instance_75.parent = this;
	this.instance_75.setTransform(-34.5,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_75},{t:this.instance_74}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1_2, new cjs.Rectangle(-34.5,-45,69,57), null);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol2copy();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.36,0.36);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19, new cjs.Rectangle(0,0,132.1,132.1), null);


(lib.Symbol18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_614();
	this.instance.parent = this;
	this.instance.setTransform(20.6,18.25,0.5906,0.5906);

	this.instance_1 = new lib.Path_0();
	this.instance_1.parent = this;
	this.instance_1.setTransform(37.6,24.4,1,1,0,0,0,29.8,16.6);

	this.instance_2 = new lib.CachedTexturedBitmap_613();
	this.instance_2.parent = this;
	this.instance_2.setTransform(6.7,6.7,0.5906,0.5906);

	this.instance_3 = new lib.CachedTexturedBitmap_612();
	this.instance_3.parent = this;
	this.instance_3.setTransform(5.7,5.65,0.5906,0.5906);

	this.instance_4 = new lib.CachedTexturedBitmap_611();
	this.instance_4.parent = this;
	this.instance_4.setTransform(5.7,5.65,0.5906,0.5906);

	this.instance_5 = new lib.CachedTexturedBitmap_610();
	this.instance_5.parent = this;
	this.instance_5.setTransform(4.75,4.75,0.5906,0.5906);

	this.instance_6 = new lib.CachedTexturedBitmap_609();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0.95,0.9,0.5906,0.5906);

	this.instance_7 = new lib.CachedTexturedBitmap_608();
	this.instance_7.parent = this;
	this.instance_7.setTransform(0.95,0.9,0.5906,0.5906);

	this.instance_8 = new lib.CachedTexturedBitmap_607();
	this.instance_8.parent = this;
	this.instance_8.setTransform(0.9,0.9,0.5906,0.5906);

	this.instance_9 = new lib.CachedTexturedBitmap_606();
	this.instance_9.parent = this;
	this.instance_9.setTransform(0,0,0.5906,0.5906);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18, new cjs.Rectangle(0,0,75,75), null);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_623();
	this.instance.parent = this;
	this.instance.setTransform(14.6,21.65,0.5906,0.5906);

	this.instance_1 = new lib.Path();
	this.instance_1.parent = this;
	this.instance_1.setTransform(37.6,24.4,1,1,0,0,0,29.8,16.6);

	this.instance_2 = new lib.CachedTexturedBitmap_622();
	this.instance_2.parent = this;
	this.instance_2.setTransform(6.65,6.7,0.5906,0.5906);

	this.instance_3 = new lib.CachedTexturedBitmap_621();
	this.instance_3.parent = this;
	this.instance_3.setTransform(5.65,5.65,0.5906,0.5906);

	this.instance_4 = new lib.CachedTexturedBitmap_620();
	this.instance_4.parent = this;
	this.instance_4.setTransform(5.65,5.65,0.5906,0.5906);

	this.instance_5 = new lib.CachedTexturedBitmap_619();
	this.instance_5.parent = this;
	this.instance_5.setTransform(4.7,4.75,0.5906,0.5906);

	this.instance_6 = new lib.CachedTexturedBitmap_618();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0.9,0.9,0.5906,0.5906);

	this.instance_7 = new lib.CachedTexturedBitmap_617();
	this.instance_7.parent = this;
	this.instance_7.setTransform(0.9,0.9,0.5906,0.5906);

	this.instance_8 = new lib.CachedTexturedBitmap_616();
	this.instance_8.parent = this;
	this.instance_8.setTransform(0.9,0.9,0.5906,0.5906);

	this.instance_9 = new lib.CachedTexturedBitmap_615();
	this.instance_9.parent = this;
	this.instance_9.setTransform(0,0,0.5906,0.5906);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17, new cjs.Rectangle(0,0,75,75), null);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_605();
	this.instance.parent = this;
	this.instance.setTransform(20.35,19.55,0.5701,0.5701);

	this.instance_1 = new lib.Path_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(37.7,24.4,1,1,0,0,0,29.9,16.6);

	this.instance_2 = new lib.CachedTexturedBitmap_604();
	this.instance_2.parent = this;
	this.instance_2.setTransform(6.65,6.65,0.5701,0.5701);

	this.instance_3 = new lib.CachedTexturedBitmap_603();
	this.instance_3.parent = this;
	this.instance_3.setTransform(5.7,5.7,0.5701,0.5701);

	this.instance_4 = new lib.CachedTexturedBitmap_602();
	this.instance_4.parent = this;
	this.instance_4.setTransform(5.7,5.7,0.5701,0.5701);

	this.instance_5 = new lib.CachedTexturedBitmap_601();
	this.instance_5.parent = this;
	this.instance_5.setTransform(4.75,4.75,0.5701,0.5701);

	this.instance_6 = new lib.CachedTexturedBitmap_600();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0.95,0.9,0.5701,0.5701);

	this.instance_7 = new lib.CachedTexturedBitmap_599();
	this.instance_7.parent = this;
	this.instance_7.setTransform(0.95,0.9,0.5701,0.5701);

	this.instance_8 = new lib.CachedTexturedBitmap_598();
	this.instance_8.parent = this;
	this.instance_8.setTransform(0.9,0.9,0.5701,0.5701);

	this.instance_9 = new lib.CachedTexturedBitmap_597();
	this.instance_9.parent = this;
	this.instance_9.setTransform(0,0,0.5701,0.5701);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol16, new cjs.Rectangle(0,0,75.3,75.3), null);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol17();
	this.instance.parent = this;
	this.instance.setTransform(5,5,0.7973,0.7973,0,0,0,37.6,37.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14, new cjs.Rectangle(-25,-25,59.8,59.8), null);


(lib.Symbol8copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.VN_MyLai = new lib.Symbol7();
	this.VN_MyLai.name = "VN_MyLai";
	this.VN_MyLai.parent = this;
	this.VN_MyLai.setTransform(1658.5,1596);

	this.VN_BachMa = new lib.Symbol6();
	this.VN_BachMa.name = "VN_BachMa";
	this.VN_BachMa.parent = this;
	this.VN_BachMa.setTransform(1454.5,1364);

	this.VN_ALuoi = new lib.Symbol5();
	this.VN_ALuoi.name = "VN_ALuoi";
	this.VN_ALuoi.parent = this;
	this.VN_ALuoi.setTransform(1307,1336.5);

	this.VN_TinhBien = new lib.Symbol4();
	this.VN_TinhBien.name = "VN_TinhBien";
	this.VN_TinhBien.parent = this;
	this.VN_TinhBien.setTransform(837.5,2402);

	this.VN_TanAn = new lib.Symbol3();
	this.VN_TanAn.name = "VN_TanAn";
	this.VN_TanAn.parent = this;
	this.VN_TanAn.setTransform(1189.5,2384.5);

	this.VN_CatTien = new lib.Symbol2();
	this.VN_CatTien.name = "VN_CatTien";
	this.VN_CatTien.parent = this;
	this.VN_CatTien.setTransform(1344,2192.5);

	this.VN_BinhChau = new lib.Symbol1();
	this.VN_BinhChau.name = "VN_BinhChau";
	this.VN_BinhChau.parent = this;
	this.VN_BinhChau.setTransform(1389.5,2376.3);

	this.VN_BacKan = new lib.Symbol3copy2_1();
	this.VN_BacKan.name = "VN_BacKan";
	this.VN_BacKan.parent = this;
	this.VN_BacKan.setTransform(1100,270.5);

	this.VN_PhoRang = new lib.Symbol2copy_1();
	this.VN_PhoRang.name = "VN_PhoRang";
	this.VN_PhoRang.parent = this;
	this.VN_PhoRang.setTransform(867,274.5);

	this.VN_BacQuang = new lib.Symbol1copy();
	this.VN_BacQuang.name = "VN_BacQuang";
	this.VN_BacQuang.parent = this;
	this.VN_BacQuang.setTransform(926.4,236);

	this.VN_TramChim = new lib.Symbol12();
	this.VN_TramChim.name = "VN_TramChim";
	this.VN_TramChim.parent = this;
	this.VN_TramChim.setTransform(1037,2361);

	this.VN_TanChau = new lib.Symbol11_1();
	this.VN_TanChau.name = "VN_TanChau";
	this.VN_TanChau.parent = this;
	this.VN_TanChau.setTransform(956,2343);

	this.VN_CaoLanh = new lib.Symbol10();
	this.VN_CaoLanh.name = "VN_CaoLanh";
	this.VN_CaoLanh.parent = this;
	this.VN_CaoLanh.setTransform(1042,2391);

	this.VN_DraySap = new lib.Symbol9_1();
	this.VN_DraySap.name = "VN_DraySap";
	this.VN_DraySap.parent = this;
	this.VN_DraySap.setTransform(1413.5,1991);

	this.VN_BuonDon = new lib.Symbol8();
	this.VN_BuonDon.name = "VN_BuonDon";
	this.VN_BuonDon.parent = this;
	this.VN_BuonDon.setTransform(1405.5,1945.5);

	this.LA_Sanamxai = new lib.Symbol7_2();
	this.LA_Sanamxai.name = "LA_Sanamxai";
	this.LA_Sanamxai.parent = this;
	this.LA_Sanamxai.setTransform(1186.5,1637.5);

	this.LA_Paksong = new lib.Symbol6_1();
	this.LA_Paksong.name = "LA_Paksong";
	this.LA_Paksong.parent = this;
	this.LA_Paksong.setTransform(1150,1441.5);

	this.LA_Sekong = new lib.Symbol5_1();
	this.LA_Sekong.name = "LA_Sekong";
	this.LA_Sekong.parent = this;
	this.LA_Sekong.setTransform(1273.5,1426.5);

	this.VN_YenThuy = new lib.Symbol4_3();
	this.VN_YenThuy.name = "VN_YenThuy";
	this.VN_YenThuy.parent = this;
	this.VN_YenThuy.setTransform(1027.5,619.5);

	this.VN_DinhLap = new lib.Symbol3copy();
	this.VN_DinhLap.name = "VN_DinhLap";
	this.VN_DinhLap.parent = this;
	this.VN_DinhLap.setTransform(1316.5,372.5);

	this.VN_TuLe = new lib.Symbol2_3();
	this.VN_TuLe.name = "VN_TuLe";
	this.VN_TuLe.parent = this;
	this.VN_TuLe.setTransform(828,385.5);

	this.VN_GotFerry = new lib.Symbol1_2();
	this.VN_GotFerry.name = "VN_GotFerry";
	this.VN_GotFerry.parent = this;
	this.VN_GotFerry.setTransform(1256.5,592);

	this.LA_PakBeng = new lib.Symbol2copy4();
	this.LA_PakBeng.name = "LA_PakBeng";
	this.LA_PakBeng.parent = this;
	this.LA_PakBeng.setTransform(145.5,647.5);

	this.VN_XuanMai = new lib.Symbol1copy6();
	this.VN_XuanMai.name = "VN_XuanMai";
	this.VN_XuanMai.parent = this;
	this.VN_XuanMai.setTransform(1066.4,524);

	this.LA_Oudomxai = new lib.Symbol123();
	this.LA_Oudomxai.name = "LA_Oudomxai";
	this.LA_Oudomxai.parent = this;
	this.LA_Oudomxai.setTransform(329.5,585.5);

	this.VN_DuGia = new lib.Symbol122();
	this.VN_DuGia.name = "VN_DuGia";
	this.VN_DuGia.parent = this;
	this.VN_DuGia.setTransform(976,140);

	this.VN_PhuQuoc = new lib.Symbol68();
	this.VN_PhuQuoc.name = "VN_PhuQuoc";
	this.VN_PhuQuoc.parent = this;
	this.VN_PhuQuoc.setTransform(660.9,2551);

	this.KH_Takeo = new lib.Symbol67();
	this.KH_Takeo.name = "KH_Takeo";
	this.KH_Takeo.parent = this;
	this.KH_Takeo.setTransform(844,2293.5);

	this.VN_ChauDoc = new lib.Symbol66();
	this.VN_ChauDoc.name = "VN_ChauDoc";
	this.VN_ChauDoc.parent = this;
	this.VN_ChauDoc.setTransform(844.5,2370.8);

	this.VN_TruongSa = new lib.Symbol65();
	this.VN_TruongSa.name = "VN_TruongSa";
	this.VN_TruongSa.parent = this;
	this.VN_TruongSa.setTransform(1836.5,2629.5);

	this.VN_ConDao = new lib.Symbol64();
	this.VN_ConDao.name = "VN_ConDao";
	this.VN_ConDao.parent = this;
	this.VN_ConDao.setTransform(1340.5,2703.5);

	this.VN_CaMau = new lib.Symbol63();
	this.VN_CaMau.name = "VN_CaMau";
	this.VN_CaMau.parent = this;
	this.VN_CaMau.setTransform(902.5,2699.5);

	this.VN_RachGia = new lib.Symbol62();
	this.VN_RachGia.name = "VN_RachGia";
	this.VN_RachGia.parent = this;
	this.VN_RachGia.setTransform(862,2500.5);

	this.VN_TraSu = new lib.Symbol61();
	this.VN_TraSu.name = "VN_TraSu";
	this.VN_TraSu.parent = this;
	this.VN_TraSu.setTransform(924.5,2430.5);

	this.VN_HaTien = new lib.Symbol60();
	this.VN_HaTien.name = "VN_HaTien";
	this.VN_HaTien.parent = this;
	this.VN_HaTien.setTransform(806.5,2457);

	this.VN_BangLang = new lib.Symbol59();
	this.VN_BangLang.name = "VN_BangLang";
	this.VN_BangLang.parent = this;
	this.VN_BangLang.setTransform(1001,2493);

	this.VN_CanTho = new lib.Symbol58();
	this.VN_CanTho.name = "VN_CanTho";
	this.VN_CanTho.parent = this;
	this.VN_CanTho.setTransform(1025,2539.5);

	this.VN_BacLieu = new lib.Symbol57();
	this.VN_BacLieu.name = "VN_BacLieu";
	this.VN_BacLieu.parent = this;
	this.VN_BacLieu.setTransform(1005.4,2676);

	this.VN_SocTrang = new lib.Symbol56();
	this.VN_SocTrang.name = "VN_SocTrang";
	this.VN_SocTrang.parent = this;
	this.VN_SocTrang.setTransform(1119.5,2607);

	this.VN_TraVinh = new lib.Symbol55();
	this.VN_TraVinh.name = "VN_TraVinh";
	this.VN_TraVinh.parent = this;
	this.VN_TraVinh.setTransform(1145,2546.5);

	this.VN_VinhLong = new lib.Symbol54();
	this.VN_VinhLong.name = "VN_VinhLong";
	this.VN_VinhLong.parent = this;
	this.VN_VinhLong.setTransform(1101.5,2500);

	this.VN_CaiBe = new lib.Symbol53();
	this.VN_CaiBe.name = "VN_CaiBe";
	this.VN_CaiBe.parent = this;
	this.VN_CaiBe.setTransform(1130.5,2440);

	this.VN_BenTre = new lib.Symbol52();
	this.VN_BenTre.name = "VN_BenTre";
	this.VN_BenTre.parent = this;
	this.VN_BenTre.setTransform(1208,2488.5);

	this.VN_VungTau = new lib.Symbol51();
	this.VN_VungTau.name = "VN_VungTau";
	this.VN_VungTau.parent = this;
	this.VN_VungTau.setTransform(1379.5,2427);

	this.VN_MyTho = new lib.Symbol50();
	this.VN_MyTho.name = "VN_MyTho";
	this.VN_MyTho.parent = this;
	this.VN_MyTho.setTransform(1228.5,2435);

	this.VN_CaiLay = new lib.Symbol49copy();
	this.VN_CaiLay.name = "VN_CaiLay";
	this.VN_CaiLay.parent = this;
	this.VN_CaiLay.setTransform(1121.5,2395.5);

	this.VN_SaDec = new lib.Symbol48copy();
	this.VN_SaDec.name = "VN_SaDec";
	this.VN_SaDec.parent = this;
	this.VN_SaDec.setTransform(1058,2472.5);

	this.VN_LongXuyen = new lib.Symbol47copy();
	this.VN_LongXuyen.name = "VN_LongXuyen";
	this.VN_LongXuyen.parent = this;
	this.VN_LongXuyen.setTransform(984,2404);

	this.VN_MocBai = new lib.Symbol46copy();
	this.VN_MocBai.name = "VN_MocBai";
	this.VN_MocBai.parent = this;
	this.VN_MocBai.setTransform(1082,2289);

	this.VN_CuChi = new lib.Symbol45copy();
	this.VN_CuChi.name = "VN_CuChi";
	this.VN_CuChi.parent = this;
	this.VN_CuChi.setTransform(1210.5,2294.5);

	this.VN_HoChiMinhCity = new lib.Symbol44copy();
	this.VN_HoChiMinhCity.name = "VN_HoChiMinhCity";
	this.VN_HoChiMinhCity.parent = this;
	this.VN_HoChiMinhCity.setTransform(1248,2346.3);

	this.VN_TayNinh = new lib.Symbol43copy();
	this.VN_TayNinh.name = "VN_TayNinh";
	this.VN_TayNinh.parent = this;
	this.VN_TayNinh.setTransform(1133.5,2222.5);

	this.VN_DongXoai = new lib.Symbol42copy();
	this.VN_DongXoai.name = "VN_DongXoai";
	this.VN_DongXoai.parent = this;
	this.VN_DongXoai.setTransform(1271,2216.5);

	this.VN_DongNai = new lib.Symbol41copy();
	this.VN_DongNai.name = "VN_DongNai";
	this.VN_DongNai.parent = this;
	this.VN_DongNai.setTransform(1378.5,2300.5);

	this.VN_BaoLoc = new lib.Symbol40copy();
	this.VN_BaoLoc.name = "VN_BaoLoc";
	this.VN_BaoLoc.parent = this;
	this.VN_BaoLoc.setTransform(1460,2201.5);

	this.VN_GiaNghia = new lib.Symbol39copy();
	this.VN_GiaNghia.name = "VN_GiaNghia";
	this.VN_GiaNghia.parent = this;
	this.VN_GiaNghia.setTransform(1400,2131);

	this.VN_PhanThiet = new lib.Symbol38copy();
	this.VN_PhanThiet.name = "VN_PhanThiet";
	this.VN_PhanThiet.parent = this;
	this.VN_PhanThiet.setTransform(1566.5,2331.5);

	this.VN_MuiNe = new lib.Symbol37copy();
	this.VN_MuiNe.name = "VN_MuiNe";
	this.VN_MuiNe.parent = this;
	this.VN_MuiNe.setTransform(1649.45,2299);

	this.VN_NinhGia = new lib.Symbol36copy();
	this.VN_NinhGia.name = "VN_NinhGia";
	this.VN_NinhGia.parent = this;
	this.VN_NinhGia.setTransform(1567.5,2185.5);

	this.VN_DaLat = new lib.Symbol35copy();
	this.VN_DaLat.name = "VN_DaLat";
	this.VN_DaLat.parent = this;
	this.VN_DaLat.setTransform(1533.5,2088.5);

	this.VN_LacLake = new lib.Symbol34copy();
	this.VN_LacLake.name = "VN_LacLake";
	this.VN_LacLake.parent = this;
	this.VN_LacLake.setTransform(1519,1982.5);

	this.VN_BuonMeThuot = new lib.Symbol33copy();
	this.VN_BuonMeThuot.name = "VN_BuonMeThuot";
	this.VN_BuonMeThuot.parent = this;
	this.VN_BuonMeThuot.setTransform(1542,1941.5);

	this.VN_Pleiku = new lib.Symbol32copy();
	this.VN_Pleiku.name = "VN_Pleiku";
	this.VN_Pleiku.parent = this;
	this.VN_Pleiku.setTransform(1415.5,1804.5);

	this.VN_BoY = new lib.Symbol31copy();
	this.VN_BoY.name = "VN_BoY";
	this.VN_BoY.parent = this;
	this.VN_BoY.setTransform(1388,1712.5);

	this.VN_BuonHo = new lib.Symbol30copy();
	this.VN_BuonHo.name = "VN_BuonHo";
	this.VN_BuonHo.parent = this;
	this.VN_BuonHo.setTransform(1525.5,1890.5);

	this.VN_KonTum = new lib.Symbol29copy();
	this.VN_KonTum.name = "VN_KonTum";
	this.VN_KonTum.parent = this;
	this.VN_KonTum.setTransform(1502,1763.5);

	this.VN_PhanRang = new lib.Symbol28copy();
	this.VN_PhanRang.name = "VN_PhanRang";
	this.VN_PhanRang.parent = this;
	this.VN_PhanRang.setTransform(1725.5,2206);

	this.VN_BinhBa = new lib.Symbol27copy();
	this.VN_BinhBa.name = "VN_BinhBa";
	this.VN_BinhBa.parent = this;
	this.VN_BinhBa.setTransform(1787,2047.5);

	this.VN_NhaTrang = new lib.Symbol26copy();
	this.VN_NhaTrang.name = "VN_NhaTrang";
	this.VN_NhaTrang.parent = this;
	this.VN_NhaTrang.setTransform(1785.5,1991);

	this.VN_TuyHoa = new lib.Symbol25copy();
	this.VN_TuyHoa.name = "VN_TuyHoa";
	this.VN_TuyHoa.parent = this;
	this.VN_TuyHoa.setTransform(1761.5,1861);

	this.VN_QuyNhon = new lib.Symbol24copy();
	this.VN_QuyNhon.name = "VN_QuyNhon";
	this.VN_QuyNhon.parent = this;
	this.VN_QuyNhon.setTransform(1758.5,1819);

	this.VN_HoangSa = new lib.Symbol23copy();
	this.VN_HoangSa.name = "VN_HoangSa";
	this.VN_HoangSa.parent = this;
	this.VN_HoangSa.setTransform(1887.5,1285.5);

	this.VN_PhuocSon = new lib.Symbol22copy();
	this.VN_PhuocSon.name = "VN_PhuocSon";
	this.VN_PhuocSon.parent = this;
	this.VN_PhuocSon.setTransform(1436,1554.5);

	this.VN_SonHa = new lib.Symbol21copy();
	this.VN_SonHa.name = "VN_SonHa";
	this.VN_SonHa.parent = this;
	this.VN_SonHa.setTransform(1528,1679.5);

	this.VN_QuangNgai = new lib.Symbol20copy();
	this.VN_QuangNgai.name = "VN_QuangNgai";
	this.VN_QuangNgai.parent = this;
	this.VN_QuangNgai.setTransform(1720,1636.5);

	this.VN_LySon = new lib.Symbol19copy2();
	this.VN_LySon.name = "VN_LySon";
	this.VN_LySon.parent = this;
	this.VN_LySon.setTransform(1747.5,1566);

	this.VN_CuLaoCham = new lib.Symbol18copy2();
	this.VN_CuLaoCham.name = "VN_CuLaoCham";
	this.VN_CuLaoCham.parent = this;
	this.VN_CuLaoCham.setTransform(1718,1426);

	this.VN_NamGiang = new lib.Symbol16copy2();
	this.VN_NamGiang.name = "VN_NamGiang";
	this.VN_NamGiang.parent = this;
	this.VN_NamGiang.setTransform(1375,1488.5);

	this.VN_DongGiang = new lib.Symbol15copy2();
	this.VN_DongGiang.name = "VN_DongGiang";
	this.VN_DongGiang.parent = this;
	this.VN_DongGiang.setTransform(1415.5,1430.5);

	this.VN_ARoang = new lib.Symbol14copy2();
	this.VN_ARoang.name = "VN_ARoang";
	this.VN_ARoang.parent = this;
	this.VN_ARoang.setTransform(1383,1380);

	this.VN_HoiAn = new lib.Symbol13copy2();
	this.VN_HoiAn.name = "VN_HoiAn";
	this.VN_HoiAn.parent = this;
	this.VN_HoiAn.setTransform(1581.45,1433);

	this.VN_DaNang = new lib.Symbol12copy2();
	this.VN_DaNang.name = "VN_DaNang";
	this.VN_DaNang.parent = this;
	this.VN_DaNang.setTransform(1561,1393);

	this.VN_MySon = new lib.Symbol11copy2();
	this.VN_MySon.name = "VN_MySon";
	this.VN_MySon.parent = this;
	this.VN_MySon.setTransform(1461.5,1481);

	this.VN_KheXanh = new lib.Symbol10copy2();
	this.VN_KheXanh.name = "VN_KheXanh";
	this.VN_KheXanh.parent = this;
	this.VN_KheXanh.setTransform(1251,1270.5);

	this.VN_PhongNha = new lib.Symbol9copy2();
	this.VN_PhongNha.name = "VN_PhongNha";
	this.VN_PhongNha.parent = this;
	this.VN_PhongNha.setTransform(1092,1115);

	this.VN_CauTreo = new lib.Symbol8copy3();
	this.VN_CauTreo.name = "VN_CauTreo";
	this.VN_CauTreo.parent = this;
	this.VN_CauTreo.setTransform(933,951.5);

	this.VN_Hue = new lib.Symbol7copy4();
	this.VN_Hue.name = "VN_Hue";
	this.VN_Hue.parent = this;
	this.VN_Hue.setTransform(1418,1321.5);

	this.VN_QuangTri = new lib.Symbol6copy3();
	this.VN_QuangTri.name = "VN_QuangTri";
	this.VN_QuangTri.parent = this;
	this.VN_QuangTri.setTransform(1391.5,1268.5);

	this.VN_VinhMocTunnels = new lib.Symbol5copy3();
	this.VN_VinhMocTunnels.name = "VN_VinhMocTunnels";
	this.VN_VinhMocTunnels.parent = this;
	this.VN_VinhMocTunnels.setTransform(1411,1209.5);

	this.VN_DongHoi = new lib.Symbol4copy4();
	this.VN_DongHoi.name = "VN_DongHoi";
	this.VN_DongHoi.parent = this;
	this.VN_DongHoi.setTransform(1277.5,1144);

	this.VN_HaTinh = new lib.Symbol3copy3();
	this.VN_HaTinh.name = "VN_HaTinh";
	this.VN_HaTinh.parent = this;
	this.VN_HaTinh.setTransform(1053,996.5);

	this.VN_Vinh = new lib.Symbol2copy3();
	this.VN_Vinh.name = "VN_Vinh";
	this.VN_Vinh.parent = this;
	this.VN_Vinh.setTransform(1006.5,919);

	this.VN_ThacBa = new lib.Symbol49();
	this.VN_ThacBa.name = "VN_ThacBa";
	this.VN_ThacBa.parent = this;
	this.VN_ThacBa.setTransform(952.9,389);

	this.VN_TayTrang = new lib.Symbol48();
	this.VN_TayTrang.name = "VN_TayTrang";
	this.VN_TayTrang.parent = this;
	this.VN_TayTrang.setTransform(567,463);

	this.VN_ThaiNguyen = new lib.Symbol47();
	this.VN_ThaiNguyen.name = "VN_ThaiNguyen";
	this.VN_ThaiNguyen.parent = this;
	this.VN_ThaiNguyen.setTransform(1095.5,392.5);

	this.VN_YenMinh = new lib.Symbol45();
	this.VN_YenMinh.name = "VN_YenMinh";
	this.VN_YenMinh.parent = this;
	this.VN_YenMinh.setTransform(893.4,65);

	this.VN_XinMan = new lib.Symbol44();
	this.VN_XinMan.name = "VN_XinMan";
	this.VN_XinMan.parent = this;
	this.VN_XinMan.setTransform(818.4,141.5);

	this.VN_VinhPhuc = new lib.Symbol43();
	this.VN_VinhPhuc.name = "VN_VinhPhuc";
	this.VN_VinhPhuc.parent = this;
	this.VN_VinhPhuc.setTransform(1017.9,421);

	this.VN_TuyenQuang = new lib.Symbol42();
	this.VN_TuyenQuang.name = "VN_TuyenQuang";
	this.VN_TuyenQuang.parent = this;
	this.VN_TuyenQuang.setTransform(1038,349);

	this.VN_TuanGiao = new lib.Symbol41();
	this.VN_TuanGiao.name = "VN_TuanGiao";
	this.VN_TuanGiao.parent = this;
	this.VN_TuanGiao.setTransform(593,327);

	this.VN_TienYen = new lib.Symbol40();
	this.VN_TienYen.name = "VN_TienYen";
	this.VN_TienYen.parent = this;
	this.VN_TienYen.setTransform(1325.5,426);

	this.VN_ThatKhe = new lib.Symbol39();
	this.VN_ThatKhe.name = "VN_ThatKhe";
	this.VN_ThatKhe.parent = this;
	this.VN_ThatKhe.setTransform(1248,273.5);

	this.VN_ThanhHoa = new lib.Symbol38();
	this.VN_ThanhHoa.name = "VN_ThanhHoa";
	this.VN_ThanhHoa.parent = this;
	this.VN_ThanhHoa.setTransform(1086.9,765.5);

	this.VN_ThanUyen = new lib.Symbol37();
	this.VN_ThanUyen.name = "VN_ThanUyen";
	this.VN_ThanUyen.parent = this;
	this.VN_ThanUyen.setTransform(759.4,319);

	this.VN_DongKhe = new lib.VN_DongKhe();
	this.VN_DongKhe.name = "VN_DongKhe";
	this.VN_DongKhe.parent = this;
	this.VN_DongKhe.setTransform(1238,229.5);

	this.VN_DienBienPhu = new lib.VN_DienBienPhu();
	this.VN_DienBienPhu.name = "VN_DienBienPhu";
	this.VN_DienBienPhu.parent = this;
	this.VN_DienBienPhu.setTransform(596,406.5);

	this.VN_CocLy = new lib.VN_CocLy();
	this.VN_CocLy.name = "VN_CocLy";
	this.VN_CocLy.parent = this;
	this.VN_CocLy.setTransform(694.4,109);

	this.VN_CatBa = new lib.VN_CatBa();
	this.VN_CatBa.name = "VN_CatBa";
	this.VN_CatBa.parent = this;
	this.VN_CatBa.setTransform(1332.4,551.5);

	this.VN_CaoSon = new lib.VN_CaoSon();
	this.VN_CaoSon.name = "VN_CaoSon";
	this.VN_CaoSon.parent = this;
	this.VN_CaoSon.setTransform(544.5,110);

	this.VN_CaoBang = new lib.VN_CaoBang();
	this.VN_CaoBang.name = "VN_CaoBang";
	this.VN_CaoBang.parent = this;
	this.VN_CaoBang.setTransform(1229.4,84.5);

	this.VN_CanCau = new lib.VN_CanCau();
	this.VN_CanCau.name = "VN_CanCau";
	this.VN_CanCau.parent = this;
	this.VN_CanCau.setTransform(690,72);

	this.VN_BinhLu = new lib.VN_BinhLu();
	this.VN_BinhLu.name = "VN_BinhLu";
	this.VN_BinhLu.parent = this;
	this.VN_BinhLu.setTransform(655.9,284.5);

	this.VN_BaoLac = new lib.VN_BaoLac();
	this.VN_BaoLac.name = "VN_BaoLac";
	this.VN_BaoLac.parent = this;
	this.VN_BaoLac.setTransform(1070.5,134.5);

	this.VN_BanGioc = new lib.VN_BanGioc();
	this.VN_BanGioc.name = "VN_BanGioc";
	this.VN_BanGioc.parent = this;
	this.VN_BanGioc.setTransform(1285.9,151);

	this.VN_BacSon = new lib.VN_BacSon();
	this.VN_BacSon.name = "VN_BacSon";
	this.VN_BacSon.parent = this;
	this.VN_BacSon.setTransform(1132,327.5);

	this.VN_BacNinh = new lib.VN_BacNinh();
	this.VN_BacNinh.name = "VN_BacNinh";
	this.VN_BacNinh.parent = this;
	this.VN_BacNinh.setTransform(1138,475.5);

	this.VN_BacMe = new lib.VN_BacMe();
	this.VN_BacMe.name = "VN_BacMe";
	this.VN_BacMe.parent = this;
	this.VN_BacMe.setTransform(968.4,210.5);

	this.VN_BacHa = new lib.VN_BacHa();
	this.VN_BacHa.name = "VN_BacHa";
	this.VN_BacHa.parent = this;
	this.VN_BacHa.setTransform(799,243);

	this.VN_BacGiang = new lib.VN_BacGiang();
	this.VN_BacGiang.name = "VN_BacGiang";
	this.VN_BacGiang.parent = this;
	this.VN_BacGiang.setTransform(1159.5,452.5);

	this.VN_BaKhe = new lib.VN_BaKhe();
	this.VN_BaKhe.name = "VN_BaKhe";
	this.VN_BaKhe.parent = this;
	this.VN_BaKhe.setTransform(921.5,443.5);

	this.VN_ThaiBinh = new lib.Symbol36();
	this.VN_ThaiBinh.name = "VN_ThaiBinh";
	this.VN_ThaiBinh.parent = this;
	this.VN_ThaiBinh.setTransform(1244,635.5);

	this.VN_TanTrao = new lib.Symbol35();
	this.VN_TanTrao.name = "VN_TanTrao";
	this.VN_TanTrao.parent = this;
	this.VN_TanTrao.setTransform(1035.5,288.5);

	this.VN_SonLa = new lib.Symbol33();
	this.VN_SonLa.name = "VN_SonLa";
	this.VN_SonLa.parent = this;
	this.VN_SonLa.setTransform(721,487);

	this.VN_SinHo = new lib.Symbol31();
	this.VN_SinHo.name = "VN_SinHo";
	this.VN_SinHo.parent = this;
	this.VN_SinHo.setTransform(520,256);

	this.VN_SinCheng = new lib.Symbol30();
	this.VN_SinCheng.name = "VN_SinCheng";
	this.VN_SinCheng.parent = this;
	this.VN_SinCheng.setTransform(717.5,34);

	this.VN_Sapa = new lib.Symbol29();
	this.VN_Sapa.name = "VN_Sapa";
	this.VN_Sapa.parent = this;
	this.VN_Sapa.setTransform(714.4,255.5);

	this.VN_QuangUyen = new lib.Symbol28();
	this.VN_QuangUyen.name = "VN_QuangUyen";
	this.VN_QuangUyen.parent = this;
	this.VN_QuangUyen.setTransform(1258,196);

	this.VN_QuanBa = new lib.Symbol27();
	this.VN_QuanBa.name = "VN_QuanBa";
	this.VN_QuanBa.parent = this;
	this.VN_QuanBa.setTransform(829.5,49);

	this.VN_NghiaLo = new lib.Symbol26();
	this.VN_NghiaLo.name = "VN_NghiaLo";
	this.VN_NghiaLo.parent = this;
	this.VN_NghiaLo.setTransform(797,424);

	this.VN_PuLuong = new lib.Symbol25();
	this.VN_PuLuong.name = "VN_PuLuong";
	this.VN_PuLuong.parent = this;
	this.VN_PuLuong.setTransform(926,638.5);

	this.VN_NinhBinh = new lib.Symbol24();
	this.VN_NinhBinh.name = "VN_NinhBinh";
	this.VN_NinhBinh.parent = this;
	this.VN_NinhBinh.setTransform(1173,692);

	this.VN_PhuYen = new lib.Symbol23();
	this.VN_PhuYen.name = "VN_PhuYen";
	this.VN_PhuYen.parent = this;
	this.VN_PhuYen.setTransform(855.5,470.5);

	this.VN_PhongTho = new lib.Symbol22();
	this.VN_PhongTho.name = "VN_PhongTho";
	this.VN_PhongTho.parent = this;
	this.VN_PhongTho.setTransform(533.5,183);

	this.VN_NamDinh = new lib.Symbol21();
	this.VN_NamDinh.name = "VN_NamDinh";
	this.VN_NamDinh.parent = this;
	this.VN_NamDinh.setTransform(1223,659.5);

	this.VN_MuongLay = new lib.Symbol20();
	this.VN_MuongLay.name = "VN_MuongLay";
	this.VN_MuongLay.parent = this;
	this.VN_MuongLay.setTransform(470.5,306);

	this.VN_MuongHum = new lib.Symbol19copy();
	this.VN_MuongHum.name = "VN_MuongHum";
	this.VN_MuongHum.parent = this;
	this.VN_MuongHum.setTransform(556.5,150.5);

	this.VN_MongCai = new lib.Symbol18copy();
	this.VN_MongCai.name = "VN_MongCai";
	this.VN_MongCai.parent = this;
	this.VN_MongCai.setTransform(1485,423.5);

	this.VN_MocChau = new lib.Symbol17copy();
	this.VN_MocChau.name = "VN_MocChau";
	this.VN_MocChau.parent = this;
	this.VN_MocChau.setTransform(855,506.5);

	this.VN_MeoVac = new lib.Symbol16copy();
	this.VN_MeoVac.name = "VN_MeoVac";
	this.VN_MeoVac.parent = this;
	this.VN_MeoVac.setTransform(1039.5,101);

	this.VN_MaiChau = new lib.Symbol15copy();
	this.VN_MaiChau.name = "VN_MaiChau";
	this.VN_MaiChau.parent = this;
	this.VN_MaiChau.setTransform(874,566.5);

	this.VN_MuCangChai = new lib.VN_MuCangChai();
	this.VN_MuCangChai.name = "VN_MuCangChai";
	this.VN_MuCangChai.parent = this;
	this.VN_MuCangChai.setTransform(842,361);

	this.VN_LungCu = new lib.Symbol14copy();
	this.VN_LungCu.name = "VN_LungCu";
	this.VN_LungCu.parent = this;
	this.VN_LungCu.setTransform(952.4,19);

	this.VN_LaoCai = new lib.Symbol13copy();
	this.VN_LaoCai.name = "VN_LaoCai";
	this.VN_LaoCai.parent = this;
	this.VN_LaoCai.setTransform(607,167);

	this.VN_LangSon = new lib.Symbol12copy();
	this.VN_LangSon.name = "VN_LangSon";
	this.VN_LangSon.parent = this;
	this.VN_LangSon.setTransform(1279,323);

	this.VN_LaiChau = new lib.Symbol11copy();
	this.VN_LaiChau.name = "VN_LaiChau";
	this.VN_LaiChau.parent = this;
	this.VN_LaiChau.setTransform(536,218);

	this.VN_LungKhauNhin = new lib.Symbol10copy();
	this.VN_LungKhauNhin.name = "VN_LungKhauNhin";
	this.VN_LungKhauNhin.parent = this;
	this.VN_LungKhauNhin.setTransform(557.5,73.5);

	this.VN_HoaBinh = new lib.Symbol9copy();
	this.VN_HoaBinh.name = "VN_HoaBinh";
	this.VN_HoaBinh.parent = this;
	this.VN_HoaBinh.setTransform(1017,566);

	this.VN_HaNoi = new lib.Symbol8copy2();
	this.VN_HaNoi.name = "VN_HaNoi";
	this.VN_HaNoi.parent = this;
	this.VN_HaNoi.setTransform(1030,453.5);

	this.VN_HaiPhong = new lib.Symbol7copy3();
	this.VN_HaiPhong.name = "VN_HaiPhong";
	this.VN_HaiPhong.parent = this;
	this.VN_HaiPhong.setTransform(1188,535);

	this.VN_HaLong = new lib.Symbol6copy2();
	this.VN_HaLong.name = "VN_HaLong";
	this.VN_HaLong.parent = this;
	this.VN_HaLong.setTransform(1314,503.5);

	this.VN_HaGiang = new lib.Symbol5copy2();
	this.VN_HaGiang.name = "VN_HaGiang";
	this.VN_HaGiang.parent = this;
	this.VN_HaGiang.setTransform(938.5,166.5);

	this.VN_HoangSuPhi = new lib.Symbol4copy3();
	this.VN_HoangSuPhi.name = "VN_HoangSuPhi";
	this.VN_HoangSuPhi.parent = this;
	this.VN_HoangSuPhi.setTransform(814,197);

	this.VN_DuongLam = new lib.Symbol3copy2();
	this.VN_DuongLam.name = "VN_DuongLam";
	this.VN_DuongLam.parent = this;
	this.VN_DuongLam.setTransform(978.5,491);

	this.VN_DongVan = new lib.Symbol2copy2();
	this.VN_DongVan.name = "VN_DongVan";
	this.VN_DongVan.parent = this;
	this.VN_DongVan.setTransform(1062,45);

	this.VN_BaBe = new lib.Symbol1copy3();
	this.VN_BaBe.name = "VN_BaBe";
	this.VN_BaBe.parent = this;
	this.VN_BaBe.setTransform(1076.5,234.5,1,1,0,0,0,29.5,12.5);

	this.KH_Sihanoukville = new lib.Symbol120();
	this.KH_Sihanoukville.name = "KH_Sihanoukville";
	this.KH_Sihanoukville.parent = this;
	this.KH_Sihanoukville.setTransform(546.4,2384.8);

	this.KH_Kep = new lib.Symbol119();
	this.KH_Kep.name = "KH_Kep";
	this.KH_Kep.parent = this;
	this.KH_Kep.setTransform(726.5,2460);

	this.KH_Kampot = new lib.Symbol118();
	this.KH_Kampot.name = "KH_Kampot";
	this.KH_Kampot.parent = this;
	this.KH_Kampot.setTransform(591.5,2455);

	this.KH_TonleSap = new lib.Symbol117();
	this.KH_TonleSap.name = "KH_TonleSap";
	this.KH_TonleSap.parent = this;
	this.KH_TonleSap.setTransform(745,1900);

	this.KH_PhnomPenh = new lib.Symbol116();
	this.KH_PhnomPenh.name = "KH_PhnomPenh";
	this.KH_PhnomPenh.parent = this;
	this.KH_PhnomPenh.setTransform(805,2226.5);

	this.KH_KompongChhnang = new lib.Symbol115();
	this.KH_KompongChhnang.name = "KH_KompongChhnang";
	this.KH_KompongChhnang.parent = this;
	this.KH_KompongChhnang.setTransform(675,2060);

	this.KH_Pursat = new lib.Symbol114();
	this.KH_Pursat.name = "KH_Pursat";
	this.KH_Pursat.parent = this;
	this.KH_Pursat.setTransform(618,1994.5);

	this.KH_Battambang = new lib.Symbol113();
	this.KH_Battambang.name = "KH_Battambang";
	this.KH_Battambang.parent = this;
	this.KH_Battambang.setTransform(525.5,1924);

	this.KH_KohTrong = new lib.Symbol112();
	this.KH_KohTrong.name = "KH_KohTrong";
	this.KH_KohTrong.parent = this;
	this.KH_KohTrong.setTransform(1178,2055);

	this.KH_KompongCham = new lib.Symbol111();
	this.KH_KompongCham.name = "KH_KompongCham";
	this.KH_KompongCham.parent = this;
	this.KH_KompongCham.setTransform(1052,2138);

	this.KH_Kratie = new lib.Symbol110();
	this.KH_Kratie.name = "KH_Kratie";
	this.KH_Kratie.parent = this;
	this.KH_Kratie.setTransform(1036,2022);

	this.KH_Mondulkiri = new lib.Symbol109();
	this.KH_Mondulkiri.name = "KH_Mondulkiri";
	this.KH_Mondulkiri.parent = this;
	this.KH_Mondulkiri.setTransform(1265,2000.5);

	this.KH_Rattanakiri = new lib.Symbol108();
	this.KH_Rattanakiri.name = "KH_Rattanakiri";
	this.KH_Rattanakiri.parent = this;
	this.KH_Rattanakiri.setTransform(1256,1767.5);

	this.KH_BanLung = new lib.Symbol107();
	this.KH_BanLung.name = "KH_BanLung";
	this.KH_BanLung.parent = this;
	this.KH_BanLung.setTransform(1285.4,1826);

	this.KH_StungTreng = new lib.Symbol106();
	this.KH_StungTreng.name = "KH_StungTreng";
	this.KH_StungTreng.parent = this;
	this.KH_StungTreng.setTransform(1037,1813);

	this.KH_KompongThom = new lib.Symbol105();
	this.KH_KompongThom.name = "KH_KompongThom";
	this.KH_KompongThom.parent = this;
	this.KH_KompongThom.setTransform(919.4,1975);

	this.KH_SiemReap = new lib.Symbol104();
	this.KH_SiemReap.name = "KH_SiemReap";
	this.KH_SiemReap.parent = this;
	this.KH_SiemReap.setTransform(748.5,1823.5);

	this.KH_SereiSaoPhoan = new lib.Symbol103();
	this.KH_SereiSaoPhoan.name = "KH_SereiSaoPhoan";
	this.KH_SereiSaoPhoan.parent = this;
	this.KH_SereiSaoPhoan.setTransform(577.5,1772);

	this.KH_KrongPoiPet = new lib.Symbol102();
	this.KH_KrongPoiPet.name = "KH_KrongPoiPet";
	this.KH_KrongPoiPet.parent = this;
	this.KH_KrongPoiPet.setTransform(668,1715);

	this.KH_Kohker = new lib.Symbol101();
	this.KH_Kohker.name = "KH_Kohker";
	this.KH_Kohker.parent = this;
	this.KH_Kohker.setTransform(757,1766.5);

	this.KH_PreahVihear = new lib.Symbol100();
	this.KH_PreahVihear.name = "KH_PreahVihear";
	this.KH_PreahVihear.parent = this;
	this.KH_PreahVihear.setTransform(921,1762.5);

	this.LA_IledeKhnong = new lib.Symbol99();
	this.LA_IledeKhnong.name = "LA_IledeKhnong";
	this.LA_IledeKhnong.parent = this;
	this.LA_IledeKhnong.setTransform(997,1706.5);

	this.LA_Champassak = new lib.Symbol98();
	this.LA_Champassak.name = "LA_Champassak";
	this.LA_Champassak.parent = this;
	this.LA_Champassak.setTransform(1120.5,1517);

	this.LA_BanKhietNgong = new lib.Symbol97();
	this.LA_BanKhietNgong.name = "LA_BanKhietNgong";
	this.LA_BanKhietNgong.parent = this;
	this.LA_BanKhietNgong.setTransform(1097,1646);

	this.LA_DonDeang = new lib.Symbol96();
	this.LA_DonDeang.name = "LA_DonDeang";
	this.LA_DonDeang.parent = this;
	this.LA_DonDeang.setTransform(1007.4,1560);

	this.LA_WatPhou = new lib.Symbol95();
	this.LA_WatPhou.name = "LA_WatPhou";
	this.LA_WatPhou.parent = this;
	this.LA_WatPhou.setTransform(1094.5,1585.5);

	this.LA_Attapeu = new lib.Symbol94();
	this.LA_Attapeu.name = "LA_Attapeu";
	this.LA_Attapeu.parent = this;
	this.LA_Attapeu.setTransform(1310,1600);

	this.LA_Pakse = new lib.Symbol93();
	this.LA_Pakse.name = "LA_Pakse";
	this.LA_Pakse.parent = this;
	this.LA_Pakse.setTransform(1049.5,1429.5);

	this.LA_Thateng = new lib.Symbol92();
	this.LA_Thateng.name = "LA_Thateng";
	this.LA_Thateng.parent = this;
	this.LA_Thateng.setTransform(1134.5,1366);

	this.LA_Laongam = new lib.Symbol91();
	this.LA_Laongam.name = "LA_Laongam";
	this.LA_Laongam.parent = this;
	this.LA_Laongam.setTransform(1072.9,1314);

	this.LA_Savannakhet = new lib.Symbol90();
	this.LA_Savannakhet.name = "LA_Savannakhet";
	this.LA_Savannakhet.parent = this;
	this.LA_Savannakhet.setTransform(945.5,1325.5);

	this.LA_Thakek = new lib.Symbol89();
	this.LA_Thakek.name = "LA_Thakek";
	this.LA_Thakek.parent = this;
	this.LA_Thakek.setTransform(888.5,1133.5);

	this.LA_Kenethao = new lib.Symbol88();
	this.LA_Kenethao.name = "LA_Kenethao";
	this.LA_Kenethao.parent = this;
	this.LA_Kenethao.setTransform(268,1042);

	this.LA_XamNeua = new lib.Symbol87();
	this.LA_XamNeua.name = "LA_XamNeua";
	this.LA_XamNeua.parent = this;
	this.LA_XamNeua.setTransform(716.5,626);

	this.LA_Hongsa = new lib.Symbol86();
	this.LA_Hongsa.name = "LA_Hongsa";
	this.LA_Hongsa.parent = this;
	this.LA_Hongsa.setTransform(267.5,727);

	this.LA_Vientiane = new lib.Symbol85();
	this.LA_Vientiane.name = "LA_Vientiane";
	this.LA_Vientiane.parent = this;
	this.LA_Vientiane.setTransform(442,1013);

	this.LA_PlainOfJars = new lib.Symbol84();
	this.LA_PlainOfJars.name = "LA_PlainOfJars";
	this.LA_PlainOfJars.parent = this;
	this.LA_PlainOfJars.setTransform(539.5,829.5);

	this.VN_NamCan = new lib.Symbol83();
	this.VN_NamCan.name = "VN_NamCan";
	this.VN_NamCan.parent = this;
	this.VN_NamCan.setTransform(777,774);

	this.LA_MuangKham = new lib.Symbol82();
	this.LA_MuangKham.name = "LA_MuangKham";
	this.LA_MuangKham.parent = this;
	this.LA_MuangKham.setTransform(675,710.5);

	this.LA_Phonxavan = new lib.Symbol81();
	this.LA_Phonxavan.name = "LA_Phonxavan";
	this.LA_Phonxavan.parent = this;
	this.LA_Phonxavan.setTransform(521,736.5);

	this.LA_VangVieng = new lib.Symbol80();
	this.LA_VangVieng.name = "LA_VangVieng";
	this.LA_VangVieng.parent = this;
	this.LA_VangVieng.setTransform(410,881.5);

	this.LA_Pakxan = new lib.Symbol79();
	this.LA_Pakxan.name = "LA_Pakxan";
	this.LA_Pakxan.parent = this;
	this.LA_Pakxan.setTransform(702.5,961.5);

	this.LA_NamNgum = new lib.Symbol78();
	this.LA_NamNgum.name = "LA_NamNgum";
	this.LA_NamNgum.parent = this;
	this.LA_NamNgum.setTransform(490.5,971);

	this.LA_Houixai = new lib.Symbol77();
	this.LA_Houixai.name = "LA_Houixai";
	this.LA_Houixai.parent = this;
	this.LA_Houixai.setTransform(107.5,547.5);

	this.LA_LuangPrabang = new lib.Symbol76();
	this.LA_LuangPrabang.name = "LA_LuangPrabang";
	this.LA_LuangPrabang.parent = this;
	this.LA_LuangPrabang.setTransform(382,673);

	this.LA_NongKhiaw = new lib.Symbol75();
	this.LA_NongKhiaw.name = "LA_NongKhiaw";
	this.LA_NongKhiaw.parent = this;
	this.LA_NongKhiaw.setTransform(562,583);

	this.LA_MuangNgoy = new lib.Symbol74();
	this.LA_MuangNgoy.name = "LA_MuangNgoy";
	this.LA_MuangNgoy.parent = this;
	this.LA_MuangNgoy.setTransform(559.5,533.5);

	this.LA_MuongKhua = new lib.Symbol73();
	this.LA_MuongKhua.name = "LA_MuongKhua";
	this.LA_MuongKhua.parent = this;
	this.LA_MuongKhua.setTransform(418.5,471);

	this.LA_LuangNamtha = new lib.Symbol72();
	this.LA_LuangNamtha.name = "LA_LuangNamtha";
	this.LA_LuangNamtha.parent = this;
	this.LA_LuangNamtha.setTransform(240.5,497);

	this.LA_MuangSing = new lib.Symbol71();
	this.LA_MuangSing.name = "LA_MuangSing";
	this.LA_MuangSing.parent = this;
	this.LA_MuangSing.setTransform(184.5,403);

	this.LA_Phongsali = new lib.Symbol70();
	this.LA_Phongsali.name = "LA_Phongsali";
	this.LA_Phongsali.parent = this;
	this.LA_Phongsali.setTransform(376.5,366);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.LA_Phongsali},{t:this.LA_MuangSing},{t:this.LA_LuangNamtha},{t:this.LA_MuongKhua},{t:this.LA_MuangNgoy},{t:this.LA_NongKhiaw},{t:this.LA_LuangPrabang},{t:this.LA_Houixai},{t:this.LA_NamNgum},{t:this.LA_Pakxan},{t:this.LA_VangVieng},{t:this.LA_Phonxavan},{t:this.LA_MuangKham},{t:this.VN_NamCan},{t:this.LA_PlainOfJars},{t:this.LA_Vientiane},{t:this.LA_Hongsa},{t:this.LA_XamNeua},{t:this.LA_Kenethao},{t:this.LA_Thakek},{t:this.LA_Savannakhet},{t:this.LA_Laongam},{t:this.LA_Thateng},{t:this.LA_Pakse},{t:this.LA_Attapeu},{t:this.LA_WatPhou},{t:this.LA_DonDeang},{t:this.LA_BanKhietNgong},{t:this.LA_Champassak},{t:this.LA_IledeKhnong},{t:this.KH_PreahVihear},{t:this.KH_Kohker},{t:this.KH_KrongPoiPet},{t:this.KH_SereiSaoPhoan},{t:this.KH_SiemReap},{t:this.KH_KompongThom},{t:this.KH_StungTreng},{t:this.KH_BanLung},{t:this.KH_Rattanakiri},{t:this.KH_Mondulkiri},{t:this.KH_Kratie},{t:this.KH_KompongCham},{t:this.KH_KohTrong},{t:this.KH_Battambang},{t:this.KH_Pursat},{t:this.KH_KompongChhnang},{t:this.KH_PhnomPenh},{t:this.KH_TonleSap},{t:this.KH_Kampot},{t:this.KH_Kep},{t:this.KH_Sihanoukville},{t:this.VN_BaBe},{t:this.VN_DongVan},{t:this.VN_DuongLam},{t:this.VN_HoangSuPhi},{t:this.VN_HaGiang},{t:this.VN_HaLong},{t:this.VN_HaiPhong},{t:this.VN_HaNoi},{t:this.VN_HoaBinh},{t:this.VN_LungKhauNhin},{t:this.VN_LaiChau},{t:this.VN_LangSon},{t:this.VN_LaoCai},{t:this.VN_LungCu},{t:this.VN_MuCangChai},{t:this.VN_MaiChau},{t:this.VN_MeoVac},{t:this.VN_MocChau},{t:this.VN_MongCai},{t:this.VN_MuongHum},{t:this.VN_MuongLay},{t:this.VN_NamDinh},{t:this.VN_PhongTho},{t:this.VN_PhuYen},{t:this.VN_NinhBinh},{t:this.VN_PuLuong},{t:this.VN_NghiaLo},{t:this.VN_QuanBa},{t:this.VN_QuangUyen},{t:this.VN_Sapa},{t:this.VN_SinCheng},{t:this.VN_SinHo},{t:this.VN_SonLa},{t:this.VN_TanTrao},{t:this.VN_ThaiBinh},{t:this.VN_BaKhe},{t:this.VN_BacGiang},{t:this.VN_BacHa},{t:this.VN_BacMe},{t:this.VN_BacNinh},{t:this.VN_BacSon},{t:this.VN_BanGioc},{t:this.VN_BaoLac},{t:this.VN_BinhLu},{t:this.VN_CanCau},{t:this.VN_CaoBang},{t:this.VN_CaoSon},{t:this.VN_CatBa},{t:this.VN_CocLy},{t:this.VN_DienBienPhu},{t:this.VN_DongKhe},{t:this.VN_ThanUyen},{t:this.VN_ThanhHoa},{t:this.VN_ThatKhe},{t:this.VN_TienYen},{t:this.VN_TuanGiao},{t:this.VN_TuyenQuang},{t:this.VN_VinhPhuc},{t:this.VN_XinMan},{t:this.VN_YenMinh},{t:this.VN_ThaiNguyen},{t:this.VN_TayTrang},{t:this.VN_ThacBa},{t:this.VN_Vinh},{t:this.VN_HaTinh},{t:this.VN_DongHoi},{t:this.VN_VinhMocTunnels},{t:this.VN_QuangTri},{t:this.VN_Hue},{t:this.VN_CauTreo},{t:this.VN_PhongNha},{t:this.VN_KheXanh},{t:this.VN_MySon},{t:this.VN_DaNang},{t:this.VN_HoiAn},{t:this.VN_ARoang},{t:this.VN_DongGiang},{t:this.VN_NamGiang},{t:this.VN_CuLaoCham},{t:this.VN_LySon},{t:this.VN_QuangNgai},{t:this.VN_SonHa},{t:this.VN_PhuocSon},{t:this.VN_HoangSa},{t:this.VN_QuyNhon},{t:this.VN_TuyHoa},{t:this.VN_NhaTrang},{t:this.VN_BinhBa},{t:this.VN_PhanRang},{t:this.VN_KonTum},{t:this.VN_BuonHo},{t:this.VN_BoY},{t:this.VN_Pleiku},{t:this.VN_BuonMeThuot},{t:this.VN_LacLake},{t:this.VN_DaLat},{t:this.VN_NinhGia},{t:this.VN_MuiNe},{t:this.VN_PhanThiet},{t:this.VN_GiaNghia},{t:this.VN_BaoLoc},{t:this.VN_DongNai},{t:this.VN_DongXoai},{t:this.VN_TayNinh},{t:this.VN_HoChiMinhCity},{t:this.VN_CuChi},{t:this.VN_MocBai},{t:this.VN_LongXuyen},{t:this.VN_SaDec},{t:this.VN_CaiLay},{t:this.VN_MyTho},{t:this.VN_VungTau},{t:this.VN_BenTre},{t:this.VN_CaiBe},{t:this.VN_VinhLong},{t:this.VN_TraVinh},{t:this.VN_SocTrang},{t:this.VN_BacLieu},{t:this.VN_CanTho},{t:this.VN_BangLang},{t:this.VN_HaTien},{t:this.VN_TraSu},{t:this.VN_RachGia},{t:this.VN_CaMau},{t:this.VN_ConDao},{t:this.VN_TruongSa},{t:this.VN_ChauDoc},{t:this.KH_Takeo},{t:this.VN_PhuQuoc},{t:this.VN_DuGia},{t:this.LA_Oudomxai},{t:this.VN_XuanMai},{t:this.LA_PakBeng},{t:this.VN_GotFerry},{t:this.VN_TuLe},{t:this.VN_DinhLap},{t:this.VN_YenThuy},{t:this.LA_Sekong},{t:this.LA_Paksong},{t:this.LA_Sanamxai},{t:this.VN_BuonDon},{t:this.VN_DraySap},{t:this.VN_CaoLanh},{t:this.VN_TanChau},{t:this.VN_TramChim},{t:this.VN_BacQuang},{t:this.VN_PhoRang},{t:this.VN_BacKan},{t:this.VN_BinhChau},{t:this.VN_CatTien},{t:this.VN_TanAn},{t:this.VN_TinhBien},{t:this.VN_ALuoi},{t:this.VN_BachMa},{t:this.VN_MyLai}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8copy, new cjs.Rectangle(48.5,3,1886.5,2715), null);


(lib.Symbol6copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();
	this.instance.parent = this;
	this.instance.setTransform(-24.5,-22.45);

	this.instance_1 = new lib.Path_0();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-13.1,1,1,0,0,0,29.7,16.6);

	this.instance_2 = new lib.CachedTexturedBitmap_596();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-30.85,-30.85,0.5228,0.5228);

	this.instance_3 = new lib.CachedTexturedBitmap_595();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-31.85,-31.85,0.5228,0.5228);

	this.instance_4 = new lib.CachedTexturedBitmap_594();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-31.85,-31.85,0.5228,0.5228);

	this.instance_5 = new lib.CachedTexturedBitmap_593();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-32.8,-32.85,0.5228,0.5228);

	this.instance_6 = new lib.CachedTexturedBitmap_592();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-36.6,-36.7,0.5228,0.5228);

	this.instance_7 = new lib.CachedTexturedBitmap_591();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-36.6,-36.7,0.5228,0.5228);

	this.instance_8 = new lib.CachedTexturedBitmap_590();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-36.7,-36.7,0.5228,0.5228);

	this.instance_9 = new lib.CachedTexturedBitmap_589();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-37.55,-37.55,0.5228,0.5228);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6copy, new cjs.Rectangle(-37.5,-37.5,75.3,75.3), null);


(lib.Symbol5_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.Symbol18();
	this.instance_2.parent = this;
	this.instance_2.setTransform(5,5,0.7973,0.7973,0,0,0,37.6,37.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5_2, new cjs.Rectangle(-25,-25,59.8,59.8), null);


(lib.Symbol4copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Symbol16();
	this.instance.parent = this;
	this.instance.setTransform(5,5,0.7973,0.7973,0,0,0,37.6,37.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4copy, new cjs.Rectangle(-25,-25,60,60), null);


(lib.Symbol3copy_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Symbol6copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(37.6,37.6,0.7973,0.7973);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3copy_1, new cjs.Rectangle(7.7,7.7,60,60), null);


(lib.Symbol1_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_76 = new lib.Symbol2_1();
	this.instance_76.parent = this;
	this.instance_76.setTransform(0.5,0,0.2857,0.2857,0,0,0,14,14);
	this.instance_76.alpha = 0.1914;

	this.timeline.addTween(cjs.Tween.get(this.instance_76).to({scaleX:0.3364,scaleY:0.3364,y:-0.1,alpha:1},14).to({scaleX:0.2857,scaleY:0.2857,x:0.4,y:0.05,alpha:0.1914},15).wait(1));

	// Layer_2
	this.instance_77 = new lib.Symbol3_1();
	this.instance_77.parent = this;
	this.instance_77.setTransform(0.5,-0.1,0.4464,0.4464,0,0,0,14,14);

	this.timeline.addTween(cjs.Tween.get(this.instance_77).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.7,-6.3,12.600000000000001,12.6);


(lib.Symbol5_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_3 = new lib.Symbol11();
	this.instance_3.parent = this;
	this.instance_3.setTransform(25.05,25.05,0.3251,0.3601);

	this.instance_4 = new lib.CachedTexturedBitmap_498();
	this.instance_4.parent = this;
	this.instance_4.setTransform(7.7,5,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_497();
	this.instance_5.parent = this;
	this.instance_5.setTransform(17.3,30.4,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_496();
	this.instance_6.parent = this;
	this.instance_6.setTransform(17.2,30.25,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_495();
	this.instance_7.parent = this;
	this.instance_7.setTransform(17.1,30.05,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_494();
	this.instance_8.parent = this;
	this.instance_8.setTransform(17,29.8,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_493();
	this.instance_9.parent = this;
	this.instance_9.setTransform(16.9,29.6,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_492();
	this.instance_10.parent = this;
	this.instance_10.setTransform(16.8,29.45,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_491();
	this.instance_11.parent = this;
	this.instance_11.setTransform(16.7,29.25,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_490();
	this.instance_12.parent = this;
	this.instance_12.setTransform(16.6,29,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_489();
	this.instance_13.parent = this;
	this.instance_13.setTransform(16.5,28.8,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_488();
	this.instance_14.parent = this;
	this.instance_14.setTransform(16.35,28.65,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_487();
	this.instance_15.parent = this;
	this.instance_15.setTransform(16.3,28.4,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_486();
	this.instance_16.parent = this;
	this.instance_16.setTransform(16.15,28.2,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_485();
	this.instance_17.parent = this;
	this.instance_17.setTransform(16.05,28,0.5,0.5);

	this.instance_18 = new lib.CachedTexturedBitmap_484();
	this.instance_18.parent = this;
	this.instance_18.setTransform(15.95,27.8,0.5,0.5);

	this.instance_19 = new lib.CachedTexturedBitmap_483();
	this.instance_19.parent = this;
	this.instance_19.setTransform(15.85,27.6,0.5,0.5);

	this.instance_20 = new lib.CachedTexturedBitmap_482();
	this.instance_20.parent = this;
	this.instance_20.setTransform(15.75,27.4,0.5,0.5);

	this.instance_21 = new lib.CachedTexturedBitmap_481();
	this.instance_21.parent = this;
	this.instance_21.setTransform(15.65,27.2,0.5,0.5);

	this.instance_22 = new lib.CachedTexturedBitmap_480();
	this.instance_22.parent = this;
	this.instance_22.setTransform(15.55,27,0.5,0.5);

	this.instance_23 = new lib.CachedTexturedBitmap_479();
	this.instance_23.parent = this;
	this.instance_23.setTransform(15.45,26.8,0.5,0.5);

	this.instance_24 = new lib.CachedTexturedBitmap_478();
	this.instance_24.parent = this;
	this.instance_24.setTransform(15.35,26.6,0.5,0.5);

	this.instance_25 = new lib.CachedTexturedBitmap_477();
	this.instance_25.parent = this;
	this.instance_25.setTransform(15.25,26.4,0.5,0.5);

	this.instance_26 = new lib.CachedTexturedBitmap_476();
	this.instance_26.parent = this;
	this.instance_26.setTransform(15.15,26.2,0.5,0.5);

	this.instance_27 = new lib.CachedTexturedBitmap_475();
	this.instance_27.parent = this;
	this.instance_27.setTransform(15.05,26,0.5,0.5);

	this.instance_28 = new lib.CachedTexturedBitmap_474();
	this.instance_28.parent = this;
	this.instance_28.setTransform(14.95,25.8,0.5,0.5);

	this.instance_29 = new lib.CachedTexturedBitmap_473();
	this.instance_29.parent = this;
	this.instance_29.setTransform(14.85,25.6,0.5,0.5);

	this.instance_30 = new lib.CachedTexturedBitmap_472();
	this.instance_30.parent = this;
	this.instance_30.setTransform(14.75,25.4,0.5,0.5);

	this.instance_31 = new lib.CachedTexturedBitmap_471();
	this.instance_31.parent = this;
	this.instance_31.setTransform(14.6,25.2,0.5,0.5);

	this.instance_32 = new lib.CachedTexturedBitmap_470();
	this.instance_32.parent = this;
	this.instance_32.setTransform(14.5,25,0.5,0.5);

	this.instance_33 = new lib.CachedTexturedBitmap_469();
	this.instance_33.parent = this;
	this.instance_33.setTransform(14.4,24.8,0.5,0.5);

	this.instance_34 = new lib.CachedTexturedBitmap_468();
	this.instance_34.parent = this;
	this.instance_34.setTransform(14.3,24.6,0.5,0.5);

	this.instance_35 = new lib.CachedTexturedBitmap_467();
	this.instance_35.parent = this;
	this.instance_35.setTransform(14.2,24.4,0.5,0.5);

	this.instance_36 = new lib.CachedTexturedBitmap_466();
	this.instance_36.parent = this;
	this.instance_36.setTransform(14.1,24.2,0.5,0.5);

	this.instance_37 = new lib.CachedTexturedBitmap_465();
	this.instance_37.parent = this;
	this.instance_37.setTransform(14,24,0.5,0.5);

	this.instance_38 = new lib.CachedTexturedBitmap_464();
	this.instance_38.parent = this;
	this.instance_38.setTransform(13.9,23.8,0.5,0.5);

	this.instance_39 = new lib.CachedTexturedBitmap_463();
	this.instance_39.parent = this;
	this.instance_39.setTransform(13.8,23.6,0.5,0.5);

	this.instance_40 = new lib.CachedTexturedBitmap_462();
	this.instance_40.parent = this;
	this.instance_40.setTransform(13.7,23.4,0.5,0.5);

	this.instance_41 = new lib.CachedTexturedBitmap_461();
	this.instance_41.parent = this;
	this.instance_41.setTransform(13.6,23.2,0.5,0.5);

	this.instance_42 = new lib.CachedTexturedBitmap_460();
	this.instance_42.parent = this;
	this.instance_42.setTransform(13.5,23,0.5,0.5);

	this.instance_43 = new lib.CachedTexturedBitmap_459();
	this.instance_43.parent = this;
	this.instance_43.setTransform(13.4,22.8,0.5,0.5);

	this.instance_44 = new lib.CachedTexturedBitmap_458();
	this.instance_44.parent = this;
	this.instance_44.setTransform(13.3,22.6,0.5,0.5);

	this.instance_45 = new lib.CachedTexturedBitmap_457();
	this.instance_45.parent = this;
	this.instance_45.setTransform(13.15,22.4,0.5,0.5);

	this.instance_46 = new lib.CachedTexturedBitmap_456();
	this.instance_46.parent = this;
	this.instance_46.setTransform(13.05,22.2,0.5,0.5);

	this.instance_47 = new lib.CachedTexturedBitmap_455();
	this.instance_47.parent = this;
	this.instance_47.setTransform(12.95,22,0.5,0.5);

	this.instance_48 = new lib.CachedTexturedBitmap_454();
	this.instance_48.parent = this;
	this.instance_48.setTransform(12.85,21.8,0.5,0.5);

	this.instance_49 = new lib.CachedTexturedBitmap_453();
	this.instance_49.parent = this;
	this.instance_49.setTransform(12.75,21.6,0.5,0.5);

	this.instance_50 = new lib.CachedTexturedBitmap_452();
	this.instance_50.parent = this;
	this.instance_50.setTransform(12.65,21.4,0.5,0.5);

	this.instance_51 = new lib.CachedTexturedBitmap_451();
	this.instance_51.parent = this;
	this.instance_51.setTransform(12.55,21.2,0.5,0.5);

	this.instance_52 = new lib.CachedTexturedBitmap_450();
	this.instance_52.parent = this;
	this.instance_52.setTransform(12.45,21,0.5,0.5);

	this.instance_53 = new lib.CachedTexturedBitmap_449();
	this.instance_53.parent = this;
	this.instance_53.setTransform(12.35,20.8,0.5,0.5);

	this.instance_54 = new lib.CachedTexturedBitmap_448();
	this.instance_54.parent = this;
	this.instance_54.setTransform(12.25,20.6,0.5,0.5);

	this.instance_55 = new lib.CachedTexturedBitmap_447();
	this.instance_55.parent = this;
	this.instance_55.setTransform(12.15,20.4,0.5,0.5);

	this.instance_56 = new lib.CachedTexturedBitmap_446();
	this.instance_56.parent = this;
	this.instance_56.setTransform(12.05,20.2,0.5,0.5);

	this.instance_57 = new lib.CachedTexturedBitmap_445();
	this.instance_57.parent = this;
	this.instance_57.setTransform(11.95,19.95,0.5,0.5);

	this.instance_58 = new lib.CachedTexturedBitmap_444();
	this.instance_58.parent = this;
	this.instance_58.setTransform(11.85,19.8,0.5,0.5);

	this.instance_59 = new lib.CachedTexturedBitmap_443();
	this.instance_59.parent = this;
	this.instance_59.setTransform(11.7,19.6,0.5,0.5);

	this.instance_60 = new lib.CachedTexturedBitmap_442();
	this.instance_60.parent = this;
	this.instance_60.setTransform(11.65,19.4,0.5,0.5);

	this.instance_61 = new lib.CachedTexturedBitmap_441();
	this.instance_61.parent = this;
	this.instance_61.setTransform(11.55,19.15,0.5,0.5);

	this.instance_62 = new lib.CachedTexturedBitmap_440();
	this.instance_62.parent = this;
	this.instance_62.setTransform(11.4,19,0.5,0.5);

	this.instance_63 = new lib.CachedTexturedBitmap_439();
	this.instance_63.parent = this;
	this.instance_63.setTransform(11.3,18.8,0.5,0.5);

	this.instance_64 = new lib.CachedTexturedBitmap_438();
	this.instance_64.parent = this;
	this.instance_64.setTransform(11.2,18.55,0.5,0.5);

	this.instance_65 = new lib.CachedTexturedBitmap_437();
	this.instance_65.parent = this;
	this.instance_65.setTransform(11.1,18.35,0.5,0.5);

	this.instance_66 = new lib.CachedTexturedBitmap_436();
	this.instance_66.parent = this;
	this.instance_66.setTransform(11,18.2,0.5,0.5);

	this.instance_67 = new lib.CachedTexturedBitmap_435();
	this.instance_67.parent = this;
	this.instance_67.setTransform(10.9,18,0.5,0.5);

	this.instance_68 = new lib.CachedTexturedBitmap_434();
	this.instance_68.parent = this;
	this.instance_68.setTransform(10.8,17.75,0.5,0.5);

	this.instance_69 = new lib.CachedTexturedBitmap_433();
	this.instance_69.parent = this;
	this.instance_69.setTransform(10.7,17.55,0.5,0.5);

	this.instance_70 = new lib.CachedTexturedBitmap_432();
	this.instance_70.parent = this;
	this.instance_70.setTransform(10.6,17.35,0.5,0.5);

	this.instance_71 = new lib.CachedTexturedBitmap_431();
	this.instance_71.parent = this;
	this.instance_71.setTransform(10.5,17.15,0.5,0.5);

	this.instance_72 = new lib.CachedTexturedBitmap_430();
	this.instance_72.parent = this;
	this.instance_72.setTransform(10.4,16.95,0.5,0.5);

	this.instance_73 = new lib.CachedTexturedBitmap_429();
	this.instance_73.parent = this;
	this.instance_73.setTransform(10.3,16.75,0.5,0.5);

	this.instance_74 = new lib.CachedTexturedBitmap_428();
	this.instance_74.parent = this;
	this.instance_74.setTransform(10.2,16.55,0.5,0.5);

	this.instance_75 = new lib.CachedTexturedBitmap_427();
	this.instance_75.parent = this;
	this.instance_75.setTransform(10.1,16.35,0.5,0.5);

	this.instance_76 = new lib.CachedTexturedBitmap_426();
	this.instance_76.parent = this;
	this.instance_76.setTransform(9.95,16.15,0.5,0.5);

	this.instance_77 = new lib.CachedTexturedBitmap_425();
	this.instance_77.parent = this;
	this.instance_77.setTransform(9.85,15.95,0.5,0.5);

	this.instance_78 = new lib.CachedTexturedBitmap_424();
	this.instance_78.parent = this;
	this.instance_78.setTransform(9.75,15.75,0.5,0.5);

	this.instance_79 = new lib.CachedTexturedBitmap_423();
	this.instance_79.parent = this;
	this.instance_79.setTransform(9.65,15.55,0.5,0.5);

	this.instance_80 = new lib.CachedTexturedBitmap_422();
	this.instance_80.parent = this;
	this.instance_80.setTransform(9.55,15.35,0.5,0.5);

	this.instance_81 = new lib.CachedTexturedBitmap_421();
	this.instance_81.parent = this;
	this.instance_81.setTransform(9.45,15.15,0.5,0.5);

	this.instance_82 = new lib.CachedTexturedBitmap_420();
	this.instance_82.parent = this;
	this.instance_82.setTransform(9.35,14.95,0.5,0.5);

	this.instance_83 = new lib.CachedTexturedBitmap_419();
	this.instance_83.parent = this;
	this.instance_83.setTransform(9.25,14.75,0.5,0.5);

	this.instance_84 = new lib.CachedTexturedBitmap_418();
	this.instance_84.parent = this;
	this.instance_84.setTransform(9.15,14.55,0.5,0.5);

	this.instance_85 = new lib.CachedTexturedBitmap_417();
	this.instance_85.parent = this;
	this.instance_85.setTransform(9.05,14.35,0.5,0.5);

	this.instance_86 = new lib.CachedTexturedBitmap_416();
	this.instance_86.parent = this;
	this.instance_86.setTransform(8.95,14.15,0.5,0.5);

	this.instance_87 = new lib.CachedTexturedBitmap_415();
	this.instance_87.parent = this;
	this.instance_87.setTransform(8.85,13.95,0.5,0.5);

	this.instance_88 = new lib.CachedTexturedBitmap_414();
	this.instance_88.parent = this;
	this.instance_88.setTransform(8.75,13.75,0.5,0.5);

	this.instance_89 = new lib.CachedTexturedBitmap_413();
	this.instance_89.parent = this;
	this.instance_89.setTransform(8.65,13.55,0.5,0.5);

	this.instance_90 = new lib.CachedTexturedBitmap_412();
	this.instance_90.parent = this;
	this.instance_90.setTransform(8.55,13.35,0.5,0.5);

	this.instance_91 = new lib.CachedTexturedBitmap_411();
	this.instance_91.parent = this;
	this.instance_91.setTransform(8.4,13.15,0.5,0.5);

	this.instance_92 = new lib.CachedTexturedBitmap_410();
	this.instance_92.parent = this;
	this.instance_92.setTransform(8.3,12.95,0.5,0.5);

	this.instance_93 = new lib.CachedTexturedBitmap_409();
	this.instance_93.parent = this;
	this.instance_93.setTransform(8.2,12.75,0.5,0.5);

	this.instance_94 = new lib.CachedTexturedBitmap_408();
	this.instance_94.parent = this;
	this.instance_94.setTransform(8.1,12.55,0.5,0.5);

	this.instance_95 = new lib.CachedTexturedBitmap_407();
	this.instance_95.parent = this;
	this.instance_95.setTransform(8,12.35,0.5,0.5);

	this.instance_96 = new lib.CachedTexturedBitmap_406();
	this.instance_96.parent = this;
	this.instance_96.setTransform(7.9,12.15,0.5,0.5);

	this.instance_97 = new lib.CachedTexturedBitmap_405();
	this.instance_97.parent = this;
	this.instance_97.setTransform(7.8,11.95,0.5,0.5);

	this.instance_98 = new lib.CachedTexturedBitmap_404();
	this.instance_98.parent = this;
	this.instance_98.setTransform(7.7,11.75,0.5,0.5);

	this.instance_99 = new lib.CachedTexturedBitmap_403();
	this.instance_99.parent = this;
	this.instance_99.setTransform(7.6,11.55,0.5,0.5);

	this.instance_100 = new lib.CachedTexturedBitmap_402();
	this.instance_100.parent = this;
	this.instance_100.setTransform(7.5,11.35,0.5,0.5);

	this.instance_101 = new lib.CachedTexturedBitmap_401();
	this.instance_101.parent = this;
	this.instance_101.setTransform(7.4,11.15,0.5,0.5);

	this.instance_102 = new lib.CachedTexturedBitmap_400();
	this.instance_102.parent = this;
	this.instance_102.setTransform(7.3,10.95,0.5,0.5);

	this.instance_103 = new lib.CachedTexturedBitmap_399();
	this.instance_103.parent = this;
	this.instance_103.setTransform(7.2,10.75,0.5,0.5);

	this.instance_104 = new lib.CachedTexturedBitmap_398();
	this.instance_104.parent = this;
	this.instance_104.setTransform(7.1,10.55,0.5,0.5);

	this.instance_105 = new lib.CachedTexturedBitmap_397();
	this.instance_105.parent = this;
	this.instance_105.setTransform(6.95,10.35,0.5,0.5);

	this.instance_106 = new lib.CachedTexturedBitmap_396();
	this.instance_106.parent = this;
	this.instance_106.setTransform(6.9,10.15,0.5,0.5);

	this.instance_107 = new lib.CachedTexturedBitmap_395();
	this.instance_107.parent = this;
	this.instance_107.setTransform(6.75,9.95,0.5,0.5);

	this.instance_108 = new lib.CachedTexturedBitmap_394();
	this.instance_108.parent = this;
	this.instance_108.setTransform(6.65,9.75,0.5,0.5);

	this.instance_109 = new lib.CachedTexturedBitmap_393();
	this.instance_109.parent = this;
	this.instance_109.setTransform(6.55,9.55,0.5,0.5);

	this.instance_110 = new lib.CachedTexturedBitmap_392();
	this.instance_110.parent = this;
	this.instance_110.setTransform(6.45,9.35,0.5,0.5);

	this.instance_111 = new lib.CachedTexturedBitmap_391();
	this.instance_111.parent = this;
	this.instance_111.setTransform(6.35,9.15,0.5,0.5);

	this.instance_112 = new lib.CachedTexturedBitmap_390();
	this.instance_112.parent = this;
	this.instance_112.setTransform(6.25,8.95,0.5,0.5);

	this.instance_113 = new lib.CachedTexturedBitmap_389();
	this.instance_113.parent = this;
	this.instance_113.setTransform(6.15,8.7,0.5,0.5);

	this.instance_114 = new lib.CachedTexturedBitmap_388();
	this.instance_114.parent = this;
	this.instance_114.setTransform(6.05,8.55,0.5,0.5);

	this.instance_115 = new lib.CachedTexturedBitmap_387();
	this.instance_115.parent = this;
	this.instance_115.setTransform(5.95,8.35,0.5,0.5);

	this.instance_116 = new lib.CachedTexturedBitmap_386();
	this.instance_116.parent = this;
	this.instance_116.setTransform(5.85,8.15,0.5,0.5);

	this.instance_117 = new lib.CachedTexturedBitmap_385();
	this.instance_117.parent = this;
	this.instance_117.setTransform(5.75,7.9,0.5,0.5);

	this.instance_118 = new lib.CachedTexturedBitmap_384();
	this.instance_118.parent = this;
	this.instance_118.setTransform(5.65,7.75,0.5,0.5);

	this.instance_119 = new lib.CachedTexturedBitmap_383();
	this.instance_119.parent = this;
	this.instance_119.setTransform(5.5,7.55,0.5,0.5);

	this.instance_120 = new lib.CachedTexturedBitmap_382();
	this.instance_120.parent = this;
	this.instance_120.setTransform(5.45,7.3,0.5,0.5);

	this.instance_121 = new lib.CachedTexturedBitmap_381();
	this.instance_121.parent = this;
	this.instance_121.setTransform(5.35,7.1,0.5,0.5);

	this.instance_122 = new lib.CachedTexturedBitmap_380();
	this.instance_122.parent = this;
	this.instance_122.setTransform(5.2,6.9,0.5,0.5);

	this.instance_123 = new lib.CachedTexturedBitmap_379();
	this.instance_123.parent = this;
	this.instance_123.setTransform(5.1,6.75,0.5,0.5);

	this.instance_124 = new lib.CachedTexturedBitmap_378();
	this.instance_124.parent = this;
	this.instance_124.setTransform(5,6.5,0.5,0.5);

	this.instance_125 = new lib.CachedTexturedBitmap_377();
	this.instance_125.parent = this;
	this.instance_125.setTransform(4.9,6.3,0.5,0.5);

	this.instance_126 = new lib.CachedTexturedBitmap_376();
	this.instance_126.parent = this;
	this.instance_126.setTransform(4.8,6.1,0.5,0.5);

	this.instance_127 = new lib.CachedTexturedBitmap_375();
	this.instance_127.parent = this;
	this.instance_127.setTransform(4.7,5.9,0.5,0.5);

	this.instance_128 = new lib.CachedTexturedBitmap_374();
	this.instance_128.parent = this;
	this.instance_128.setTransform(4.6,5.7,0.5,0.5);

	this.instance_129 = new lib.CachedTexturedBitmap_373();
	this.instance_129.parent = this;
	this.instance_129.setTransform(4.5,5.5,0.5,0.5);

	this.instance_130 = new lib.CachedTexturedBitmap_372();
	this.instance_130.parent = this;
	this.instance_130.setTransform(4.4,5.3,0.5,0.5);

	this.instance_131 = new lib.CachedTexturedBitmap_371();
	this.instance_131.parent = this;
	this.instance_131.setTransform(4.3,5.1,0.5,0.5);

	this.instance_132 = new lib.CachedTexturedBitmap_370();
	this.instance_132.parent = this;
	this.instance_132.setTransform(4.2,4.9,0.5,0.5);

	this.instance_133 = new lib.CachedTexturedBitmap_369();
	this.instance_133.parent = this;
	this.instance_133.setTransform(4.1,4.7,0.5,0.5);

	this.instance_134 = new lib.CachedTexturedBitmap_369();
	this.instance_134.parent = this;
	this.instance_134.setTransform(4.1,4.7,0.5,0.5);

	this.instance_135 = new lib.CachedTexturedBitmap_369();
	this.instance_135.parent = this;
	this.instance_135.setTransform(4.1,4.7,0.5,0.5);

	this.instance_136 = new lib.CachedTexturedBitmap_366();
	this.instance_136.parent = this;
	this.instance_136.setTransform(3.4,2.8,0.5,0.5);

	this.instance_137 = new lib.CachedTexturedBitmap_365();
	this.instance_137.parent = this;
	this.instance_137.setTransform(2.9,4.2,0.5,0.5);

	this.instance_138 = new lib.CachedTexturedBitmap_364();
	this.instance_138.parent = this;
	this.instance_138.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_138},{t:this.instance_137},{t:this.instance_136},{t:this.instance_135},{t:this.instance_134},{t:this.instance_133},{t:this.instance_132},{t:this.instance_131},{t:this.instance_130},{t:this.instance_129},{t:this.instance_128},{t:this.instance_127},{t:this.instance_126},{t:this.instance_125},{t:this.instance_124},{t:this.instance_123},{t:this.instance_122},{t:this.instance_121},{t:this.instance_120},{t:this.instance_119},{t:this.instance_118},{t:this.instance_117},{t:this.instance_116},{t:this.instance_115},{t:this.instance_114},{t:this.instance_113},{t:this.instance_112},{t:this.instance_111},{t:this.instance_110},{t:this.instance_109},{t:this.instance_108},{t:this.instance_107},{t:this.instance_106},{t:this.instance_105},{t:this.instance_104},{t:this.instance_103},{t:this.instance_102},{t:this.instance_101},{t:this.instance_100},{t:this.instance_99},{t:this.instance_98},{t:this.instance_97},{t:this.instance_96},{t:this.instance_95},{t:this.instance_94},{t:this.instance_93},{t:this.instance_92},{t:this.instance_91},{t:this.instance_90},{t:this.instance_89},{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5_3, new cjs.Rectangle(0,0,50,50), null);


(lib.Symbol3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.Symbol9();
	this.instance_2.parent = this;
	this.instance_2.setTransform(23.75,23,0.3861,0.3861);

	this.instance_3 = new lib.CachedTexturedBitmap_292();
	this.instance_3.parent = this;
	this.instance_3.setTransform(7.65,4.95,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_291();
	this.instance_4.parent = this;
	this.instance_4.setTransform(17.3,30.4,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_290();
	this.instance_5.parent = this;
	this.instance_5.setTransform(17.2,30.2,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_289();
	this.instance_6.parent = this;
	this.instance_6.setTransform(17.1,30.05,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_288();
	this.instance_7.parent = this;
	this.instance_7.setTransform(17,29.85,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_287();
	this.instance_8.parent = this;
	this.instance_8.setTransform(16.9,29.65,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_286();
	this.instance_9.parent = this;
	this.instance_9.setTransform(16.8,29.5,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_285();
	this.instance_10.parent = this;
	this.instance_10.setTransform(16.7,29.3,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_284();
	this.instance_11.parent = this;
	this.instance_11.setTransform(16.6,29.15,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_283();
	this.instance_12.parent = this;
	this.instance_12.setTransform(16.55,28.95,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_282();
	this.instance_13.parent = this;
	this.instance_13.setTransform(16.45,28.75,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_281();
	this.instance_14.parent = this;
	this.instance_14.setTransform(16.35,28.6,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_280();
	this.instance_15.parent = this;
	this.instance_15.setTransform(16.25,28.4,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_279();
	this.instance_16.parent = this;
	this.instance_16.setTransform(16.15,28.2,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_278();
	this.instance_17.parent = this;
	this.instance_17.setTransform(16.05,28.05,0.5,0.5);

	this.instance_18 = new lib.CachedTexturedBitmap_277();
	this.instance_18.parent = this;
	this.instance_18.setTransform(15.95,27.85,0.5,0.5);

	this.instance_19 = new lib.CachedTexturedBitmap_276();
	this.instance_19.parent = this;
	this.instance_19.setTransform(15.85,27.65,0.5,0.5);

	this.instance_20 = new lib.CachedTexturedBitmap_275();
	this.instance_20.parent = this;
	this.instance_20.setTransform(15.8,27.5,0.5,0.5);

	this.instance_21 = new lib.CachedTexturedBitmap_274();
	this.instance_21.parent = this;
	this.instance_21.setTransform(15.7,27.3,0.5,0.5);

	this.instance_22 = new lib.CachedTexturedBitmap_273();
	this.instance_22.parent = this;
	this.instance_22.setTransform(15.6,27.1,0.5,0.5);

	this.instance_23 = new lib.CachedTexturedBitmap_272();
	this.instance_23.parent = this;
	this.instance_23.setTransform(15.5,26.95,0.5,0.5);

	this.instance_24 = new lib.CachedTexturedBitmap_271();
	this.instance_24.parent = this;
	this.instance_24.setTransform(15.4,26.75,0.5,0.5);

	this.instance_25 = new lib.CachedTexturedBitmap_270();
	this.instance_25.parent = this;
	this.instance_25.setTransform(15.3,26.55,0.5,0.5);

	this.instance_26 = new lib.CachedTexturedBitmap_269();
	this.instance_26.parent = this;
	this.instance_26.setTransform(15.2,26.4,0.5,0.5);

	this.instance_27 = new lib.CachedTexturedBitmap_268();
	this.instance_27.parent = this;
	this.instance_27.setTransform(15.1,26.2,0.5,0.5);

	this.instance_28 = new lib.CachedTexturedBitmap_267();
	this.instance_28.parent = this;
	this.instance_28.setTransform(15.05,26,0.5,0.5);

	this.instance_29 = new lib.CachedTexturedBitmap_266();
	this.instance_29.parent = this;
	this.instance_29.setTransform(14.95,25.85,0.5,0.5);

	this.instance_30 = new lib.CachedTexturedBitmap_265();
	this.instance_30.parent = this;
	this.instance_30.setTransform(14.85,25.65,0.5,0.5);

	this.instance_31 = new lib.CachedTexturedBitmap_264();
	this.instance_31.parent = this;
	this.instance_31.setTransform(14.75,25.5,0.5,0.5);

	this.instance_32 = new lib.CachedTexturedBitmap_263();
	this.instance_32.parent = this;
	this.instance_32.setTransform(14.65,25.3,0.5,0.5);

	this.instance_33 = new lib.CachedTexturedBitmap_262();
	this.instance_33.parent = this;
	this.instance_33.setTransform(14.55,25.1,0.5,0.5);

	this.instance_34 = new lib.CachedTexturedBitmap_261();
	this.instance_34.parent = this;
	this.instance_34.setTransform(14.45,24.95,0.5,0.5);

	this.instance_35 = new lib.CachedTexturedBitmap_260();
	this.instance_35.parent = this;
	this.instance_35.setTransform(14.35,24.75,0.5,0.5);

	this.instance_36 = new lib.CachedTexturedBitmap_259();
	this.instance_36.parent = this;
	this.instance_36.setTransform(14.3,24.55,0.5,0.5);

	this.instance_37 = new lib.CachedTexturedBitmap_258();
	this.instance_37.parent = this;
	this.instance_37.setTransform(14.2,24.4,0.5,0.5);

	this.instance_38 = new lib.CachedTexturedBitmap_257();
	this.instance_38.parent = this;
	this.instance_38.setTransform(14.1,24.2,0.5,0.5);

	this.instance_39 = new lib.CachedTexturedBitmap_256();
	this.instance_39.parent = this;
	this.instance_39.setTransform(14,24,0.5,0.5);

	this.instance_40 = new lib.CachedTexturedBitmap_255();
	this.instance_40.parent = this;
	this.instance_40.setTransform(13.9,23.85,0.5,0.5);

	this.instance_41 = new lib.CachedTexturedBitmap_254();
	this.instance_41.parent = this;
	this.instance_41.setTransform(13.8,23.65,0.5,0.5);

	this.instance_42 = new lib.CachedTexturedBitmap_253();
	this.instance_42.parent = this;
	this.instance_42.setTransform(13.7,23.45,0.5,0.5);

	this.instance_43 = new lib.CachedTexturedBitmap_252();
	this.instance_43.parent = this;
	this.instance_43.setTransform(13.6,23.3,0.5,0.5);

	this.instance_44 = new lib.CachedTexturedBitmap_251();
	this.instance_44.parent = this;
	this.instance_44.setTransform(13.55,23.1,0.5,0.5);

	this.instance_45 = new lib.CachedTexturedBitmap_250();
	this.instance_45.parent = this;
	this.instance_45.setTransform(13.45,22.9,0.5,0.5);

	this.instance_46 = new lib.CachedTexturedBitmap_249();
	this.instance_46.parent = this;
	this.instance_46.setTransform(13.35,22.75,0.5,0.5);

	this.instance_47 = new lib.CachedTexturedBitmap_248();
	this.instance_47.parent = this;
	this.instance_47.setTransform(13.25,22.55,0.5,0.5);

	this.instance_48 = new lib.CachedTexturedBitmap_247();
	this.instance_48.parent = this;
	this.instance_48.setTransform(13.15,22.35,0.5,0.5);

	this.instance_49 = new lib.CachedTexturedBitmap_246();
	this.instance_49.parent = this;
	this.instance_49.setTransform(13.05,22.2,0.5,0.5);

	this.instance_50 = new lib.CachedTexturedBitmap_245();
	this.instance_50.parent = this;
	this.instance_50.setTransform(12.95,22,0.5,0.5);

	this.instance_51 = new lib.CachedTexturedBitmap_244();
	this.instance_51.parent = this;
	this.instance_51.setTransform(12.85,21.85,0.5,0.5);

	this.instance_52 = new lib.CachedTexturedBitmap_243();
	this.instance_52.parent = this;
	this.instance_52.setTransform(12.8,21.65,0.5,0.5);

	this.instance_53 = new lib.CachedTexturedBitmap_242();
	this.instance_53.parent = this;
	this.instance_53.setTransform(12.7,21.45,0.5,0.5);

	this.instance_54 = new lib.CachedTexturedBitmap_241();
	this.instance_54.parent = this;
	this.instance_54.setTransform(12.6,21.3,0.5,0.5);

	this.instance_55 = new lib.CachedTexturedBitmap_240();
	this.instance_55.parent = this;
	this.instance_55.setTransform(12.5,21.1,0.5,0.5);

	this.instance_56 = new lib.CachedTexturedBitmap_239();
	this.instance_56.parent = this;
	this.instance_56.setTransform(12.4,20.95,0.5,0.5);

	this.instance_57 = new lib.CachedTexturedBitmap_238();
	this.instance_57.parent = this;
	this.instance_57.setTransform(12.3,20.75,0.5,0.5);

	this.instance_58 = new lib.CachedTexturedBitmap_237();
	this.instance_58.parent = this;
	this.instance_58.setTransform(12.2,20.55,0.5,0.5);

	this.instance_59 = new lib.CachedTexturedBitmap_236();
	this.instance_59.parent = this;
	this.instance_59.setTransform(12.1,20.4,0.5,0.5);

	this.instance_60 = new lib.CachedTexturedBitmap_235();
	this.instance_60.parent = this;
	this.instance_60.setTransform(12.05,20.2,0.5,0.5);

	this.instance_61 = new lib.CachedTexturedBitmap_234();
	this.instance_61.parent = this;
	this.instance_61.setTransform(11.95,20,0.5,0.5);

	this.instance_62 = new lib.CachedTexturedBitmap_233();
	this.instance_62.parent = this;
	this.instance_62.setTransform(11.85,19.85,0.5,0.5);

	this.instance_63 = new lib.CachedTexturedBitmap_232();
	this.instance_63.parent = this;
	this.instance_63.setTransform(11.75,19.65,0.5,0.5);

	this.instance_64 = new lib.CachedTexturedBitmap_231();
	this.instance_64.parent = this;
	this.instance_64.setTransform(11.65,19.45,0.5,0.5);

	this.instance_65 = new lib.CachedTexturedBitmap_230();
	this.instance_65.parent = this;
	this.instance_65.setTransform(11.55,19.3,0.5,0.5);

	this.instance_66 = new lib.CachedTexturedBitmap_229();
	this.instance_66.parent = this;
	this.instance_66.setTransform(11.45,19.1,0.5,0.5);

	this.instance_67 = new lib.CachedTexturedBitmap_228();
	this.instance_67.parent = this;
	this.instance_67.setTransform(11.35,18.9,0.5,0.5);

	this.instance_68 = new lib.CachedTexturedBitmap_227();
	this.instance_68.parent = this;
	this.instance_68.setTransform(11.3,18.75,0.5,0.5);

	this.instance_69 = new lib.CachedTexturedBitmap_226();
	this.instance_69.parent = this;
	this.instance_69.setTransform(11.2,18.55,0.5,0.5);

	this.instance_70 = new lib.CachedTexturedBitmap_225();
	this.instance_70.parent = this;
	this.instance_70.setTransform(11.1,18.35,0.5,0.5);

	this.instance_71 = new lib.CachedTexturedBitmap_224();
	this.instance_71.parent = this;
	this.instance_71.setTransform(11,18.2,0.5,0.5);

	this.instance_72 = new lib.CachedTexturedBitmap_223();
	this.instance_72.parent = this;
	this.instance_72.setTransform(10.9,18,0.5,0.5);

	this.instance_73 = new lib.CachedTexturedBitmap_222();
	this.instance_73.parent = this;
	this.instance_73.setTransform(10.8,17.8,0.5,0.5);

	this.instance_74 = new lib.CachedTexturedBitmap_221();
	this.instance_74.parent = this;
	this.instance_74.setTransform(10.7,17.65,0.5,0.5);

	this.instance_75 = new lib.CachedTexturedBitmap_220();
	this.instance_75.parent = this;
	this.instance_75.setTransform(10.6,17.45,0.5,0.5);

	this.instance_76 = new lib.CachedTexturedBitmap_219();
	this.instance_76.parent = this;
	this.instance_76.setTransform(10.55,17.3,0.5,0.5);

	this.instance_77 = new lib.CachedTexturedBitmap_218();
	this.instance_77.parent = this;
	this.instance_77.setTransform(10.4,17.1,0.5,0.5);

	this.instance_78 = new lib.CachedTexturedBitmap_217();
	this.instance_78.parent = this;
	this.instance_78.setTransform(10.35,16.9,0.5,0.5);

	this.instance_79 = new lib.CachedTexturedBitmap_216();
	this.instance_79.parent = this;
	this.instance_79.setTransform(10.25,16.75,0.5,0.5);

	this.instance_80 = new lib.CachedTexturedBitmap_215();
	this.instance_80.parent = this;
	this.instance_80.setTransform(10.15,16.55,0.5,0.5);

	this.instance_81 = new lib.CachedTexturedBitmap_214();
	this.instance_81.parent = this;
	this.instance_81.setTransform(10.05,16.35,0.5,0.5);

	this.instance_82 = new lib.CachedTexturedBitmap_213();
	this.instance_82.parent = this;
	this.instance_82.setTransform(9.95,16.2,0.5,0.5);

	this.instance_83 = new lib.CachedTexturedBitmap_212();
	this.instance_83.parent = this;
	this.instance_83.setTransform(9.85,16,0.5,0.5);

	this.instance_84 = new lib.CachedTexturedBitmap_211();
	this.instance_84.parent = this;
	this.instance_84.setTransform(9.8,15.85,0.5,0.5);

	this.instance_85 = new lib.CachedTexturedBitmap_210();
	this.instance_85.parent = this;
	this.instance_85.setTransform(9.65,15.65,0.5,0.5);

	this.instance_86 = new lib.CachedTexturedBitmap_209();
	this.instance_86.parent = this;
	this.instance_86.setTransform(9.6,15.45,0.5,0.5);

	this.instance_87 = new lib.CachedTexturedBitmap_208();
	this.instance_87.parent = this;
	this.instance_87.setTransform(9.5,15.25,0.5,0.5);

	this.instance_88 = new lib.CachedTexturedBitmap_207();
	this.instance_88.parent = this;
	this.instance_88.setTransform(9.4,15.1,0.5,0.5);

	this.instance_89 = new lib.CachedTexturedBitmap_206();
	this.instance_89.parent = this;
	this.instance_89.setTransform(9.3,14.9,0.5,0.5);

	this.instance_90 = new lib.CachedTexturedBitmap_205();
	this.instance_90.parent = this;
	this.instance_90.setTransform(9.2,14.7,0.5,0.5);

	this.instance_91 = new lib.CachedTexturedBitmap_204();
	this.instance_91.parent = this;
	this.instance_91.setTransform(9.1,14.55,0.5,0.5);

	this.instance_92 = new lib.CachedTexturedBitmap_203();
	this.instance_92.parent = this;
	this.instance_92.setTransform(9.05,14.35,0.5,0.5);

	this.instance_93 = new lib.CachedTexturedBitmap_202();
	this.instance_93.parent = this;
	this.instance_93.setTransform(8.9,14.15,0.5,0.5);

	this.instance_94 = new lib.CachedTexturedBitmap_201();
	this.instance_94.parent = this;
	this.instance_94.setTransform(8.85,14,0.5,0.5);

	this.instance_95 = new lib.CachedTexturedBitmap_200();
	this.instance_95.parent = this;
	this.instance_95.setTransform(8.75,13.8,0.5,0.5);

	this.instance_96 = new lib.CachedTexturedBitmap_199();
	this.instance_96.parent = this;
	this.instance_96.setTransform(8.65,13.65,0.5,0.5);

	this.instance_97 = new lib.CachedTexturedBitmap_198();
	this.instance_97.parent = this;
	this.instance_97.setTransform(8.55,13.45,0.5,0.5);

	this.instance_98 = new lib.CachedTexturedBitmap_197();
	this.instance_98.parent = this;
	this.instance_98.setTransform(8.45,13.25,0.5,0.5);

	this.instance_99 = new lib.CachedTexturedBitmap_196();
	this.instance_99.parent = this;
	this.instance_99.setTransform(8.35,13.1,0.5,0.5);

	this.instance_100 = new lib.CachedTexturedBitmap_195();
	this.instance_100.parent = this;
	this.instance_100.setTransform(8.3,12.9,0.5,0.5);

	this.instance_101 = new lib.CachedTexturedBitmap_194();
	this.instance_101.parent = this;
	this.instance_101.setTransform(8.15,12.75,0.5,0.5);

	this.instance_102 = new lib.CachedTexturedBitmap_193();
	this.instance_102.parent = this;
	this.instance_102.setTransform(8.1,12.55,0.5,0.5);

	this.instance_103 = new lib.CachedTexturedBitmap_192();
	this.instance_103.parent = this;
	this.instance_103.setTransform(8,12.35,0.5,0.5);

	this.instance_104 = new lib.CachedTexturedBitmap_191();
	this.instance_104.parent = this;
	this.instance_104.setTransform(7.9,12.2,0.5,0.5);

	this.instance_105 = new lib.CachedTexturedBitmap_190();
	this.instance_105.parent = this;
	this.instance_105.setTransform(7.8,12,0.5,0.5);

	this.instance_106 = new lib.CachedTexturedBitmap_189();
	this.instance_106.parent = this;
	this.instance_106.setTransform(7.7,11.8,0.5,0.5);

	this.instance_107 = new lib.CachedTexturedBitmap_188();
	this.instance_107.parent = this;
	this.instance_107.setTransform(7.6,11.65,0.5,0.5);

	this.instance_108 = new lib.CachedTexturedBitmap_187();
	this.instance_108.parent = this;
	this.instance_108.setTransform(7.55,11.45,0.5,0.5);

	this.instance_109 = new lib.CachedTexturedBitmap_186();
	this.instance_109.parent = this;
	this.instance_109.setTransform(7.4,11.25,0.5,0.5);

	this.instance_110 = new lib.CachedTexturedBitmap_185();
	this.instance_110.parent = this;
	this.instance_110.setTransform(7.35,11.1,0.5,0.5);

	this.instance_111 = new lib.CachedTexturedBitmap_184();
	this.instance_111.parent = this;
	this.instance_111.setTransform(7.25,10.9,0.5,0.5);

	this.instance_112 = new lib.CachedTexturedBitmap_183();
	this.instance_112.parent = this;
	this.instance_112.setTransform(7.15,10.7,0.5,0.5);

	this.instance_113 = new lib.CachedTexturedBitmap_182();
	this.instance_113.parent = this;
	this.instance_113.setTransform(7.05,10.55,0.5,0.5);

	this.instance_114 = new lib.CachedTexturedBitmap_181();
	this.instance_114.parent = this;
	this.instance_114.setTransform(6.95,10.35,0.5,0.5);

	this.instance_115 = new lib.CachedTexturedBitmap_180();
	this.instance_115.parent = this;
	this.instance_115.setTransform(6.85,10.15,0.5,0.5);

	this.instance_116 = new lib.CachedTexturedBitmap_179();
	this.instance_116.parent = this;
	this.instance_116.setTransform(6.8,10,0.5,0.5);

	this.instance_117 = new lib.CachedTexturedBitmap_178();
	this.instance_117.parent = this;
	this.instance_117.setTransform(6.65,9.8,0.5,0.5);

	this.instance_118 = new lib.CachedTexturedBitmap_177();
	this.instance_118.parent = this;
	this.instance_118.setTransform(6.6,9.6,0.5,0.5);

	this.instance_119 = new lib.CachedTexturedBitmap_176();
	this.instance_119.parent = this;
	this.instance_119.setTransform(6.5,9.45,0.5,0.5);

	this.instance_120 = new lib.CachedTexturedBitmap_175();
	this.instance_120.parent = this;
	this.instance_120.setTransform(6.4,9.25,0.5,0.5);

	this.instance_121 = new lib.CachedTexturedBitmap_174();
	this.instance_121.parent = this;
	this.instance_121.setTransform(6.3,9.1,0.5,0.5);

	this.instance_122 = new lib.CachedTexturedBitmap_173();
	this.instance_122.parent = this;
	this.instance_122.setTransform(6.2,8.9,0.5,0.5);

	this.instance_123 = new lib.CachedTexturedBitmap_172();
	this.instance_123.parent = this;
	this.instance_123.setTransform(6.1,8.7,0.5,0.5);

	this.instance_124 = new lib.CachedTexturedBitmap_171();
	this.instance_124.parent = this;
	this.instance_124.setTransform(6.05,8.55,0.5,0.5);

	this.instance_125 = new lib.CachedTexturedBitmap_170();
	this.instance_125.parent = this;
	this.instance_125.setTransform(5.9,8.35,0.5,0.5);

	this.instance_126 = new lib.CachedTexturedBitmap_169();
	this.instance_126.parent = this;
	this.instance_126.setTransform(5.85,8.15,0.5,0.5);

	this.instance_127 = new lib.CachedTexturedBitmap_168();
	this.instance_127.parent = this;
	this.instance_127.setTransform(5.75,8,0.5,0.5);

	this.instance_128 = new lib.CachedTexturedBitmap_167();
	this.instance_128.parent = this;
	this.instance_128.setTransform(5.65,7.8,0.5,0.5);

	this.instance_129 = new lib.CachedTexturedBitmap_166();
	this.instance_129.parent = this;
	this.instance_129.setTransform(5.55,7.65,0.5,0.5);

	this.instance_130 = new lib.CachedTexturedBitmap_165();
	this.instance_130.parent = this;
	this.instance_130.setTransform(5.45,7.45,0.5,0.5);

	this.instance_131 = new lib.CachedTexturedBitmap_164();
	this.instance_131.parent = this;
	this.instance_131.setTransform(5.35,7.25,0.5,0.5);

	this.instance_132 = new lib.CachedTexturedBitmap_163();
	this.instance_132.parent = this;
	this.instance_132.setTransform(5.3,7.05,0.5,0.5);

	this.instance_133 = new lib.CachedTexturedBitmap_162();
	this.instance_133.parent = this;
	this.instance_133.setTransform(5.15,6.9,0.5,0.5);

	this.instance_134 = new lib.CachedTexturedBitmap_161();
	this.instance_134.parent = this;
	this.instance_134.setTransform(5.1,6.7,0.5,0.5);

	this.instance_135 = new lib.CachedTexturedBitmap_160();
	this.instance_135.parent = this;
	this.instance_135.setTransform(5,6.5,0.5,0.5);

	this.instance_136 = new lib.CachedTexturedBitmap_159();
	this.instance_136.parent = this;
	this.instance_136.setTransform(4.9,6.35,0.5,0.5);

	this.instance_137 = new lib.CachedTexturedBitmap_158();
	this.instance_137.parent = this;
	this.instance_137.setTransform(4.8,6.15,0.5,0.5);

	this.instance_138 = new lib.CachedTexturedBitmap_157();
	this.instance_138.parent = this;
	this.instance_138.setTransform(4.7,5.95,0.5,0.5);

	this.instance_139 = new lib.CachedTexturedBitmap_156();
	this.instance_139.parent = this;
	this.instance_139.setTransform(4.6,5.8,0.5,0.5);

	this.instance_140 = new lib.CachedTexturedBitmap_155();
	this.instance_140.parent = this;
	this.instance_140.setTransform(4.55,5.6,0.5,0.5);

	this.instance_141 = new lib.CachedTexturedBitmap_154();
	this.instance_141.parent = this;
	this.instance_141.setTransform(4.4,5.45,0.5,0.5);

	this.instance_142 = new lib.CachedTexturedBitmap_153();
	this.instance_142.parent = this;
	this.instance_142.setTransform(4.35,5.25,0.5,0.5);

	this.instance_143 = new lib.CachedTexturedBitmap_152();
	this.instance_143.parent = this;
	this.instance_143.setTransform(4.25,5.05,0.5,0.5);

	this.instance_144 = new lib.CachedTexturedBitmap_151();
	this.instance_144.parent = this;
	this.instance_144.setTransform(4.15,4.9,0.5,0.5);

	this.instance_145 = new lib.CachedTexturedBitmap_150();
	this.instance_145.parent = this;
	this.instance_145.setTransform(4.05,4.7,0.5,0.5);

	this.instance_146 = new lib.CachedTexturedBitmap_150();
	this.instance_146.parent = this;
	this.instance_146.setTransform(4.05,4.7,0.5,0.5);

	this.instance_147 = new lib.CachedTexturedBitmap_150();
	this.instance_147.parent = this;
	this.instance_147.setTransform(4.05,4.7,0.5,0.5);

	this.instance_148 = new lib.CachedTexturedBitmap_147();
	this.instance_148.parent = this;
	this.instance_148.setTransform(3.4,2.8,0.5,0.5);

	this.instance_149 = new lib.CachedTexturedBitmap_146();
	this.instance_149.parent = this;
	this.instance_149.setTransform(2.9,4.2,0.5,0.5);

	this.instance_150 = new lib.CachedTexturedBitmap_145();
	this.instance_150.parent = this;
	this.instance_150.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_150},{t:this.instance_149},{t:this.instance_148},{t:this.instance_147},{t:this.instance_146},{t:this.instance_145},{t:this.instance_144},{t:this.instance_143},{t:this.instance_142},{t:this.instance_141},{t:this.instance_140},{t:this.instance_139},{t:this.instance_138},{t:this.instance_137},{t:this.instance_136},{t:this.instance_135},{t:this.instance_134},{t:this.instance_133},{t:this.instance_132},{t:this.instance_131},{t:this.instance_130},{t:this.instance_129},{t:this.instance_128},{t:this.instance_127},{t:this.instance_126},{t:this.instance_125},{t:this.instance_124},{t:this.instance_123},{t:this.instance_122},{t:this.instance_121},{t:this.instance_120},{t:this.instance_119},{t:this.instance_118},{t:this.instance_117},{t:this.instance_116},{t:this.instance_115},{t:this.instance_114},{t:this.instance_113},{t:this.instance_112},{t:this.instance_111},{t:this.instance_110},{t:this.instance_109},{t:this.instance_108},{t:this.instance_107},{t:this.instance_106},{t:this.instance_105},{t:this.instance_104},{t:this.instance_103},{t:this.instance_102},{t:this.instance_101},{t:this.instance_100},{t:this.instance_99},{t:this.instance_98},{t:this.instance_97},{t:this.instance_96},{t:this.instance_95},{t:this.instance_94},{t:this.instance_93},{t:this.instance_92},{t:this.instance_91},{t:this.instance_90},{t:this.instance_89},{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3_2, new cjs.Rectangle(0,0,50,50), null);


(lib.mcDriver = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.mcDriver_4 = new lib.Symbol7_1();
	this.mcDriver_4.name = "mcDriver_4";
	this.mcDriver_4.parent = this;
	this.mcDriver_4.setTransform(25.05,187,0.7905,0.7868,0,0,0,31.7,31.8);

	this.mcDriver_3 = new lib.Symbol5_3();
	this.mcDriver_3.name = "mcDriver_3";
	this.mcDriver_3.parent = this;
	this.mcDriver_3.setTransform(25,133.05,1,0.999,0,0,0,25,25.1);

	this.mcDriver_6 = new lib.Symbol4_2();
	this.mcDriver_6.name = "mcDriver_6";
	this.mcDriver_6.parent = this;
	this.mcDriver_6.setTransform(25,295,1,1,0,0,0,25,25);

	this.mcDriver_1 = new lib.Symbol3_2();
	this.mcDriver_1.name = "mcDriver_1";
	this.mcDriver_1.parent = this;
	this.mcDriver_1.setTransform(25,25,1,1,0,0,0,25,25);

	this.mcDriver_5 = new lib.Symbol2_2();
	this.mcDriver_5.name = "mcDriver_5";
	this.mcDriver_5.parent = this;
	this.mcDriver_5.setTransform(25,241,1,1,0,0,0,25,25);

	this.mcDriver_2 = new lib.Symbol1_1();
	this.mcDriver_2.name = "mcDriver_2";
	this.mcDriver_2.parent = this;
	this.mcDriver_2.setTransform(24.95,78.95,0.995,0.9901,0,0,0,25.1,25.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mcDriver_2},{t:this.mcDriver_5},{t:this.mcDriver_1},{t:this.mcDriver_6},{t:this.mcDriver_3},{t:this.mcDriver_4}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mcDriver, new cjs.Rectangle(0,0,50,320), null);


(lib.btnDot3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol4_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.3333,scaleY:1.3333},0).wait(1).to({scaleX:1,scaleY:1},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.3,-9.3,18.700000000000003,18.700000000000003);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol14();
	this.instance.parent = this;
	this.instance.setTransform(105.2,52.6,1,1,0,0,0,105.2,52.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.0618,scaleY:1.0618,x:111.7,y:55.85},0).wait(1).to({scaleX:1,scaleY:1,x:105.2,y:52.6},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.5,-26.5,63.5,63.5);


(lib.Symbol7_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_88 = new lib.Symbol5_2();
	this.instance_88.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_88).wait(1).to({scaleX:1.0618,scaleY:1.0618},0).wait(1).to({scaleX:1,scaleY:1},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.5,-26.5,63.5,63.5);


(lib.Symbol6_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_2 = new lib.Symbol4copy();
	this.instance_2.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({scaleX:1.0999,scaleY:1.0999},0).wait(1).to({scaleX:1,scaleY:1},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.4,-27.4,66,66);


(lib.Symbol4copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol3copy_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,37.6,37.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.1995,scaleY:1.1995},0).wait(1).to({scaleX:1,scaleY:1},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35.9,-35.9,72,72);


(lib.Symbol1copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hnpoint_png
	this.instance = new lib.hnpoint();
	this.instance.parent = this;
	this.instance.setTransform(-12,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// mcAnim
	this.mcAnim = new lib.Symbol1_3();
	this.mcAnim.name = "mcAnim";
	this.mcAnim.parent = this;
	this.mcAnim.setTransform(0.5,-1.2,1.7037,1.7037);

	this.timeline.addTween(cjs.Tween.get(this.mcAnim).wait(1));

	// mcPoint
	this.mcPoint = new lib.btnDot3();
	this.mcPoint.name = "mcPoint";
	this.mcPoint.parent = this;
	this.mcPoint.setTransform(0.9,-0.9);
	new cjs.ButtonHelper(this.mcPoint, 0, 1, 2, false, new lib.btnDot3(), 3);

	this.timeline.addTween(cjs.Tween.get(this.mcPoint).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy5, new cjs.Rectangle(-12,-12,24.3,24), null);


(lib.Symbol3_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.mcAnim = new lib.Symbol1_3();
	this.mcAnim.name = "mcAnim";
	this.mcAnim.parent = this;
	this.mcAnim.setTransform(-0.4,-0.3,1.7037,1.7037);

	this.timeline.addTween(cjs.Tween.get(this.mcAnim).wait(1));

	// Layer_1
	this.mcPoint = new lib.btnDot3();
	this.mcPoint.name = "mcPoint";
	this.mcPoint.parent = this;
	new cjs.ButtonHelper(this.mcPoint, 0, 1, 2, false, new lib.btnDot3(), 3);

	this.timeline.addTween(cjs.Tween.get(this.mcPoint).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3_3, new cjs.Rectangle(-10.1,-11.1,21.5,21.5), null);


(lib.mcSetting = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.btnCome = new lib.Symbol4copy2();
	this.btnCome.name = "btnCome";
	this.btnCome.parent = this;
	this.btnCome.setTransform(320.2,42.6,1,1,0,0,180);
	new cjs.ButtonHelper(this.btnCome, 0, 1, 2, false, new lib.Symbol4copy2(), 3);

	this.btnGo = new lib.Symbol4copy2();
	this.btnGo.name = "btnGo";
	this.btnGo.parent = this;
	this.btnGo.setTransform(252.2,42.6);
	new cjs.ButtonHelper(this.btnGo, 0, 1, 2, false, new lib.Symbol4copy2(), 3);

	this.btnCapture = new lib.Symbol15();
	this.btnCapture.name = "btnCapture";
	this.btnCapture.parent = this;
	this.btnCapture.setTransform(108.7,37.6);
	new cjs.ButtonHelper(this.btnCapture, 0, 1, 2, false, new lib.Symbol15(), 3);

	this.btnResetAll = new lib.Symbol7_3();
	this.btnResetAll.name = "btnResetAll";
	this.btnResetAll.parent = this;
	this.btnResetAll.setTransform(177.6,37.6);
	new cjs.ButtonHelper(this.btnResetAll, 0, 1, 2, false, new lib.Symbol7_3(), 3);

	this.btnNewRound = new lib.Symbol6_2();
	this.btnNewRound.name = "btnNewRound";
	this.btnNewRound.parent = this;
	this.btnNewRound.setTransform(41.6,37.6);
	new cjs.ButtonHelper(this.btnNewRound, 0, 1, 2, false, new lib.Symbol6_2(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btnNewRound},{t:this.btnResetAll},{t:this.btnCapture},{t:this.btnGo},{t:this.btnCome}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mcSetting, new cjs.Rectangle(14.1,6.6,342,72), null);


(lib.Symbol1copy_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.VN_TinhBien = new lib.Symbol3_3();
	this.VN_TinhBien.name = "VN_TinhBien";
	this.VN_TinhBien.parent = this;
	this.VN_TinhBien.setTransform(902.3,2437.75);

	this.VN_TanAn = new lib.Symbol3_3();
	this.VN_TanAn.name = "VN_TanAn";
	this.VN_TanAn.parent = this;
	this.VN_TanAn.setTransform(1204.35,2439.45);

	this.VN_BinhChau = new lib.Symbol3_3();
	this.VN_BinhChau.name = "VN_BinhChau";
	this.VN_BinhChau.parent = this;
	this.VN_BinhChau.setTransform(1408.3,2426.75);

	this.VN_DongNai = new lib.Symbol3_3();
	this.VN_DongNai.name = "VN_DongNai";
	this.VN_DongNai.parent = this;
	this.VN_DongNai.setTransform(1339.3,2335.55);

	this.VN_CatTien = new lib.Symbol3_3();
	this.VN_CatTien.name = "VN_CatTien";
	this.VN_CatTien.parent = this;
	this.VN_CatTien.setTransform(1364.6,2247.2);

	this.VN_ALuoi = new lib.Symbol3_3();
	this.VN_ALuoi.name = "VN_ALuoi";
	this.VN_ALuoi.parent = this;
	this.VN_ALuoi.setTransform(1334,1391.1);

	this.VN_BachMa = new lib.Symbol3_3();
	this.VN_BachMa.name = "VN_BachMa";
	this.VN_BachMa.parent = this;
	this.VN_BachMa.setTransform(1433.3,1400.3);

	this.VN_MyLai = new lib.Symbol3_3();
	this.VN_MyLai.name = "VN_MyLai";
	this.VN_MyLai.parent = this;
	this.VN_MyLai.setTransform(1665.45,1649);

	this.VN_BacQuang = new lib.Symbol3_3();
	this.VN_BacQuang.name = "VN_BacQuang";
	this.VN_BacQuang.parent = this;
	this.VN_BacQuang.setTransform(900.65,268.35);

	this.VN_PhoRang = new lib.Symbol3_3();
	this.VN_PhoRang.name = "VN_PhoRang";
	this.VN_PhoRang.parent = this;
	this.VN_PhoRang.setTransform(844.15,305.65);

	this.VN_BacKan = new lib.Symbol3_3();
	this.VN_BacKan.name = "VN_BacKan";
	this.VN_BacKan.parent = this;
	this.VN_BacKan.setTransform(1081.25,306.35);

	this.VN_TanChau = new lib.Symbol3_3();
	this.VN_TanChau.name = "VN_TanChau";
	this.VN_TanChau.parent = this;
	this.VN_TanChau.setTransform(935.55,2379.75);

	this.VN_TramChim = new lib.Symbol3_3();
	this.VN_TramChim.name = "VN_TramChim";
	this.VN_TramChim.parent = this;
	this.VN_TramChim.setTransform(1052.85,2410.45);

	this.VN_YenThuy = new lib.Symbol3_3();
	this.VN_YenThuy.name = "VN_YenThuy";
	this.VN_YenThuy.parent = this;
	this.VN_YenThuy.setTransform(1054.85,630.35);

	this.VN_TuLe = new lib.Symbol3_3();
	this.VN_TuLe.name = "VN_TuLe";
	this.VN_TuLe.parent = this;
	this.VN_TuLe.setTransform(819.35,421.85);

	this.VN_DinhLap = new lib.Symbol3_3();
	this.VN_DinhLap.name = "VN_DinhLap";
	this.VN_DinhLap.parent = this;
	this.VN_DinhLap.setTransform(1296.35,404.85);

	this.VN_GotFerry = new lib.Symbol3_3();
	this.VN_GotFerry.name = "VN_GotFerry";
	this.VN_GotFerry.parent = this;
	this.VN_GotFerry.setTransform(1277.35,575.85);

	this.LA_Sekong = new lib.Symbol3_3();
	this.LA_Sekong.name = "LA_Sekong";
	this.LA_Sekong.parent = this;
	this.LA_Sekong.setTransform(1257.35,1462.1);

	this.LA_Paksong = new lib.Symbol3_3();
	this.LA_Paksong.name = "LA_Paksong";
	this.LA_Paksong.parent = this;
	this.LA_Paksong.setTransform(1130.35,1473.8);

	this.LA_Sanamxai = new lib.Symbol3_3();
	this.LA_Sanamxai.name = "LA_Sanamxai";
	this.LA_Sanamxai.parent = this;
	this.LA_Sanamxai.setTransform(1202.35,1654.3);

	this.VN_DraySap = new lib.Symbol3_3();
	this.VN_DraySap.name = "VN_DraySap";
	this.VN_DraySap.parent = this;
	this.VN_DraySap.setTransform(1433.3,2000.75);

	this.VN_BuonDon = new lib.Symbol3_3();
	this.VN_BuonDon.name = "VN_BuonDon";
	this.VN_BuonDon.parent = this;
	this.VN_BuonDon.setTransform(1414.8,1961.75);

	this.VN_CaoLanh = new lib.Symbol3_3();
	this.VN_CaoLanh.name = "VN_CaoLanh";
	this.VN_CaoLanh.parent = this;
	this.VN_CaoLanh.setTransform(1059.85,2443.75);

	this.LA_PakBeng = new lib.Symbol3_3();
	this.LA_PakBeng.name = "LA_PakBeng";
	this.LA_PakBeng.parent = this;
	this.LA_PakBeng.setTransform(209.9,715);

	this.VN_XuanMai = new lib.Symbol3_3();
	this.VN_XuanMai.name = "VN_XuanMai";
	this.VN_XuanMai.parent = this;
	this.VN_XuanMai.setTransform(1048.55,558.4);

	this.VN_HaNoi = new lib.Symbol1copy5();
	this.VN_HaNoi.name = "VN_HaNoi";
	this.VN_HaNoi.parent = this;
	this.VN_HaNoi.setTransform(1067.35,517.85);

	this.KH_KrongPoiPet = new lib.Symbol3_3();
	this.KH_KrongPoiPet.name = "KH_KrongPoiPet";
	this.KH_KrongPoiPet.parent = this;
	this.KH_KrongPoiPet.setTransform(577.15,1752.1);

	this.LA_Thateng = new lib.Symbol3_3();
	this.LA_Thateng.name = "LA_Thateng";
	this.LA_Thateng.parent = this;
	this.LA_Thateng.setTransform(1141.85,1411.8);

	this.LA_Laongam = new lib.Symbol3_3();
	this.LA_Laongam.name = "LA_Laongam";
	this.LA_Laongam.parent = this;
	this.LA_Laongam.setTransform(1086.35,1364.8);

	this.LA_Pakse = new lib.Symbol3_3();
	this.LA_Pakse.name = "LA_Pakse";
	this.LA_Pakse.parent = this;
	this.LA_Pakse.setTransform(1024.35,1465.1);

	this.KH_BanLung = new lib.Symbol3_3();
	this.KH_BanLung.name = "KH_BanLung";
	this.KH_BanLung.parent = this;
	this.KH_BanLung.setTransform(1245.35,1854.8);

	this.VN_PhanThiet = new lib.Symbol3_3();
	this.VN_PhanThiet.name = "VN_PhanThiet";
	this.VN_PhanThiet.parent = this;
	this.VN_PhanThiet.setTransform(1581.8,2333.25);

	this.VN_KheXanh = new lib.Symbol3_3();
	this.VN_KheXanh.name = "VN_KheXanh";
	this.VN_KheXanh.parent = this;
	this.VN_KheXanh.setTransform(1249.85,1331.5);

	this.VN_PhongNha = new lib.Symbol3_3();
	this.VN_PhongNha.name = "VN_PhongNha";
	this.VN_PhongNha.parent = this;
	this.VN_PhongNha.setTransform(1150.55,1170.8);

	this.VN_TanTrao = new lib.Symbol3_3();
	this.VN_TanTrao.name = "VN_TanTrao";
	this.VN_TanTrao.parent = this;
	this.VN_TanTrao.setTransform(1045.05,343.85);

	this.VN_TuanGiao = new lib.Symbol3_3();
	this.VN_TuanGiao.name = "VN_TuanGiao";
	this.VN_TuanGiao.parent = this;
	this.VN_TuanGiao.setTransform(653.65,386.05);

	this.LA_PlainOfJars = new lib.Symbol3_3();
	this.LA_PlainOfJars.name = "LA_PlainOfJars";
	this.LA_PlainOfJars.parent = this;
	this.LA_PlainOfJars.setTransform(559.85,841.15);

	this.KH_Sihanoukville = new lib.Symbol3_3();
	this.KH_Sihanoukville.name = "KH_Sihanoukville";
	this.KH_Sihanoukville.parent = this;
	this.KH_Sihanoukville.setTransform(667.5,2419.55);

	this.VN_ConDao = new lib.Symbol3_3();
	this.VN_ConDao.name = "VN_ConDao";
	this.VN_ConDao.parent = this;
	this.VN_ConDao.setTransform(1418,2741.35);

	this.VN_BinhBa = new lib.Symbol3_3();
	this.VN_BinhBa.name = "VN_BinhBa";
	this.VN_BinhBa.parent = this;
	this.VN_BinhBa.setTransform(1748.3,2077);

	this.VN_TuyHoa = new lib.Symbol3_3();
	this.VN_TuyHoa.name = "VN_TuyHoa";
	this.VN_TuyHoa.parent = this;
	this.VN_TuyHoa.setTransform(1718.75,1891.8);

	this.VN_LySon = new lib.Symbol3_3();
	this.VN_LySon.name = "VN_LySon";
	this.VN_LySon.parent = this;
	this.VN_LySon.setTransform(1832.05,1597.6);

	this.VN_BaoLoc = new lib.Symbol3_3();
	this.VN_BaoLoc.name = "VN_BaoLoc";
	this.VN_BaoLoc.parent = this;
	this.VN_BaoLoc.setTransform(1506.3,2233.5);

	this.VN_PhanRang = new lib.Symbol3_3();
	this.VN_PhanRang.name = "VN_PhanRang";
	this.VN_PhanRang.parent = this;
	this.VN_PhanRang.setTransform(1673.25,2236.75);

	this.LA_MuangNgoy = new lib.Symbol3_3();
	this.LA_MuangNgoy.name = "LA_MuangNgoy";
	this.LA_MuangNgoy.parent = this;
	this.LA_MuangNgoy.setTransform(499.35,563.85);

	this.VN_VinhPhuc = new lib.Symbol3_3();
	this.VN_VinhPhuc.name = "VN_VinhPhuc";
	this.VN_VinhPhuc.parent = this;
	this.VN_VinhPhuc.setTransform(1014.35,465.85);

	this.VN_PhongTho = new lib.Symbol3_3();
	this.VN_PhongTho.name = "VN_PhongTho";
	this.VN_PhongTho.parent = this;
	this.VN_PhongTho.setTransform(589.85,239.35);

	this.VN_MuongLay = new lib.Symbol3_3();
	this.VN_MuongLay.name = "VN_MuongLay";
	this.VN_MuongLay.parent = this;
	this.VN_MuongLay.setTransform(560.85,340.35);

	this.LA_XamNeua = new lib.Symbol3_3();
	this.LA_XamNeua.name = "LA_XamNeua";
	this.LA_XamNeua.parent = this;
	this.LA_XamNeua.setTransform(731.35,635.35);

	this.KH_Kampot = new lib.Symbol3_3();
	this.KH_Kampot.name = "KH_Kampot";
	this.KH_Kampot.parent = this;
	this.KH_Kampot.setTransform(743.85,2423.75);

	this.KH_Kep = new lib.Symbol3_3();
	this.KH_Kep.name = "KH_Kep";
	this.KH_Kep.parent = this;
	this.KH_Kep.setTransform(790.85,2437.75);

	this.KH_Takeo = new lib.Symbol3_3();
	this.KH_Takeo.name = "KH_Takeo";
	this.KH_Takeo.parent = this;
	this.KH_Takeo.setTransform(879.85,2359.75);

	this.KH_SereiSaoPhoan = new lib.Symbol3_3();
	this.KH_SereiSaoPhoan.name = "KH_SereiSaoPhoan";
	this.KH_SereiSaoPhoan.parent = this;
	this.KH_SereiSaoPhoan.setTransform(638.85,1800.3);

	this.KH_SiemReap = new lib.Symbol3_3();
	this.KH_SiemReap.name = "KH_SiemReap";
	this.KH_SiemReap.parent = this;
	this.KH_SiemReap.setTransform(699.35,1855.8);

	this.KH_TonleSap = new lib.Symbol3_3();
	this.KH_TonleSap.name = "KH_TonleSap";
	this.KH_TonleSap.parent = this;
	this.KH_TonleSap.setTransform(705.35,1936.75);

	this.KH_Battambang = new lib.Symbol3_3();
	this.KH_Battambang.name = "KH_Battambang";
	this.KH_Battambang.parent = this;
	this.KH_Battambang.setTransform(563.85,1927.75);

	this.KH_Pursat = new lib.Symbol3_3();
	this.KH_Pursat.name = "KH_Pursat";
	this.KH_Pursat.parent = this;
	this.KH_Pursat.setTransform(687.35,2029.75);

	this.KH_PhnomPenh = new lib.Symbol3_3();
	this.KH_PhnomPenh.name = "KH_PhnomPenh";
	this.KH_PhnomPenh.parent = this;
	this.KH_PhnomPenh.setTransform(909.35,2262.25);

	this.KH_KompongChhnang = new lib.Symbol3_3();
	this.KH_KompongChhnang.name = "KH_KompongChhnang";
	this.KH_KompongChhnang.parent = this;
	this.KH_KompongChhnang.setTransform(769.85,2086);

	this.KH_KompongCham = new lib.Symbol3_3();
	this.KH_KompongCham.name = "KH_KompongCham";
	this.KH_KompongCham.parent = this;
	this.KH_KompongCham.setTransform(1128.35,2135.25);

	this.KH_KohTrong = new lib.Symbol3_3();
	this.KH_KohTrong.name = "KH_KohTrong";
	this.KH_KohTrong.parent = this;
	this.KH_KohTrong.setTransform(1133.35,2087.25);

	this.KH_KompongThom = new lib.Symbol3_3();
	this.KH_KompongThom.name = "KH_KompongThom";
	this.KH_KompongThom.parent = this;
	this.KH_KompongThom.setTransform(950.35,2045.75);

	this.KH_Kratie = new lib.Symbol3_3();
	this.KH_Kratie.name = "KH_Kratie";
	this.KH_Kratie.parent = this;
	this.KH_Kratie.setTransform(1108.35,2059.75);

	this.KH_Mondulkiri = new lib.Symbol3_3();
	this.KH_Mondulkiri.name = "KH_Mondulkiri";
	this.KH_Mondulkiri.parent = this;
	this.KH_Mondulkiri.setTransform(1279.35,2008.75);

	this.KH_Rattanakiri = new lib.Symbol3_3();
	this.KH_Rattanakiri.name = "KH_Rattanakiri";
	this.KH_Rattanakiri.parent = this;
	this.KH_Rattanakiri.setTransform(1268.35,1826.8);

	this.KH_StungTreng = new lib.Symbol3_3();
	this.KH_StungTreng.name = "KH_StungTreng";
	this.KH_StungTreng.parent = this;
	this.KH_StungTreng.setTransform(1136.55,1842.8);

	this.KH_Kohker = new lib.Symbol3_3();
	this.KH_Kohker.name = "KH_Kohker";
	this.KH_Kohker.parent = this;
	this.KH_Kohker.setTransform(828.85,1807.3);

	this.KH_PreahVihear = new lib.Symbol3_3();
	this.KH_PreahVihear.name = "KH_PreahVihear";
	this.KH_PreahVihear.parent = this;
	this.KH_PreahVihear.setTransform(933.85,1768.1);

	this.LA_IledeKhnong = new lib.Symbol3_3();
	this.LA_IledeKhnong.name = "LA_IledeKhnong";
	this.LA_IledeKhnong.parent = this;
	this.LA_IledeKhnong.setTransform(1070.85,1759.8);

	this.LA_Champassak = new lib.Symbol3_3();
	this.LA_Champassak.name = "LA_Champassak";
	this.LA_Champassak.parent = this;
	this.LA_Champassak.setTransform(1060.35,1553.8);

	this.LA_BanKhietNgong = new lib.Symbol3_3();
	this.LA_BanKhietNgong.name = "LA_BanKhietNgong";
	this.LA_BanKhietNgong.parent = this;
	this.LA_BanKhietNgong.setTransform(1095.35,1653.3);

	this.LA_Attapeu = new lib.Symbol3_3();
	this.LA_Attapeu.name = "LA_Attapeu";
	this.LA_Attapeu.parent = this;
	this.LA_Attapeu.setTransform(1277.85,1633.8);

	this.LA_DonDeang = new lib.Symbol3_3();
	this.LA_DonDeang.name = "LA_DonDeang";
	this.LA_DonDeang.parent = this;
	this.LA_DonDeang.setTransform(1080.85,1593.6);

	this.LA_WatPhou = new lib.Symbol3_3();
	this.LA_WatPhou.name = "LA_WatPhou";
	this.LA_WatPhou.parent = this;
	this.LA_WatPhou.setTransform(1052.85,1618.8);

	this.LA_Savannakhet = new lib.Symbol3_3();
	this.LA_Savannakhet.name = "LA_Savannakhet";
	this.LA_Savannakhet.parent = this;
	this.LA_Savannakhet.setTransform(876.35,1364.8);

	this.LA_Thakek = new lib.Symbol3_3();
	this.LA_Thakek.name = "LA_Thakek";
	this.LA_Thakek.parent = this;
	this.LA_Thakek.setTransform(894.35,1193.8);

	this.LA_Kenethao = new lib.Symbol3_3();
	this.LA_Kenethao.name = "LA_Kenethao";
	this.LA_Kenethao.parent = this;
	this.LA_Kenethao.setTransform(296.4,1109.85);

	this.LA_Vientiane = new lib.Symbol3_3();
	this.LA_Vientiane.name = "LA_Vientiane";
	this.LA_Vientiane.parent = this;
	this.LA_Vientiane.setTransform(474.9,1078.35);

	this.LA_Pakxan = new lib.Symbol3_3();
	this.LA_Pakxan.name = "LA_Pakxan";
	this.LA_Pakxan.parent = this;
	this.LA_Pakxan.setTransform(670.35,996.35);

	this.LA_NamNgum = new lib.Symbol3_3();
	this.LA_NamNgum.name = "LA_NamNgum";
	this.LA_NamNgum.parent = this;
	this.LA_NamNgum.setTransform(514.85,969.85);

	this.LA_VangVieng = new lib.Symbol3_3();
	this.LA_VangVieng.name = "LA_VangVieng";
	this.LA_VangVieng.parent = this;
	this.LA_VangVieng.setTransform(453.4,886.85);

	this.LA_Phonxavan = new lib.Symbol3_3();
	this.LA_Phonxavan.name = "LA_Phonxavan";
	this.LA_Phonxavan.parent = this;
	this.LA_Phonxavan.setTransform(581.85,799.85);

	this.LA_MuangKham = new lib.Symbol3_3();
	this.LA_MuangKham.name = "LA_MuangKham";
	this.LA_MuangKham.parent = this;
	this.LA_MuangKham.setTransform(663.85,769.85);

	this.LA_LuangPrabang = new lib.Symbol3_3();
	this.LA_LuangPrabang.name = "LA_LuangPrabang";
	this.LA_LuangPrabang.parent = this;
	this.LA_LuangPrabang.setTransform(402.35,733.35);

	this.LA_Hongsa = new lib.Symbol3_3();
	this.LA_Hongsa.name = "LA_Hongsa";
	this.LA_Hongsa.parent = this;
	this.LA_Hongsa.setTransform(238.4,755.55);

	this.LA_Houixai = new lib.Symbol3_3();
	this.LA_Houixai.name = "LA_Houixai";
	this.LA_Houixai.parent = this;
	this.LA_Houixai.setTransform(90.4,632.35);

	this.LA_MuangSing = new lib.Symbol3_3();
	this.LA_MuangSing.name = "LA_MuangSing";
	this.LA_MuangSing.parent = this;
	this.LA_MuangSing.setTransform(225.9,466.35);

	this.LA_LuangNamtha = new lib.Symbol3_3();
	this.LA_LuangNamtha.name = "LA_LuangNamtha";
	this.LA_LuangNamtha.parent = this;
	this.LA_LuangNamtha.setTransform(266.9,499.85);

	this.LA_Oudomxai = new lib.Symbol3_3();
	this.LA_Oudomxai.name = "LA_Oudomxai";
	this.LA_Oudomxai.parent = this;
	this.LA_Oudomxai.setTransform(356.9,595.05);

	this.LA_NongKhiaw = new lib.Symbol3_3();
	this.LA_NongKhiaw.name = "LA_NongKhiaw";
	this.LA_NongKhiaw.parent = this;
	this.LA_NongKhiaw.setTransform(505.9,613.35);

	this.LA_MuongKhua = new lib.Symbol3_3();
	this.LA_MuongKhua.name = "LA_MuongKhua";
	this.LA_MuongKhua.parent = this;
	this.LA_MuongKhua.setTransform(451.4,528.35);

	this.LA_Phongsali = new lib.Symbol3_3();
	this.LA_Phongsali.name = "LA_Phongsali";
	this.LA_Phongsali.parent = this;
	this.LA_Phongsali.setTransform(394.4,424.35);

	this.VN_CaMau = new lib.Symbol3_3();
	this.VN_CaMau.name = "VN_CaMau";
	this.VN_CaMau.parent = this;
	this.VN_CaMau.setTransform(913.85,2712.75);

	this.VN_PhuQuoc = new lib.Symbol3_3();
	this.VN_PhuQuoc.name = "VN_PhuQuoc";
	this.VN_PhuQuoc.parent = this;
	this.VN_PhuQuoc.setTransform(747.35,2584.25);

	this.VN_HaTien = new lib.Symbol3_3();
	this.VN_HaTien.name = "VN_HaTien";
	this.VN_HaTien.parent = this;
	this.VN_HaTien.setTransform(821.85,2468.25);

	this.VN_RachGia = new lib.Symbol3_3();
	this.VN_RachGia.name = "VN_RachGia";
	this.VN_RachGia.parent = this;
	this.VN_RachGia.setTransform(924.6,2530.75);

	this.VN_BacLieu = new lib.Symbol3_3();
	this.VN_BacLieu.name = "VN_BacLieu";
	this.VN_BacLieu.parent = this;
	this.VN_BacLieu.setTransform(1016.35,2681.75);

	this.VN_SocTrang = new lib.Symbol3_3();
	this.VN_SocTrang.name = "VN_SocTrang";
	this.VN_SocTrang.parent = this;
	this.VN_SocTrang.setTransform(1078.85,2636.75);

	this.VN_CanTho = new lib.Symbol3_3();
	this.VN_CanTho.name = "VN_CanTho";
	this.VN_CanTho.parent = this;
	this.VN_CanTho.setTransform(1060.85,2544.75);

	this.VN_TraVinh = new lib.Symbol3_3();
	this.VN_TraVinh.name = "VN_TraVinh";
	this.VN_TraVinh.parent = this;
	this.VN_TraVinh.setTransform(1163.85,2556.75);

	this.VN_BenTre = new lib.Symbol3_3();
	this.VN_BenTre.name = "VN_BenTre";
	this.VN_BenTre.parent = this;
	this.VN_BenTre.setTransform(1204.35,2498.75);

	this.VN_CaiBe = new lib.Symbol3_3();
	this.VN_CaiBe.name = "VN_CaiBe";
	this.VN_CaiBe.parent = this;
	this.VN_CaiBe.setTransform(1109.85,2476.25);

	this.VN_VinhLong = new lib.Symbol3_3();
	this.VN_VinhLong.name = "VN_VinhLong";
	this.VN_VinhLong.parent = this;
	this.VN_VinhLong.setTransform(1116.85,2508.75);

	this.VN_BangLang = new lib.Symbol3_3();
	this.VN_BangLang.name = "VN_BangLang";
	this.VN_BangLang.parent = this;
	this.VN_BangLang.setTransform(1010.35,2503.75);

	this.VN_LongXuyen = new lib.Symbol3_3();
	this.VN_LongXuyen.name = "VN_LongXuyen";
	this.VN_LongXuyen.parent = this;
	this.VN_LongXuyen.setTransform(1002.35,2458.75);

	this.VN_TraSu = new lib.Symbol3_3();
	this.VN_TraSu.name = "VN_TraSu";
	this.VN_TraSu.parent = this;
	this.VN_TraSu.setTransform(933.85,2442.75);

	this.VN_ChauDoc = new lib.Symbol3_3();
	this.VN_ChauDoc.name = "VN_ChauDoc";
	this.VN_ChauDoc.parent = this;
	this.VN_ChauDoc.setTransform(930.85,2405.75);

	this.VN_SaDec = new lib.Symbol3_3();
	this.VN_SaDec.name = "VN_SaDec";
	this.VN_SaDec.parent = this;
	this.VN_SaDec.setTransform(1071.35,2484.75);

	this.VN_CaiLay = new lib.Symbol3_3();
	this.VN_CaiLay.name = "VN_CaiLay";
	this.VN_CaiLay.parent = this;
	this.VN_CaiLay.setTransform(1124.35,2448.75);

	this.VN_MyTho = new lib.Symbol3_3();
	this.VN_MyTho.name = "VN_MyTho";
	this.VN_MyTho.parent = this;
	this.VN_MyTho.setTransform(1201.35,2467.25);

	this.VN_VungTau = new lib.Symbol3_3();
	this.VN_VungTau.name = "VN_VungTau";
	this.VN_VungTau.parent = this;
	this.VN_VungTau.setTransform(1341.3,2462.25);

	this.VN_MocBai = new lib.Symbol3_3();
	this.VN_MocBai.name = "VN_MocBai";
	this.VN_MocBai.parent = this;
	this.VN_MocBai.setTransform(1150.85,2322.25);

	this.VN_HoChiMinhCity = new lib.Symbol3_3();
	this.VN_HoChiMinhCity.name = "VN_HoChiMinhCity";
	this.VN_HoChiMinhCity.parent = this;
	this.VN_HoChiMinhCity.setTransform(1232.35,2380.75);

	this.VN_CuChi = new lib.Symbol3_3();
	this.VN_CuChi.name = "VN_CuChi";
	this.VN_CuChi.parent = this;
	this.VN_CuChi.setTransform(1195.85,2353.75);

	this.VN_TayNinh = new lib.Symbol3_3();
	this.VN_TayNinh.name = "VN_TayNinh";
	this.VN_TayNinh.parent = this;
	this.VN_TayNinh.setTransform(1149.85,2283.5);

	this.VN_DongXoai = new lib.Symbol3_3();
	this.VN_DongXoai.name = "VN_DongXoai";
	this.VN_DongXoai.parent = this;
	this.VN_DongXoai.setTransform(1286.35,2265.5);

	this.VN_MuiNe = new lib.Symbol3_3();
	this.VN_MuiNe.name = "VN_MuiNe";
	this.VN_MuiNe.parent = this;
	this.VN_MuiNe.setTransform(1624.25,2325.25);

	this.VN_NinhGia = new lib.Symbol3_3();
	this.VN_NinhGia.name = "VN_NinhGia";
	this.VN_NinhGia.parent = this;
	this.VN_NinhGia.setTransform(1530.8,2216.75);

	this.VN_GiaNghia = new lib.Symbol3_3();
	this.VN_GiaNghia.name = "VN_GiaNghia";
	this.VN_GiaNghia.parent = this;
	this.VN_GiaNghia.setTransform(1408.3,2135.25);

	this.VN_DaLat = new lib.Symbol3_3();
	this.VN_DaLat.name = "VN_DaLat";
	this.VN_DaLat.parent = this;
	this.VN_DaLat.setTransform(1544.95,2157.25);

	this.VN_LacLake = new lib.Symbol3_3();
	this.VN_LacLake.name = "VN_LacLake";
	this.VN_LacLake.parent = this;
	this.VN_LacLake.setTransform(1490.35,2013.75);

	this.VN_BuonMeThuot = new lib.Symbol3_3();
	this.VN_BuonMeThuot.name = "VN_BuonMeThuot";
	this.VN_BuonMeThuot.parent = this;
	this.VN_BuonMeThuot.setTransform(1483.3,1977.75);

	this.VN_NhaTrang = new lib.Symbol3_3();
	this.VN_NhaTrang.name = "VN_NhaTrang";
	this.VN_NhaTrang.parent = this;
	this.VN_NhaTrang.setTransform(1734.25,2022.25);

	this.VN_BuonHo = new lib.Symbol3_3();
	this.VN_BuonHo.name = "VN_BuonHo";
	this.VN_BuonHo.parent = this;
	this.VN_BuonHo.setTransform(1503.3,1943.3);

	this.VN_Pleiku = new lib.Symbol3_3();
	this.VN_Pleiku.name = "VN_Pleiku";
	this.VN_Pleiku.parent = this;
	this.VN_Pleiku.setTransform(1484.3,1839.3);

	this.VN_QuyNhon = new lib.Symbol3_3();
	this.VN_QuyNhon.name = "VN_QuyNhon";
	this.VN_QuyNhon.parent = this;
	this.VN_QuyNhon.setTransform(1711.75,1851.3);

	this.VN_KonTum = new lib.Symbol3_3();
	this.VN_KonTum.name = "VN_KonTum";
	this.VN_KonTum.parent = this;
	this.VN_KonTum.setTransform(1463.8,1802.3);

	this.VN_BoY = new lib.Symbol3_3();
	this.VN_BoY.name = "VN_BoY";
	this.VN_BoY.parent = this;
	this.VN_BoY.setTransform(1373,1741.8);

	this.VN_SonHa = new lib.Symbol3_3();
	this.VN_SonHa.name = "VN_SonHa";
	this.VN_SonHa.parent = this;
	this.VN_SonHa.setTransform(1577.8,1710.8);

	this.VN_QuangNgai = new lib.Symbol3_3();
	this.VN_QuangNgai.name = "VN_QuangNgai";
	this.VN_QuangNgai.parent = this;
	this.VN_QuangNgai.setTransform(1659.25,1669.3);

	this.VN_PhuocSon = new lib.Symbol3_3();
	this.VN_PhuocSon.name = "VN_PhuocSon";
	this.VN_PhuocSon.parent = this;
	this.VN_PhuocSon.setTransform(1435.3,1561.8);

	this.VN_CuLaoCham = new lib.Symbol3_3();
	this.VN_CuLaoCham.name = "VN_CuLaoCham";
	this.VN_CuLaoCham.parent = this;
	this.VN_CuLaoCham.setTransform(1656.25,1462.1);

	this.VN_HoiAn = new lib.Symbol3_3();
	this.VN_HoiAn.name = "VN_HoiAn";
	this.VN_HoiAn.parent = this;
	this.VN_HoiAn.setTransform(1555.1,1465.1);

	this.VN_NamGiang = new lib.Symbol3_3();
	this.VN_NamGiang.name = "VN_NamGiang";
	this.VN_NamGiang.parent = this;
	this.VN_NamGiang.setTransform(1366.8,1496.8);

	this.VN_DongGiang = new lib.Symbol3_3();
	this.VN_DongGiang.name = "VN_DongGiang";
	this.VN_DongGiang.parent = this;
	this.VN_DongGiang.setTransform(1415.3,1434.8);

	this.VN_DaNang = new lib.Symbol3_3();
	this.VN_DaNang.name = "VN_DaNang";
	this.VN_DaNang.parent = this;
	this.VN_DaNang.setTransform(1521.8,1433.8);

	this.VN_MySon = new lib.Symbol3_3();
	this.VN_MySon.name = "VN_MySon";
	this.VN_MySon.parent = this;
	this.VN_MySon.setTransform(1486.3,1485.8);

	this.VN_ARoang = new lib.Symbol3_3();
	this.VN_ARoang.name = "VN_ARoang";
	this.VN_ARoang.parent = this;
	this.VN_ARoang.setTransform(1347.3,1408.8);

	this.VN_Hue = new lib.Symbol3_3();
	this.VN_Hue.name = "VN_Hue";
	this.VN_Hue.parent = this;
	this.VN_Hue.setTransform(1401,1366.8);

	this.VN_QuangTri = new lib.Symbol3_3();
	this.VN_QuangTri.name = "VN_QuangTri";
	this.VN_QuangTri.parent = this;
	this.VN_QuangTri.setTransform(1344.3,1311.3);

	this.VN_VinhMocTunnels = new lib.Symbol3_3();
	this.VN_VinhMocTunnels.name = "VN_VinhMocTunnels";
	this.VN_VinhMocTunnels.parent = this;
	this.VN_VinhMocTunnels.setTransform(1346.3,1271.3);

	this.VN_DongHoi = new lib.Symbol3_3();
	this.VN_DongHoi.name = "VN_DongHoi";
	this.VN_DongHoi.parent = this;
	this.VN_DongHoi.setTransform(1215.85,1175.8);

	this.VN_HaTinh = new lib.Symbol3_3();
	this.VN_HaTinh.name = "VN_HaTinh";
	this.VN_HaTinh.parent = this;
	this.VN_HaTinh.setTransform(1099.3,1023.8);

	this.VN_CauTreo = new lib.Symbol3_3();
	this.VN_CauTreo.name = "VN_CauTreo";
	this.VN_CauTreo.parent = this;
	this.VN_CauTreo.setTransform(963.35,1012.8);

	this.VN_NamCan = new lib.Symbol3_3();
	this.VN_NamCan.name = "VN_NamCan";
	this.VN_NamCan.parent = this;
	this.VN_NamCan.setTransform(739.85,804.85);

	this.VN_Vinh = new lib.Symbol3_3();
	this.VN_Vinh.name = "VN_Vinh";
	this.VN_Vinh.parent = this;
	this.VN_Vinh.setTransform(1049.35,950.35);

	this.VN_ThanhHoa = new lib.Symbol3_3();
	this.VN_ThanhHoa.name = "VN_ThanhHoa";
	this.VN_ThanhHoa.parent = this;
	this.VN_ThanhHoa.setTransform(1037.3,796.95);

	this.VN_MuongHum = new lib.Symbol3_3();
	this.VN_MuongHum.name = "VN_MuongHum";
	this.VN_MuongHum.parent = this;
	this.VN_MuongHum.setTransform(673.85,241.85);

	this.VN_DuGia = new lib.Symbol3_3();
	this.VN_DuGia.name = "VN_DuGia";
	this.VN_DuGia.parent = this;
	this.VN_DuGia.setTransform(951.4,169.35);

	this.VN_BaKhe = new lib.Symbol3_3();
	this.VN_BaKhe.name = "VN_BaKhe";
	this.VN_BaKhe.parent = this;
	this.VN_BaKhe.setTransform(892.4,474.55);

	this.VN_BacMe = new lib.Symbol3_3();
	this.VN_BacMe.name = "VN_BacMe";
	this.VN_BacMe.parent = this;
	this.VN_BacMe.setTransform(976.85,224.35);

	this.VN_BacHa = new lib.Symbol3_3();
	this.VN_BacHa.name = "VN_BacHa";
	this.VN_BacHa.parent = this;
	this.VN_BacHa.setTransform(803.35,257.35);

	this.VN_CanCau = new lib.Symbol3_3();
	this.VN_CanCau.name = "VN_CanCau";
	this.VN_CanCau.parent = this;
	this.VN_CanCau.setTransform(804.35,229.85);

	this.VN_HoangSuPhi = new lib.Symbol3_3();
	this.VN_HoangSuPhi.name = "VN_HoangSuPhi";
	this.VN_HoangSuPhi.parent = this;
	this.VN_HoangSuPhi.setTransform(860.85,217.35);

	this.VN_MeoVac = new lib.Symbol3_3();
	this.VN_MeoVac.name = "VN_MeoVac";
	this.VN_MeoVac.parent = this;
	this.VN_MeoVac.setTransform(1001.3,141.4);

	this.VN_DongVan = new lib.Symbol3_3();
	this.VN_DongVan.name = "VN_DongVan";
	this.VN_DongVan.parent = this;
	this.VN_DongVan.setTransform(982.85,111.9);

	this.VN_LungCu = new lib.Symbol3_3();
	this.VN_LungCu.name = "VN_LungCu";
	this.VN_LungCu.parent = this;
	this.VN_LungCu.setTransform(975.3,81.4);

	this.VN_YenMinh = new lib.Symbol3_3();
	this.VN_YenMinh.name = "VN_YenMinh";
	this.VN_YenMinh.parent = this;
	this.VN_YenMinh.setTransform(933.85,136.4);

	this.VN_QuanBa = new lib.Symbol3_3();
	this.VN_QuanBa.name = "VN_QuanBa";
	this.VN_QuanBa.parent = this;
	this.VN_QuanBa.setTransform(902.3,150.9);

	this.VN_XinMan = new lib.Symbol3_3();
	this.VN_XinMan.name = "VN_XinMan";
	this.VN_XinMan.parent = this;
	this.VN_XinMan.setTransform(837.3,196.9);

	this.VN_SinCheng = new lib.Symbol3_3();
	this.VN_SinCheng.name = "VN_SinCheng";
	this.VN_SinCheng.parent = this;
	this.VN_SinCheng.setTransform(784.85,219.4);

	this.VN_LungKhauNhin = new lib.Symbol3_3();
	this.VN_LungKhauNhin.name = "VN_LungKhauNhin";
	this.VN_LungKhauNhin.parent = this;
	this.VN_LungKhauNhin.setTransform(744.85,199.35);

	this.VN_CaoSon = new lib.Symbol3_3();
	this.VN_CaoSon.name = "VN_CaoSon";
	this.VN_CaoSon.parent = this;
	this.VN_CaoSon.setTransform(744.35,221.85);

	this.VN_CocLy = new lib.Symbol3_3();
	this.VN_CocLy.name = "VN_CocLy";
	this.VN_CocLy.parent = this;
	this.VN_CocLy.setTransform(765.05,236.15);

	this.VN_LaoCai = new lib.Symbol3_3();
	this.VN_LaoCai.name = "VN_LaoCai";
	this.VN_LaoCai.parent = this;
	this.VN_LaoCai.setTransform(717.85,245.85);

	this.VN_LaiChau = new lib.Symbol3_3();
	this.VN_LaiChau.name = "VN_LaiChau";
	this.VN_LaiChau.parent = this;
	this.VN_LaiChau.setTransform(638.85,261.85);

	this.VN_Sapa = new lib.Symbol3_3();
	this.VN_Sapa.name = "VN_Sapa";
	this.VN_Sapa.parent = this;
	this.VN_Sapa.setTransform(699.85,284.35);

	this.VN_BinhLu = new lib.Symbol3_3();
	this.VN_BinhLu.name = "VN_BinhLu";
	this.VN_BinhLu.parent = this;
	this.VN_BinhLu.setTransform(679.85,295.35);

	this.VN_SinHo = new lib.Symbol3_3();
	this.VN_SinHo.name = "VN_SinHo";
	this.VN_SinHo.parent = this;
	this.VN_SinHo.setTransform(590.85,291.85);

	this.VN_TayTrang = new lib.Symbol3_3();
	this.VN_TayTrang.name = "VN_TayTrang";
	this.VN_TayTrang.parent = this;
	this.VN_TayTrang.setTransform(524.35,491.85);

	this.VN_DienBienPhu = new lib.Symbol3_3();
	this.VN_DienBienPhu.name = "VN_DienBienPhu";
	this.VN_DienBienPhu.parent = this;
	this.VN_DienBienPhu.setTransform(544.85,445.05);

	this.VN_ThanUyen = new lib.Symbol3_3();
	this.VN_ThanUyen.name = "VN_ThanUyen";
	this.VN_ThanUyen.parent = this;
	this.VN_ThanUyen.setTransform(719.85,353.85);

	this.VN_MuCangChai = new lib.Symbol3_3();
	this.VN_MuCangChai.name = "VN_MuCangChai";
	this.VN_MuCangChai.parent = this;
	this.VN_MuCangChai.setTransform(789.85,396.85);

	this.VN_NghiaLo = new lib.Symbol3_3();
	this.VN_NghiaLo.name = "VN_NghiaLo";
	this.VN_NghiaLo.parent = this;
	this.VN_NghiaLo.setTransform(879.35,458.35);

	this.VN_PhuYen = new lib.Symbol3_3();
	this.VN_PhuYen.name = "VN_PhuYen";
	this.VN_PhuYen.parent = this;
	this.VN_PhuYen.setTransform(864.6,482.85);

	this.VN_SonLa = new lib.Symbol3_3();
	this.VN_SonLa.name = "VN_SonLa";
	this.VN_SonLa.parent = this;
	this.VN_SonLa.setTransform(741.35,498.1);

	this.VN_PuLuong = new lib.Symbol3_3();
	this.VN_PuLuong.name = "VN_PuLuong";
	this.VN_PuLuong.parent = this;
	this.VN_PuLuong.setTransform(957.85,646.85);

	this.VN_MocChau = new lib.Symbol3_3();
	this.VN_MocChau.name = "VN_MocChau";
	this.VN_MocChau.parent = this;
	this.VN_MocChau.setTransform(890.85,567.2);

	this.VN_MaiChau = new lib.Symbol3_3();
	this.VN_MaiChau.name = "VN_MaiChau";
	this.VN_MaiChau.parent = this;
	this.VN_MaiChau.setTransform(965.3,583.05);

	this.VN_DuongLam = new lib.Symbol3_3();
	this.VN_DuongLam.name = "VN_DuongLam";
	this.VN_DuongLam.parent = this;
	this.VN_DuongLam.setTransform(983.85,496.85);

	this.VN_ThacBa = new lib.Symbol3_3();
	this.VN_ThacBa.name = "VN_ThacBa";
	this.VN_ThacBa.parent = this;
	this.VN_ThacBa.setTransform(981.85,405.85);

	this.VN_TuyenQuang = new lib.Symbol3_3();
	this.VN_TuyenQuang.name = "VN_TuyenQuang";
	this.VN_TuyenQuang.parent = this;
	this.VN_TuyenQuang.setTransform(1006.75,396.05);

	this.VN_ThaiNguyen = new lib.Symbol3_3();
	this.VN_ThaiNguyen.name = "VN_ThaiNguyen";
	this.VN_ThaiNguyen.parent = this;
	this.VN_ThaiNguyen.setTransform(1072.25,415.35);

	this.VN_BacSon = new lib.Symbol3_3();
	this.VN_BacSon.name = "VN_BacSon";
	this.VN_BacSon.parent = this;
	this.VN_BacSon.setTransform(1140.85,337.85);

	this.VN_HaGiang = new lib.Symbol3_3();
	this.VN_HaGiang.name = "VN_HaGiang";
	this.VN_HaGiang.parent = this;
	this.VN_HaGiang.setTransform(897.55,203.05);

	this.VN_BaBe = new lib.Symbol3_3();
	this.VN_BaBe.name = "VN_BaBe";
	this.VN_BaBe.parent = this;
	this.VN_BaBe.setTransform(1055.85,269.35);

	this.VN_BaoLac = new lib.Symbol3_3();
	this.VN_BaoLac.name = "VN_BaoLac";
	this.VN_BaoLac.parent = this;
	this.VN_BaoLac.setTransform(1084.85,192.65);

	this.VN_CaoBang = new lib.Symbol3_3();
	this.VN_CaoBang.name = "VN_CaoBang";
	this.VN_CaoBang.parent = this;
	this.VN_CaoBang.setTransform(1158.8,221.35);

	this.VN_BanGioc = new lib.Symbol3_3();
	this.VN_BanGioc.name = "VN_BanGioc";
	this.VN_BanGioc.parent = this;
	this.VN_BanGioc.setTransform(1245.85,183.85);

	this.VN_QuangUyen = new lib.Symbol3_3();
	this.VN_QuangUyen.name = "VN_QuangUyen";
	this.VN_QuangUyen.parent = this;
	this.VN_QuangUyen.setTransform(1203.85,224.85);

	this.VN_DongKhe = new lib.Symbol3_3();
	this.VN_DongKhe.name = "VN_DongKhe";
	this.VN_DongKhe.parent = this;
	this.VN_DongKhe.setTransform(1196.85,255.35);

	this.VN_ThatKhe = new lib.Symbol3_3();
	this.VN_ThatKhe.name = "VN_ThatKhe";
	this.VN_ThatKhe.parent = this;
	this.VN_ThatKhe.setTransform(1213.85,306.35);

	this.VN_LangSon = new lib.Symbol3_3();
	this.VN_LangSon.name = "VN_LangSon";
	this.VN_LangSon.parent = this;
	this.VN_LangSon.setTransform(1242.85,357.35);

	this.VN_BacGiang = new lib.Symbol3_3();
	this.VN_BacGiang.name = "VN_BacGiang";
	this.VN_BacGiang.parent = this;
	this.VN_BacGiang.setTransform(1117.35,480.35);

	this.VN_BacNinh = new lib.Symbol3_3();
	this.VN_BacNinh.name = "VN_BacNinh";
	this.VN_BacNinh.parent = this;
	this.VN_BacNinh.setTransform(1100.55,510.85);

	this.VN_HoaBinh = new lib.Symbol3_3();
	this.VN_HoaBinh.name = "VN_HoaBinh";
	this.VN_HoaBinh.parent = this;
	this.VN_HoaBinh.setTransform(1023.35,574.85);

	this.VN_NinhBinh = new lib.Symbol3_3();
	this.VN_NinhBinh.name = "VN_NinhBinh";
	this.VN_NinhBinh.parent = this;
	this.VN_NinhBinh.setTransform(1102.85,658.85);

	this.VN_NamDinh = new lib.Symbol3_3();
	this.VN_NamDinh.name = "VN_NamDinh";
	this.VN_NamDinh.parent = this;
	this.VN_NamDinh.setTransform(1145.35,647.35);

	this.VN_ThaiBinh = new lib.Symbol3_3();
	this.VN_ThaiBinh.name = "VN_ThaiBinh";
	this.VN_ThaiBinh.parent = this;
	this.VN_ThaiBinh.setTransform(1176.35,628.35);

	this.VN_HaLong = new lib.Symbol3_3();
	this.VN_HaLong.name = "VN_HaLong";
	this.VN_HaLong.parent = this;
	this.VN_HaLong.setTransform(1275.85,535.85);

	this.VN_HaiPhong = new lib.Symbol3_3();
	this.VN_HaiPhong.name = "VN_HaiPhong";
	this.VN_HaiPhong.parent = this;
	this.VN_HaiPhong.setTransform(1216.35,591.7);

	this.VN_MongCai = new lib.Symbol3_3();
	this.VN_MongCai.name = "VN_MongCai";
	this.VN_MongCai.parent = this;
	this.VN_MongCai.setTransform(1494.35,427.55);

	this.VN_TienYen = new lib.Symbol3_3();
	this.VN_TienYen.name = "VN_TienYen";
	this.VN_TienYen.parent = this;
	this.VN_TienYen.setTransform(1374,458.35);

	this.VN_CatBa = new lib.Symbol3_3();
	this.VN_CatBa.name = "VN_CatBa";
	this.VN_CatBa.parent = this;
	this.VN_CatBa.setTransform(1301.35,590.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.VN_CatBa},{t:this.VN_TienYen},{t:this.VN_MongCai},{t:this.VN_HaiPhong},{t:this.VN_HaLong},{t:this.VN_ThaiBinh},{t:this.VN_NamDinh},{t:this.VN_NinhBinh},{t:this.VN_HoaBinh},{t:this.VN_BacNinh},{t:this.VN_BacGiang},{t:this.VN_LangSon},{t:this.VN_ThatKhe},{t:this.VN_DongKhe},{t:this.VN_QuangUyen},{t:this.VN_BanGioc},{t:this.VN_CaoBang},{t:this.VN_BaoLac},{t:this.VN_BaBe},{t:this.VN_HaGiang},{t:this.VN_BacSon},{t:this.VN_ThaiNguyen},{t:this.VN_TuyenQuang},{t:this.VN_ThacBa},{t:this.VN_DuongLam},{t:this.VN_MaiChau},{t:this.VN_MocChau},{t:this.VN_PuLuong},{t:this.VN_SonLa},{t:this.VN_PhuYen},{t:this.VN_NghiaLo},{t:this.VN_MuCangChai},{t:this.VN_ThanUyen},{t:this.VN_DienBienPhu},{t:this.VN_TayTrang},{t:this.VN_SinHo},{t:this.VN_BinhLu},{t:this.VN_Sapa},{t:this.VN_LaiChau},{t:this.VN_LaoCai},{t:this.VN_CocLy},{t:this.VN_CaoSon},{t:this.VN_LungKhauNhin},{t:this.VN_SinCheng},{t:this.VN_XinMan},{t:this.VN_QuanBa},{t:this.VN_YenMinh},{t:this.VN_LungCu},{t:this.VN_DongVan},{t:this.VN_MeoVac},{t:this.VN_HoangSuPhi},{t:this.VN_CanCau},{t:this.VN_BacHa},{t:this.VN_BacMe},{t:this.VN_BaKhe},{t:this.VN_DuGia},{t:this.VN_MuongHum},{t:this.VN_ThanhHoa},{t:this.VN_Vinh},{t:this.VN_NamCan},{t:this.VN_CauTreo},{t:this.VN_HaTinh},{t:this.VN_DongHoi},{t:this.VN_VinhMocTunnels},{t:this.VN_QuangTri},{t:this.VN_Hue},{t:this.VN_ARoang},{t:this.VN_MySon},{t:this.VN_DaNang},{t:this.VN_DongGiang},{t:this.VN_NamGiang},{t:this.VN_HoiAn},{t:this.VN_CuLaoCham},{t:this.VN_PhuocSon},{t:this.VN_QuangNgai},{t:this.VN_SonHa},{t:this.VN_BoY},{t:this.VN_KonTum},{t:this.VN_QuyNhon},{t:this.VN_Pleiku},{t:this.VN_BuonHo},{t:this.VN_NhaTrang},{t:this.VN_BuonMeThuot},{t:this.VN_LacLake},{t:this.VN_DaLat},{t:this.VN_GiaNghia},{t:this.VN_NinhGia},{t:this.VN_MuiNe},{t:this.VN_DongXoai},{t:this.VN_TayNinh},{t:this.VN_CuChi},{t:this.VN_HoChiMinhCity},{t:this.VN_MocBai},{t:this.VN_VungTau},{t:this.VN_MyTho},{t:this.VN_CaiLay},{t:this.VN_SaDec},{t:this.VN_ChauDoc},{t:this.VN_TraSu},{t:this.VN_LongXuyen},{t:this.VN_BangLang},{t:this.VN_VinhLong},{t:this.VN_CaiBe},{t:this.VN_BenTre},{t:this.VN_TraVinh},{t:this.VN_CanTho},{t:this.VN_SocTrang},{t:this.VN_BacLieu},{t:this.VN_RachGia},{t:this.VN_HaTien},{t:this.VN_PhuQuoc},{t:this.VN_CaMau},{t:this.LA_Phongsali},{t:this.LA_MuongKhua},{t:this.LA_NongKhiaw},{t:this.LA_Oudomxai},{t:this.LA_LuangNamtha},{t:this.LA_MuangSing},{t:this.LA_Houixai},{t:this.LA_Hongsa},{t:this.LA_LuangPrabang},{t:this.LA_MuangKham},{t:this.LA_Phonxavan},{t:this.LA_VangVieng},{t:this.LA_NamNgum},{t:this.LA_Pakxan},{t:this.LA_Vientiane},{t:this.LA_Kenethao},{t:this.LA_Thakek},{t:this.LA_Savannakhet},{t:this.LA_WatPhou},{t:this.LA_DonDeang},{t:this.LA_Attapeu},{t:this.LA_BanKhietNgong},{t:this.LA_Champassak},{t:this.LA_IledeKhnong},{t:this.KH_PreahVihear},{t:this.KH_Kohker},{t:this.KH_StungTreng},{t:this.KH_Rattanakiri},{t:this.KH_Mondulkiri},{t:this.KH_Kratie},{t:this.KH_KompongThom},{t:this.KH_KohTrong},{t:this.KH_KompongCham},{t:this.KH_KompongChhnang},{t:this.KH_PhnomPenh},{t:this.KH_Pursat},{t:this.KH_Battambang},{t:this.KH_TonleSap},{t:this.KH_SiemReap},{t:this.KH_SereiSaoPhoan},{t:this.KH_Takeo},{t:this.KH_Kep},{t:this.KH_Kampot},{t:this.LA_XamNeua},{t:this.VN_MuongLay},{t:this.VN_PhongTho},{t:this.VN_VinhPhuc},{t:this.LA_MuangNgoy},{t:this.VN_PhanRang},{t:this.VN_BaoLoc},{t:this.VN_LySon},{t:this.VN_TuyHoa},{t:this.VN_BinhBa},{t:this.VN_ConDao},{t:this.KH_Sihanoukville},{t:this.LA_PlainOfJars},{t:this.VN_TuanGiao},{t:this.VN_TanTrao},{t:this.VN_PhongNha},{t:this.VN_KheXanh},{t:this.VN_PhanThiet},{t:this.KH_BanLung},{t:this.LA_Pakse},{t:this.LA_Laongam},{t:this.LA_Thateng},{t:this.KH_KrongPoiPet},{t:this.VN_HaNoi},{t:this.VN_XuanMai},{t:this.LA_PakBeng},{t:this.VN_CaoLanh},{t:this.VN_BuonDon},{t:this.VN_DraySap},{t:this.LA_Sanamxai},{t:this.LA_Paksong},{t:this.LA_Sekong},{t:this.VN_GotFerry},{t:this.VN_DinhLap},{t:this.VN_TuLe},{t:this.VN_YenThuy},{t:this.VN_TramChim},{t:this.VN_TanChau},{t:this.VN_BacKan},{t:this.VN_PhoRang},{t:this.VN_BacQuang},{t:this.VN_MyLai},{t:this.VN_BachMa},{t:this.VN_ALuoi},{t:this.VN_CatTien},{t:this.VN_DongNai},{t:this.VN_BinhChau},{t:this.VN_TanAn},{t:this.VN_TinhBien}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy_1, new cjs.Rectangle(80.2,70.3,1763.2,2681.3999999999996), null);


(lib.map_viet_nam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.mcDriver = new lib.Symbol19();
	this.mcDriver.name = "mcDriver";
	this.mcDriver.parent = this;
	this.mcDriver.setTransform(23,2672.15);

	this.timeline.addTween(cjs.Tween.get(this.mcDriver).wait(1));

	// Layer_4
	this.mcRoutes = new lib.Symbol1copy_1();
	this.mcRoutes.name = "mcRoutes";
	this.mcRoutes.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.mcRoutes).wait(1));

	// Layer_6
	this.mcCity = new lib.Symbol8copy();
	this.mcCity.name = "mcCity";
	this.mcCity.parent = this;
	this.mcCity.setTransform(1013.5,1436,1,1,0,0,0,991.5,1403);

	this.timeline.addTween(cjs.Tween.get(this.mcCity).wait(1));

	// Layer_3
	this.instance = new lib.map3nuoc1pngcopy();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.map_viet_nam, new cjs.Rectangle(0,0,2048,2854), null);


// stage content:
(lib.ui_viet_nam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.mcGame = new lib.map_viet_nam();
	this.mcGame.name = "mcGame";
	this.mcGame.parent = this;
	this.mcGame.setTransform(4,-6);

	this.timeline.addTween(cjs.Tween.get(this.mcGame).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1032,1415,1020,1433);
// library properties:
lib.properties = {
	id: '1FD19714E65D4E4DB044A37B9F30D6F9',
	width: 2056,
	height: 2842,
	fps: 24,
	color: "#666666",
	opacity: 1.00,
	manifest: [
		{src:"images/map3nuoc1pngcopy.jpg", id:"map3nuoc1pngcopy"},
		{src:"images/ui_viet_nam_atlas_.png", id:"ui_viet_nam_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['1FD19714E65D4E4DB044A37B9F30D6F9'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;